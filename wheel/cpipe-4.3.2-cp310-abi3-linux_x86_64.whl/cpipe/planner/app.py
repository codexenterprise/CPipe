"""CPipe capacity planner. Planner page is public; catalog and formulas require login."""

from __future__ import annotations

import json
import secrets
from pathlib import Path

import yaml
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from .calculator import admin_detail, calculate, public_result
from .catalog import (
    DATA_DIR,
    algo_map,
    default_catalog,
    hw_map,
    load_catalog,
    public_catalog,
    save_catalog,
)

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = DATA_DIR / "config.yaml"
DEFAULT_PORT = 8888


def _write_default_config() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        "auth": {"username": "admin", "password": "123456", "secret_key": secrets.token_urlsafe(32)},
        "server": {"host": "0.0.0.0", "port": DEFAULT_PORT},
    }
    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        f.write("# Restart the service after changing username or password\n")
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        _write_default_config()
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    data.setdefault("auth", {})
    data.setdefault("server", {})
    data["auth"].setdefault("username", "admin")
    data["auth"].setdefault("password", "123456")
    data["auth"].setdefault("secret_key", "cpipe-capacity-planner-change-me")
    data["server"].setdefault("host", "0.0.0.0")
    data["server"].setdefault("port", DEFAULT_PORT)
    return data


def _same_text(left: str, right: str) -> bool:
    a = str(left).encode("utf-8")
    b = str(right).encode("utf-8")
    if len(a) != len(b):
        secrets.compare_digest(a, a)
        return False
    return secrets.compare_digest(a, b)


def template_url_for(endpoint: str, **values: str) -> str:
    if endpoint == "static":
        filename = str(values.get("filename") or "").lstrip("/")
        return f"/static/{filename}"
    routes = {
        "login": "/login",
        "login_post": "/login",
        "logout": "/logout",
        "evaluate_page": "/",
        "preview_page": "/preview",
        "admin_page": "/admin",
    }
    return routes[endpoint]


class AuthRequired(Exception):
    pass


class NoStoreMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers") or [])
                headers.append((b"cache-control", b"no-store, no-cache, must-revalidate, max-age=0"))
                headers.append((b"pragma", b"no-cache"))
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_wrapper)


cfg = load_config()
app = FastAPI()
app.add_middleware(
    SessionMiddleware,
    secret_key=str(cfg["auth"]["secret_key"]),
    max_age=None,
    same_site="lax",
    https_only=False,
)
app.add_middleware(NoStoreMiddleware)

templates = Jinja2Templates(directory=str(ROOT / "templates"))
templates.env.auto_reload = True
templates.env.globals["url_for"] = template_url_for
app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")


def render(request: Request, name: str, context: dict | None = None, status_code: int = 200):
    return templates.TemplateResponse(request, name, context or {}, status_code=status_code)


def require_user(request: Request) -> str:
    user = request.session.get("user")
    if not user:
        raise AuthRequired()
    return str(user)


@app.exception_handler(AuthRequired)
async def auth_required(request: Request, _exc: AuthRequired):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"ok": False, "error": "Not signed in"}, status_code=401)
    return RedirectResponse(f"/login?next={request.url.path}", status_code=302)


async def read_json(request: Request) -> dict:
    raw = await request.body()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def evaluate_rows(rows: list, full: bool = False) -> list:
    catalog = load_catalog()
    hardwares = hw_map(catalog)
    algos = algo_map(catalog)
    results = []
    for row in rows or []:
        computed = calculate(hardwares.get(row.get("hwId")), algos, row)
        payload = computed if full else public_result(computed)
        payload["id"] = row.get("id")
        if full and computed.get("ok"):
            payload["detail"] = admin_detail(computed)
        results.append(payload)
    return results


@app.get("/")
def evaluate_page(request: Request):
    return render(request, "evaluate.html")


@app.get("/preview")
def preview_page(request: Request):
    return render(request, "preview.html")


@app.get("/login")
def login(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/admin", status_code=302)
    return render(request, "login.html", {"error": "", "next": request.query_params.get("next") or "/admin"})


@app.post("/login")
async def login_post(request: Request):
    auth = load_config()["auth"]
    form = await request.form()
    username = str(form.get("username") or "").strip()
    password = str(form.get("password") or "")
    next_url = str(form.get("next") or "/admin")
    if not next_url.startswith("/"):
        next_url = "/admin"
    if _same_text(username, str(auth["username"])) and _same_text(password, str(auth["password"])):
        request.session["user"] = username
        return RedirectResponse(next_url, status_code=302)
    return render(request, "login.html", {"error": "Invalid username or password", "next": next_url}, status_code=401)


@app.post("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=302)


@app.get("/admin")
def admin_page(request: Request):
    user = require_user(request)
    return render(request, "admin.html", {"user": user})


@app.get("/api/catalog")
def api_catalog():
    return {"ok": True, **public_catalog()}


@app.post("/api/evaluate")
async def api_evaluate(request: Request):
    body = await read_json(request)
    return {"ok": True, "results": evaluate_rows(body.get("rows") or [], full=False)}


@app.get("/api/admin/catalog")
def api_admin_catalog(request: Request):
    require_user(request)
    return {"ok": True, **load_catalog()}


@app.put("/api/admin/catalog")
async def api_admin_save_catalog(request: Request):
    require_user(request)
    body = await read_json(request)
    try:
        saved = save_catalog(body)
    except ValueError as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
    return {"ok": True, **saved}


@app.post("/api/admin/reset")
def api_admin_reset(request: Request):
    require_user(request)
    saved = save_catalog(default_catalog())
    return {"ok": True, **saved}


@app.post("/api/admin/evaluate")
async def api_admin_evaluate(request: Request):
    require_user(request)
    body = await read_json(request)
    return {"ok": True, "results": evaluate_rows(body.get("rows") or [], full=True)}


def main() -> None:
    import uvicorn

    load_catalog()
    server = load_config()["server"]
    print(f"CPipe planner config: {DATA_DIR}")
    uvicorn.run(app, host=str(server["host"]), port=int(server["port"]))
