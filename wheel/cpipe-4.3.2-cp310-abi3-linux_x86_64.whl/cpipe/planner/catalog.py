"""Hardware / algorithm catalog stored as JSON."""

from __future__ import annotations

import json
from pathlib import Path

from .calculator import hw_streams

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_CATALOG_PATH = PACKAGE_DIR / "default_catalog.json"
DATA_DIR = Path.home() / ".cpipe" / "planner"
CATALOG_PATH = DATA_DIR / "catalog.json"


def default_catalog() -> dict:
    with DEFAULT_CATALOG_PATH.open("r", encoding="utf-8") as f:
        return _validate(json.load(f))


def _validate(data: dict) -> dict:
    hardware = data.get("hardware")
    algos = data.get("algos")
    if not isinstance(hardware, list) or not isinstance(algos, list):
        raise ValueError("catalog must include hardware and algos lists")
    if not hardware or not algos:
        raise ValueError("Keep at least one hardware item and one algorithm")
    return {"hardware": hardware, "algos": algos}


def load_catalog() -> dict:
    if not CATALOG_PATH.exists():
        data = default_catalog()
        save_catalog(data)
        return data
    with CATALOG_PATH.open("r", encoding="utf-8") as f:
        return _validate(json.load(f))


def save_catalog(data: dict) -> dict:
    clean = _validate(data)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CATALOG_PATH.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(clean, f, ensure_ascii=False, indent=2)
    tmp.replace(CATALOG_PATH)
    return clean


def public_catalog(data: dict | None = None) -> dict:
    catalog = data or load_catalog()
    return {
        "hardware": [
            {"id": h.get("id"), "name": h.get("name"), "maxStreams": hw_streams(h), "vramGb": h.get("vramGb")}
            for h in catalog["hardware"]
        ],
        "algos": [
            {"id": a.get("id"), "name": a.get("name"), "defaultFps": a.get("defaultFps", 1)}
            for a in catalog["algos"]
        ],
    }


def algo_map(catalog: dict | None = None) -> dict:
    catalog = catalog or load_catalog()
    return {a["id"]: a for a in catalog["algos"] if a.get("id")}


def hw_map(catalog: dict | None = None) -> dict:
    catalog = catalog or load_catalog()
    return {h["id"]: h for h in catalog["hardware"] if h.get("id")}
