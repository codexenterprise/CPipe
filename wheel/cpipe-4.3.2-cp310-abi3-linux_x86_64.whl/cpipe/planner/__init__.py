"""Standalone capacity planner web app. Start with `python -m cpipe.planner`."""
