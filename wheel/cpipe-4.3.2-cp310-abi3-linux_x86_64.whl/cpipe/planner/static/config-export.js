// Fill the Artifact Tool-authored workbook template; JSZip only handles the XLSX archive.
(function () {
  'use strict';
  const ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  function writeCell(cell, value, formula) {
    if (!cell) throw Error('Missing template cell');
    const numeric = typeof value === 'number';
    if (numeric && !Number.isFinite(value)) throw Error('Invalid number');
    const text = String(value).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]/g, '');
    if (text.length > 32767) throw Error('Excel cell text limit exceeded');
    cell.replaceChildren();
    cell.setAttribute('t', numeric ? 'n' : 'inlineStr');
    if (formula) {
      const node = cell.ownerDocument.createElementNS(ns, 'x:f');
      node.textContent = formula; cell.append(node);
    }
    const node = cell.ownerDocument.createElementNS(ns, numeric ? 'x:v' : 'x:is');
    if (numeric) node.textContent = text;
    else {
      const content = cell.ownerDocument.createElementNS(ns, 'x:t');
      content.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve');
      content.textContent = text; node.append(content);
    }
    cell.append(node);
  }
  window.createConfigWorkbook = async function (report) {
    const t = (key, values) => I18n.t(key, values, report.locale);
    if (!report.algorithms.length || report.algorithms.length > 1048572) throw Error('Invalid algorithm row count');
    const response = await fetch('/static/config-template.xlsx?v=3', { signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw Error('Template unavailable');
    const zip = await JSZip.loadAsync(await response.arrayBuffer());
    const parser = new DOMParser();
    const serializer = new XMLSerializer();
    const summary = parser.parseFromString(await zip.file('xl/worksheets/sheet1.xml').async('string'), 'application/xml');
    const algorithms = parser.parseFromString(await zip.file('xl/worksheets/sheet2.xml').async('string'), 'application/xml');
    for (const [sheet, labels] of [[summary, { A1: '配置清单', A3: '项目', B3: '配置', C3: '单位' }], [algorithms, { A1: '识别任务明细', A3: '序号', B3: '识别任务', C3: '每秒分析帧数' }]]) {
      for (const [cell, key] of Object.entries(labels)) writeCell(sheet.querySelector(`[r="${cell}"]`), t(key));
    }
    const addresses = Object.fromEntries(report.fields.map(([key], index) => [key, 'B' + (index + 4)]));
    const formulas = {
      quantity: addresses.target ? `ROUNDUP(${addresses.target}/${addresses.capacity},0)` : '',
      total: `${addresses.quantity}*${addresses.capacity}`
    };
    function fillRows(sheet, rows, rowFormulas = []) {
      const data = sheet.getElementsByTagNameNS(ns, 'sheetData')[0];
      const model = data.querySelector('[r="4"]').cloneNode(true);
      Array.from(data.children).filter((row) => Number(row.getAttribute('r')) >= 4).forEach((row) => row.remove());
      rows.forEach((values, index) => {
        const row = model.cloneNode(true);
        row.setAttribute('r', index + 4);
        row.setAttribute('ht', Math.min(409, Math.max(32, Math.ceil(String(values[1]).length / 45) * 20)));
        Array.from(row.children).forEach((cell, column) => {
          cell.setAttribute('r', 'ABC'[column] + (index + 4));
          cell.setAttribute('s', model.children[typeof values[column] === 'number' ? (sheet === summary ? 2 : column) : 1].getAttribute('s'));
          writeCell(cell, values[column], column === 1 ? rowFormulas[index] : '');
        });
        data.append(row);
      });
      sheet.querySelector('dimension')?.setAttribute('ref', `A1:C${rows.length + 3}`);
    }
    fillRows(summary, report.fields.map(([, ...values]) => values), report.fields.map(([key]) => formulas[key] || ''));
    fillRows(algorithms, report.algorithms);
    zip.file('xl/worksheets/sheet1.xml', serializer.serializeToString(summary));
    zip.file('xl/worksheets/sheet2.xml', serializer.serializeToString(algorithms));
    const workbook = parser.parseFromString(await zip.file('xl/workbook.xml').async('string'), 'application/xml');
    Array.from(workbook.getElementsByTagNameNS(ns, 'sheet')).forEach((sheet, index) => sheet.setAttribute('name', t(index === 0 ? '配置清单' : '识别任务明细')));
    zip.file('xl/workbook.xml', serializer.serializeToString(workbook));
    return zip.generateAsync({ type: 'blob', compression: 'DEFLATE', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  };
})();
