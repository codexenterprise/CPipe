(function () {
  'use strict';
  // Source copy is Chinese; custom catalog names are preserved verbatim.
  const en = {
  "视频分析设备选型 · Code_X": "Video Analytics Hardware Selector · Code_X",
  "视频分析设备选型": "Video analytics hardware selector",
  "跳到配置内容": "Skip to requirements",
  "语言": "Language",
  "填写视频数量和识别需求，查看需要的设备。": "Enter your video streams and analysis tasks to find the equipment you need.",
  "已有设备，查看支持路数": "Already have a device? Check its capacity",
  "需要采购，按视频数量选设备": "Buying equipment? Enter your stream count",
  "选择已有设备和识别任务，查看支持的视频路数。": "Select your device and analysis tasks to see how many streams it supports.",
  "填写需求": "Your requirements",
  "需要分析多少路视频？": "How many video streams need analysis?",
  "你已有哪款设备？": "Which device do you have?",
  "正在加载设备…": "Loading devices…",
  "填写需要接入的路数": "Enter the number of streams",
  "请选择设备": "Select a device",
  "路": "streams",
  "路视频": "video streams",
  "{count} 路": "{count} streams",
  "{count} 路视频": "{count} video streams",
  "视频数量": "Video streams",
  "需要识别什么？": "What do you need to identify?",
  "识别任务": "Analysis task",
  "每秒分析帧数": "Frames analyzed per second",
  "帧": "frames",
  "{fps} 帧/秒": "{fps} FPS",
  "添加识别任务": "Add analysis task",
  "已添加的识别任务": "Added analysis tasks and frame rates",
  "可添加的识别任务": "Available analysis tasks",
  "添加需要的识别任务，每项可以单独设置分析频率。": "Add an analysis task. Set the analysis rate for each task.",
  "添加 {name}": "Add {name}",
  "{name}每秒分析帧数，第 {index} 项": "{name} frames per second, instance {index}",
  "删除第 {index} 项 {name}": "Delete instance {index}: {name}",
  "这里设置分析频率，不是摄像头拍摄帧率。": "This is the analysis rate, not the camera's recording frame rate.",
  "以上识别任务应用于全部 {count} 路视频。": "These tasks apply to all {count} video streams.",
  "所有视频使用以上识别任务。": "All video streams use these analysis tasks.",
  "CPU 与内存说明": "CPU and memory guidance",
  "独立显卡主机": "Hosts with discrete GPUs",
  "CPU：总物理核心数不少于视频路数的一半（向下取整），且最低 8 核；主频不低于 2.6 GHz。": "CPU: at least half the video stream count in physical cores, rounded down, with a minimum of 8 cores; clock speed at least 2.6 GHz.",
  "内存：至少 32 GB，且大于所用显卡总显存的 1.5 倍。": "Memory: at least 32 GB and greater than 1.5 times the total VRAM of the GPUs used.",
  "视频路数按实际计划接入量，不代入设备最大支持路数。": "Use the actual planned stream count, not the device's maximum capacity.",
  "边缘设备（如 Orin NX 16G）": "Edge devices (such as Orin NX 16G)",
  "CPU 和内存由所购整机规格决定，不套用上述主机公式。": "CPU and memory depend on the purchased system's specifications. The host rules above do not apply.",
  "请输入大于 0 的整数视频路数": "Enter a positive whole number of video streams.",
  "请添加至少一项识别任务": "Add at least one analysis task.",
  "每秒分析帧数须为大于或等于 0 的数字": "Enter a valid analysis rate of 0 or greater.",
  "查看所需设备": "Find equipment",
  "查看支持路数": "Check stream capacity",
  "重新计算": "Recalculate",
  "正在计算…": "Calculating…",
  "设备选型结果": "Equipment results",
  "满足 {count} 路视频的设备": "Equipment for {count} video streams",
  "这款设备能分析多少路视频？": "How many streams can this device analyze?",
  "选择一种设备，生成配置清单。": "Select a device to create your configuration.",
  "使用当前识别任务与分析频率。": "Using your current tasks and analysis rates.",
  "需求已修改，请重新计算。": "Requirements changed. Recalculate to update the results.",
  "计算完成后将在这里显示结果。": "Your results will appear here when the calculation is complete.",
  "点击“重新计算”更新设备结果。": "Select Recalculate to update the equipment results.",
  "正在加载设备与识别任务…": "Loading devices and analysis tasks…",
  "暂时无法获取结果": "Results are currently unavailable",
  "正在匹配设备": "Finding suitable equipment",
  "填写需求，查看设备": "Enter your requirements to find equipment",
  "设备型号": "Device model",
  "设备类型": "Device type",
  "每张 / 台支持": "Streams per card / unit",
  "需要数量": "Quantity needed",
  "独立显卡": "Discrete GPU",
  "边缘设备": "Edge device",
  "选择 {name}": "Select {name}",
  "计算失败，请重新计算": "Calculation failed. Please recalculate.",
  "目标路数过大，请缩小后重试": "The stream count is too large. Enter a smaller number.",
  "显存不足，无法运行这组识别任务": "Not enough device memory for these tasks",
  "无法支持当前识别任务与分析频率": "Cannot support these tasks at the current analysis rates",
  "部分设备计算失败，可点击“重新计算”重试。": "Some devices could not be evaluated. Select Recalculate to retry.",
  "每台设备可分析": "Each device can analyze",
  "每张显卡可分析": "Each GPU card can analyze",
  "已选设备": "Selected equipment",
  "请选择一种设备，再复制或导出配置。": "Select a device to copy or export its configuration.",
  "完成计算后，可复制或导出设备配置。": "Calculate to copy or export your equipment configuration.",
  "导出配置清单": "Export configuration",
  "复制配置信息": "Copy configuration",
  "设备数量": "Device count",
  "每台支持路数": "Streams per device",
  "每张支持路数": "Streams per GPU card",
  "合计支持路数": "Total stream capacity",
  "配置清单": "Hardware configuration",
  "识别任务明细": "Analysis tasks",
  "项目": "Item",
  "配置": "Configuration",
  "单位": "Unit",
  "序号": "Instance",
  "算法": "Analysis task",
  "{label}：{value}": "{label}: {value}",
  "请手动复制配置信息": "Copy configuration manually",
  "浏览器未允许自动复制，文本已全选，请按 Ctrl+C / ⌘C 复制。": "Your browser blocked automatic copying. The text is selected; press Ctrl+C / ⌘C to copy.",
  "完整配置信息": "Full configuration details",
  "关闭": "Close",
  "已复制配置信息。": "Configuration copied.",
  "正在生成 Excel 配置清单…": "Generating the Excel configuration…",
  "需求或语言已变更，请重新导出。": "Requirements or language changed. Please export again.",
  "Excel 配置清单已生成，请在浏览器下载中查看。": "Excel configuration generated. Check your browser downloads.",
  "Excel 导出失败，请重试；也可先复制配置信息。": "Excel export failed. Try again or copy the configuration.",
  "浏览器无法保存输入，刷新后可能丢失本次修改。": "This browser cannot save your input. Changes may be lost after refreshing.",
  "计算结果暂不可用，请重新计算。": "The result is unavailable. Please recalculate.",
  "暂时无法连接计算服务，请重新计算。": "Cannot connect to the calculation service. Please try again.",
  "设备与识别任务加载失败，请检查网络后重试。": "Could not load devices and analysis tasks. Check your connection and retry.",
  "重新加载": "Reload",
  "列表加载完成后即可开始。": "You can start once the lists have loaded.",
  "登录 · 参数管理": "Sign in · Settings",
  "参数管理登录": "Settings login",
  "账号密码在本机": "Change username and password in local ",
  "中修改，改完需重启服务。": ", then restart the service.",
  "用户名或密码错误": "Invalid username or password",
  "用户名": "Username",
  "密码": "Password",
  "登录": "Sign in",
  "返回评估页": "Back to planner",
  "参数管理 · CPipe 设备选型": "Catalog · CPipe Capacity Planner",
  "参数与公式": "Catalog & formulas",
  "当前登录：": "Signed in as ",
  "。硬件和算法参数保存在": ". Hardware and algorithm parameters are stored in ",
  "，修改后评估页立即生效。": ", and the planner uses them immediately.",
  "恢复默认": "Restore defaults",
  "退出登录": "Sign out",
  "参数库": "Parameter catalog",
  "修改会自动保存": "Changes save automatically",
  "硬件": "Hardware",
  "+ 新增硬件": "+ Add hardware",
  "名称": "Name",
  "显存 GB": "VRAM GB",
  "单路解码 MB": "Decode MB / stream",
  "解码上限": "Decode limit",
  "检测算力 FPS": "Detection FPS",
  "解码上限为自动时：": "When decode limit is Auto: ",
  "，例如 24G / 400M = 60 路。Orin NX 固定为 10 路。": ", e.g. 24G / 400M = 60 streams. Orin NX uses Fixed 10.",
  "+ 新增算法": "+ Add algorithm",
  "折合检测": "Detection equiv.",
  "默认 FPS": "Default FPS",
  "折合检测仅用于算力计算。多选时显存与算力叠加（若模型共享主干则偏保守）。": "Detection equivalent is used only for compute. Multi-select stacks VRAM and compute (conservative if models share a backbone).",
  "计算公式": "Formulas",
  "显存限制": "VRAM limit",
  "算力限制": "Compute limit",
  "解码限制": "Decode limit",
  "= 本页硬件的解码上限（自动或固定）": "= hardware decode limit on this page (auto or fixed)",
  "结果": "Result",
  "默认算力：3090 = 170 检测 FPS，L4 = 150，Orin NX 16G = 40。默认解码：每路 400MB。账号密码在": "Default compute: 3090 = 170 detection FPS, L4 = 150, Orin NX 16G = 40. Default decode: 400MB per stream. Change credentials in ",
  "中修改，改完需重启。": "and restart.",
  "自动": "Auto",
  "固定": "Fixed",
  "删除": "Del",
  "当前 {count} 路（{vram}G/{decode}M）": "Now {count} streams ({vram}G/{decode}M)",
  "当前 {count} 路": "Now {count} streams",
  "正在保存…": "Saving…",
  "保存失败": "Save failed",
  "已保存": "Saved",
  "已恢复默认": "Defaults restored",
  "至少保留一项硬件": "Keep at least one hardware item",
  "至少保留一项算法": "Keep at least one algorithm",
  "确定恢复默认的硬件和算法参数吗？评估页将使用新的参数。": "Restore default hardware and algorithm parameters? The planner will use the new values.",
  "新硬件": "New hardware",
  "新算法": "New algorithm"
};
  const storageKey = 'cpipe-capacity-planner-language';
  function initialLocale() {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved === 'zh' || saved === 'en') return saved;
    } catch { /* Language selection still works without storage. */ }
    try {
      const preferred = navigator.languages?.[0] || navigator.language;
      return typeof preferred === 'string' && new Intl.Locale(preferred).language === 'zh' ? 'zh' : 'en';
    } catch { return 'en'; }
  }
  let locale = initialLocale();
  function t(key, values = {}, language = locale) {
    const message = language === 'zh' ? key : en[key] ?? key;
    return String(message ?? '').replace(/\{(\w+)\}/g, (match, name) => Object.hasOwn(values, name) ? String(values[name]) : match);
  }
  function apply() {
    document.documentElement.lang = locale === 'zh' ? 'zh-CN' : 'en';
    document.querySelectorAll('[data-i18n]').forEach((element) => { element.textContent = t(element.dataset.i18n); });
    for (const attribute of ['aria-label', 'placeholder']) {
      document.querySelectorAll(`[data-i18n-${attribute}]`).forEach((element) => element.setAttribute(attribute, t(element.getAttribute(`data-i18n-${attribute}`))));
    }
    const select = document.getElementById('languageSelect');
    if (select) select.value = locale;
  }
  window.I18n = {
    t, apply,
    algorithmName(name) {
      const names = {
        'Detection': '目标检测', 'Detection + Classification': '目标检测与分类',
        'Intrusion': '区域入侵检测', 'Smoking': '吸烟识别', 'Phone Usage': '手机使用识别',
        'Helmet & Vest': '安全帽与反光衣识别', 'Face Recognition': '人脸识别'
      };
      return locale === 'zh' ? names[name] || name : name;
    },
    get locale() { return locale; },
    unit(edge, count) { return locale === 'zh' ? (edge ? '台' : '张') : (edge ? 'unit' : 'card') + (count === 1 ? '' : 's'); },
    setLocale(value) {
      if (value !== 'zh' && value !== 'en') return;
      locale = value;
      try { localStorage.setItem(storageKey, value); } catch { /* Session-only preference. */ }
      apply();
    }
  };
})();
