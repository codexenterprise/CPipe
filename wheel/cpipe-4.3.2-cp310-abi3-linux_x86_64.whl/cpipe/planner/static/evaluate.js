(function () {
  'use strict';
  const { t } = window.I18n;
  const STORAGE_KEY = 'cpipe-capacity-planner-demand-v4';
  const state = { hardware: [], algos: [], row: null, result: null, phase: 'empty', request: null, revision: 0, exporting: false, noticeKey: '', loadFailed: false, hasCalculated: false };
  const $ = (id) => document.getElementById(id);
  const current = () => state.row;
  const algorithm = (id) => state.algos.find((a) => a.id === id);
  const hardware = (id) => state.hardware.find((h) => h.id === id);
  const isSizing = (row = current()) => row?.mode !== 'capacity';
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const tr = (key, values) => esc(t(key, values));
  const validFps = (value) => (typeof value === 'string' || typeof value === 'number') && String(value).trim() !== '' && Number.isFinite(Number(value)) && Number(value) >= 0;
  const validCameras = (value) => validFps(value) && Number.isSafeInteger(Number(value)) && Number(value) > 0;
  const isEdgeDevice = (device) => device?.id === 'orin-nx-16g';
  const taskName = (id) => I18n.algorithmName(algorithm(id)?.name || '');
  function notice(message) {
    state.noticeKey = message;
    $('notice').textContent = t(message);
    $('notice').hidden = !message;
  }
  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(current())); }
    catch { notice('浏览器无法保存输入，刷新后可能丢失本次修改。'); }
  }
  function loadDemand() {
    let saved;
    try {
      saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      // Keep the complete legacy collection untouched; carry only its first demand into the new screen.
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) saved = JSON.parse(localStorage.getItem('cpipe-capacity-planner-rows-v3'))?.[0];
    } catch { /* A fresh demand is still usable if storage is blocked or malformed. */ }
    state.row = {
      mode: saved ? (isSizing(saved) && saved.mode ? 'sizing' : 'capacity') : 'sizing',
      hwId: hardware(saved?.hwId) ? saved.hwId : state.hardware[0].id,
      selectedHwId: hardware(saved?.selectedHwId) ? saved.selectedHwId : '',
      cameras: validCameras(saved?.cameras) ? Number(saved.cameras) : '',
      algos: (Array.isArray(saved?.algos) ? saved.algos : []).filter((a) => a && algorithm(a.id))
        .map((a) => ({ id: a.id, fps: validFps(a.fps) ? Number(a.fps) : '' }))
    };
  }
  function rowError(row = current()) {
    if (!row) return '';
    if (isSizing(row) && !validCameras(row.cameras)) return '请输入大于 0 的整数视频路数';
    if (!isSizing(row) && !hardware(row.hwId)) return '请选择设备';
    if (!row.algos.length) return '请添加至少一项识别任务';
    if (row.algos.some((a) => !validFps(a.fps))) return '每秒分析帧数须为大于或等于 0 的数字';
    return '';
  }
  function renderScope() {
    const row = current();
    $('taskScope').textContent = t(isSizing(row) && validCameras(row.cameras) ? '以上识别任务应用于全部 {count} 路视频。' : '所有视频使用以上识别任务。', { count: row?.cameras });
  }
  function renderAlgorithms() {
    $('algorithmRows').innerHTML = current().algos.map((a, index) => {
      const name = taskName(a.id);
      return '<div class="algorithm-row">' +
        '<label for="fps-' + index + '">' + esc(name) + '</label>' +
        '<input id="fps-' + index + '" type="number" min="0" step="0.1" inputmode="decimal" value="' + esc(a.fps) + '" data-fps="' + index + '" aria-label="' + tr('{name}每秒分析帧数，第 {index} 项', { name, index: index + 1 }) + '" aria-invalid="' + !validFps(a.fps) + '" />' +
        '<span class="fps-unit">' + tr('帧') + '</span>' +
        '<button type="button" class="button remove-algorithm" data-remove-algo="' + index + '" aria-label="' + tr('删除第 {index} 项 {name}', { index: index + 1, name }) + '"><svg aria-hidden="true"><use href="#icon-trash"/></svg></button></div>';
    }).join('') || '<p class="empty-hint">' + tr('添加需要的识别任务，每项可以单独设置分析频率。') + '</p>';
    $('algorithmOptions').innerHTML = state.algos.map((a) => '<button type="button" data-add-algo="' + esc(a.id) + '" aria-label="' + tr('添加 {name}', { name: taskName(a.id) }) + '"><span>' + esc(taskName(a.id)) + '</span><svg aria-hidden="true"><use href="#icon-plus"/></svg></button>').join('');
  }
  function deviceOption(candidate) {
    if (!candidate?.ok || !candidate.hasAlgos || candidate.n <= 0) return null;
    const device = hardware(candidate.hwId);
    if (!device) return null;
    const quantity = isSizing() ? Math.ceil(Number(current().cameras) / candidate.n) : 1;
    if (!Number.isSafeInteger(quantity * candidate.n)) return null;
    return { device, quantity, capacity: candidate.n, unit: I18n.unit(isEdgeDevice(device), quantity) };
  }
  function selectedDevice() {
    if (state.phase !== 'ready' || rowError()) return null;
    return deviceOption(isSizing() ? state.result?.candidates?.find((c) => c.hwId === current().selectedHwId) : state.result);
  }
  function summaryText() {
    const row = current();
    return [...(isSizing() ? [t('{count} 路视频', { count: row.cameras })] : []),
      ...row.algos.map((a) => taskName(a.id) + ' ' + t('{fps} 帧/秒', { fps: a.fps }))].join(' · ');
  }
  function renderExportActions() {
    const selected = selectedDevice();
    $('btnCopyInfo').disabled = !selected;
    $('btnExport').disabled = !selected || state.exporting;
    $('selectedSummary').innerHTML = selected
      ? '<h3>' + tr('已选设备') + '</h3><strong>' + esc(selected.device.name) + ' × ' + selected.quantity + ' ' + esc(selected.unit) + '</strong><p>' + esc(summaryText()) + '</p>'
      : '<p class="selection-empty">' + tr(state.phase === 'ready' && isSizing() ? '请选择一种设备，再复制或导出配置。' : '完成计算后，可复制或导出设备配置。') + '</p>';
  }
  function configReport() {
    const selected = selectedDevice();
    if (!selected) return null;
    return {
      locale: I18n.locale,
      fields: [
        ...(isSizing() ? [['target', t('视频数量'), Number(current().cameras), t('路')]] : []),
        ['device', t('设备型号'), selected.device.name, ''],
        ['quantity', t('设备数量'), selected.quantity, selected.unit],
        ['capacity', t(isEdgeDevice(selected.device) ? '每台支持路数' : '每张支持路数'), selected.capacity, t('路')],
        ...(selected.quantity > 1 ? [['total', t('合计支持路数'), selected.quantity * selected.capacity, t('路')]] : [])
      ],
      algorithms: current().algos.map((a, index) => [index + 1, taskName(a.id), Number(a.fps)])
    };
  }
  $('btnCopyInfo').addEventListener('click', async () => {
    const report = configReport();
    if (!report) return;
    const text = [
      ...report.fields.map(([, label, value, unit]) => t('{label}：{value}', { label, value: `${value}${unit ? ' ' + unit : ''}` })),
      t('识别任务明细'), ...report.algorithms.map(([i, name, fps]) => `${i}. ${t('{label}：{value}', { label: name, value: t('{fps} 帧/秒', { fps }) })}`)
    ].join('\n');
    try {
      if (!navigator.clipboard?.writeText) throw Error('Clipboard unavailable');
      await navigator.clipboard.writeText(text);
      $('exportStatus').textContent = t('已复制配置信息。');
    } catch {
      // LAN HTTP may not expose Clipboard API. Try the native copy command, then offer manual copy.
      const field = document.createElement('textarea');
      field.value = text; field.className = 'clipboard-buffer';
      document.body.append(field); field.select();
      let copied = false;
      try { copied = document.execCommand('copy'); } catch { /* Manual recovery below. */ }
      field.remove(); $('btnCopyInfo').focus();
      if (copied) $('exportStatus').textContent = t('已复制配置信息。');
      else { $('copyText').value = text; $('copyFallback').showModal(); $('copyText').focus(); $('copyText').select(); }
    }
  });
  $('btnExport').addEventListener('click', async () => {
    const report = configReport();
    if (!report) return;
    const signature = JSON.stringify(current());
    const revision = state.revision;
    state.exporting = true; renderExportActions();
    $('exportStatus').textContent = t('正在生成 Excel 配置清单…');
    try {
      const blob = await window.createConfigWorkbook(report);
      if (signature !== JSON.stringify(current()) || revision !== state.revision || report.locale !== I18n.locale) {
        $('exportStatus').textContent = t('需求或语言已变更，请重新导出。'); return;
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = t('配置清单') + '.xlsx';
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      $('exportStatus').textContent = t('Excel 配置清单已生成，请在浏览器下载中查看。');
    } catch {
      $('exportStatus').textContent = t('Excel 导出失败，请重试；也可先复制配置信息。');
    } finally { state.exporting = false; renderExportActions(); }
  });
  function unavailableReason(candidate) {
    if (!candidate?.ok) return '计算失败，请重新计算';
    if (candidate.n > 0) return '目标路数过大，请缩小后重试';
    return candidate.bottleneck === 'Algorithm VRAM exceeds device VRAM' ? '显存不足，无法运行这组识别任务' : '无法支持当前识别任务与分析频率';
  }
  function renderResult() {
    const row = current();
    const ready = state.phase === 'ready';
    const loading = state.phase === 'loading';
    $('result').setAttribute('aria-busy', String(loading));
    $('result').className = state.phase === 'error' ? 'result-error' : '';
    $('resultHeading').textContent = t(isSizing() ? (ready ? '满足 {count} 路视频的设备' : '设备选型结果') : '这款设备能分析多少路视频？', { count: row?.cameras });
    $('resultStatus').textContent = t(loading ? '正在计算…' : state.phase === 'dirty' ? '需求已修改，请重新计算。' : ready ? (isSizing() ? '选择一种设备，生成配置清单。' : '使用当前识别任务与分析频率。') : '');
    $('btnCalculate').disabled = !row || loading;
    $('btnCalculate').textContent = t(loading ? '正在计算…' : state.hasCalculated ? '重新计算' : isSizing() ? '查看所需设备' : '查看支持路数');
    $('btnCalculate').classList.toggle('primary', !ready);
    $('inputStatus').textContent = row && state.phase !== 'empty' ? t(rowError()) : '';
    if (!ready) {
      const message = state.phase === 'error' ? state.result.error : loading ? '计算完成后将在这里显示结果。' : rowError() || '点击“重新计算”更新设备结果。';
      $('result').innerHTML = '<div class="empty-hint result-placeholder"><strong>' + tr(!row ? '正在加载设备与识别任务…' : state.phase === 'error' ? '暂时无法获取结果' : loading ? '正在匹配设备' : '填写需求，查看设备') + '</strong>' + tr(message) + '</div>';
    } else if (isSizing()) {
      $('result').innerHTML = '<table class="candidate-table"><thead><tr><th scope="col">' + tr('设备型号') + '</th><th scope="col">' + tr('设备类型') + '</th><th scope="col">' + tr('每张 / 台支持') + '</th><th scope="col">' + tr('需要数量') + '</th></tr></thead><tbody>' +
        state.result.candidates.map((candidate) => {
          const device = hardware(candidate.hwId);
          const selected = deviceOption(candidate);
          const checked = selected && row.selectedHwId === device.id;
          return '<tr class="candidate' + (checked ? ' selected' : '') + '" data-hardware="' + esc(device.id) + '">' +
            '<td><label class="candidate-choice"><input type="radio" name="selectedHardware" value="' + esc(device.id) + '" aria-label="' + tr('选择 {name}', { name: device.name }) + '"' + (checked ? ' checked' : '') + (selected ? '' : ' disabled') + '/><span>' + esc(device.name) + '</span></label></td>' +
            '<td>' + tr(isEdgeDevice(device) ? '边缘设备' : '独立显卡') + '</td>' +
            (selected ? '<td class="candidate-capacity">' + tr('{count} 路', { count: selected.capacity }) + '</td><td><span class="device-count" data-quantity="' + selected.quantity + '">' + selected.quantity + ' ' + esc(selected.unit) + '</span></td>'
              : '<td colspan="2" class="candidate-unavailable">' + tr(unavailableReason(candidate)) + '</td>') + '</tr>';
        }).join('') + '</tbody></table>';
      if (state.result.candidates.some((c) => !c.ok)) $('resultStatus').textContent = t('部分设备计算失败，可点击“重新计算”重试。');
    } else {
      const device = hardware(row.hwId);
      $('result').innerHTML = '<p class="capacity-device">' + esc(device.name) + '</p><p class="capacity-note">' + tr(isEdgeDevice(device) ? '每台设备可分析' : '每张显卡可分析') + '</p><div class="capacity"><strong>' + state.result.n + '</strong><span>' + tr('路视频') + '</span></div>' +
        (state.result.n === 0 ? '<p class="candidate-unavailable">' + tr(unavailableReason(state.result)) + '</p>' : '');
    }
    renderExportActions();
  }
  function renderEditor() {
    const row = current();
    $('hardware').value = row.hwId;
    $('targetCameras').value = row.cameras;
    $('targetCameras').setAttribute('aria-invalid', String(state.phase !== 'empty' && !validCameras(row.cameras)));
    $('hardwareSection').hidden = isSizing();
    $('cameraSection').hidden = !isSizing();
    $('modeIntro').textContent = t(isSizing() ? '填写视频数量和识别需求，查看需要的设备。' : '选择已有设备和识别任务，查看支持的视频路数。');
    $('modeSwitch').textContent = t(isSizing() ? '已有设备，查看支持路数' : '需要采购，按视频数量选设备');
    $('modeSwitch').dataset.mode = isSizing() ? 'capacity' : 'sizing';
    $('algoPicker').open = false;
    renderAlgorithms();
    renderScope();
    renderResult();
  }
  function invalidate() {
    state.request?.abort();
    state.revision++;
    state.phase = 'dirty';
    state.result = null;
    current().selectedHwId = '';
    $('exportStatus').textContent = '';
    $('copyFallback').close();
    renderScope();
    persist();
    renderResult();
  }
  async function getJson(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) throw Error('HTTP failure');
    const data = await response.json();
    if (!data?.ok) throw Error('API failure');
    return data;
  }
  async function evaluate() {
    state.request?.abort();
    const revision = ++state.revision;
    $('copyFallback').close();
    $('exportStatus').textContent = '';
    state.result = null;
    if (rowError()) {
      state.phase = 'dirty';
      renderResult();
      return;
    }
    state.phase = 'loading';
    state.hasCalculated = true;
    persist();
    renderResult();
    const rows = (isSizing() ? state.hardware : [hardware(current().hwId)]).map((hw, index) => ({
      id: String(index), hwId: hw.id, algos: current().algos.map((a) => ({ id: a.id, fps: Number(a.fps) }))
    }));
    const controller = new AbortController();
    state.request = controller;
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
      const data = await getJson('/api/evaluate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows }), signal: controller.signal
      });
      if (revision !== state.revision) return;
      if (!Array.isArray(data.results)) throw Error('Missing results');
      const results = rows.map((query) => {
        const matching = data.results.filter((r) => r?.id === query.id);
        const result = matching[0];
        const valid = matching.length === 1 && result?.ok === true && result.hasAlgos === true && Number.isSafeInteger(result.n) && result.n >= 0;
        return { ...(valid ? result : { ok: false }), hwId: query.hwId };
      });
      state.result = isSizing() ? { candidates: results } : results[0];
      state.phase = !isSizing() && !state.result.ok ? 'error' : 'ready';
      if (state.phase === 'error') state.result.error = '计算结果暂不可用，请重新计算。';
    } catch {
      if (revision !== state.revision) return;
      state.phase = 'error';
      state.result = { error: '暂时无法连接计算服务，请重新计算。' };
    } finally {
      clearTimeout(timeout);
      if (revision === state.revision) renderResult();
    }
  }
  $('btnCalculate').addEventListener('click', evaluate);
  $('hardware').addEventListener('change', () => { current().hwId = $('hardware').value; invalidate(); });
  $('modeSwitch').addEventListener('click', () => {
    if (isSizing() && current().selectedHwId) current().hwId = current().selectedHwId;
    current().mode = isSizing() ? 'capacity' : 'sizing';
    invalidate();
    renderEditor();
  });
  $('targetCameras').addEventListener('input', () => {
    current().cameras = $('targetCameras').value;
    $('targetCameras').setAttribute('aria-invalid', String(!validCameras(current().cameras)));
    invalidate();
  });
  $('algorithmRows').addEventListener('input', (event) => {
    if (!event.target.matches('[data-fps]')) return;
    const item = current().algos[Number(event.target.dataset.fps)];
    if (!item) return;
    item.fps = event.target.value;
    event.target.setAttribute('aria-invalid', String(!validFps(item.fps)));
    invalidate();
  });
  $('algorithmRows').addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove-algo]');
    if (!button) return;
    const index = Number(button.dataset.removeAlgo);
    if (!Number.isInteger(index) || index < 0 || index >= current().algos.length) return;
    current().algos.splice(index, 1);
    renderAlgorithms();
    ($('algorithmRows').querySelectorAll('input')[Math.min(index, current().algos.length - 1)] || $('algoPicker').querySelector('summary')).focus();
    invalidate();
  });
  $('algorithmOptions').addEventListener('click', (event) => {
    const id = event.target.closest('[data-add-algo]')?.dataset.addAlgo;
    const algo = algorithm(id);
    if (!algo) return;
    current().algos.push({ id, fps: validFps(algo.defaultFps) ? Number(algo.defaultFps) : '' });
    renderAlgorithms();
    $('algoPicker').open = false;
    $('algorithmRows').lastElementChild.querySelector('input').focus();
    invalidate();
  });
  for (const id of ['algoPicker', 'hardwareNotes']) {
    $(id).addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { $(id).open = false; $(id).querySelector('summary').focus(); }
    });
  }
  document.addEventListener('click', (event) => {
    for (const id of ['algoPicker', 'hardwareNotes']) {
      if (!$(id).contains(event.target)) $(id).open = false;
    }
  });
  $('result').addEventListener('click', (event) => {
    if (event.target.closest('label, input')) return;
    event.target.closest('.candidate')?.querySelector('input:not(:disabled)')?.click();
  });
  $('result').addEventListener('change', (event) => {
    if (event.target.name !== 'selectedHardware' || state.phase !== 'ready') return;
    current().selectedHwId = event.target.value;
    persist();
    $('result').querySelectorAll('.candidate').forEach((candidate) => candidate.classList.toggle('selected', Boolean(candidate.querySelector('input:checked'))));
    $('exportStatus').textContent = '';
    $('copyFallback').close();
    renderExportActions();
  });
  async function boot() {
    state.loadFailed = false;
    I18n.apply();
    renderResult();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    try {
      const data = await getJson('/api/catalog', { signal: controller.signal });
      for (const key of ['hardware', 'algos']) {
        if (!Array.isArray(data[key]) || !data[key].length || data[key].some((item) => !item || typeof item.id !== 'string' || !item.id || typeof item.name !== 'string') || new Set(data[key].map((item) => item.id)).size !== data[key].length) throw Error('Invalid catalog');
      }
      state.hardware = data.hardware;
      state.algos = data.algos;
      loadDemand();
      $('hardware').innerHTML = state.hardware.map((h) => '<option value="' + esc(h.id) + '">' + esc(h.name) + '</option>').join('');
      $('inputs').disabled = false;
      $('modeSwitch').disabled = false;
      renderEditor();
      if (!rowError()) await evaluate();
    } catch {
      state.loadFailed = true;
      renderLoadError();
    } finally { clearTimeout(timeout); }
  }
  function renderLoadError() {
    notice('设备与识别任务加载失败，请检查网络后重试。');
    const retry = document.createElement('button');
    retry.className = 'button';
    retry.textContent = t('重新加载');
    retry.addEventListener('click', () => { notice(''); boot(); });
    $('notice').append(retry);
    $('result').setAttribute('aria-busy', 'false');
    $('resultStatus').textContent = t('列表加载完成后即可开始。');
  }
  $('languageSelect').addEventListener('change', () => {
    const pickerOpen = $('algoPicker').open;
    const algorithmScroll = $('algorithmRows').scrollTop;
    const resultScroll = $('result').scrollTop;
    I18n.setLocale($('languageSelect').value);
    notice(state.noticeKey);
    $('exportStatus').textContent = '';
    $('copyFallback').close();
    if (current()) {
      renderEditor();
      $('algoPicker').open = pickerOpen;
      $('algorithmRows').scrollTop = algorithmScroll;
      $('result').scrollTop = resultScroll;
    } else if (state.loadFailed) renderLoadError();
    else renderResult();
  });
  boot();
})();
