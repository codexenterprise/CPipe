(function () {
  const state = { hardware: [], algos: [], timer: null };

  const $ = (id) => document.getElementById(id);
  const t = (key, values) => I18n.t(key, values);

  function uid(prefix) {
    return prefix + "-" + Math.random().toString(36).slice(2, 9);
  }

  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }

  function numOr(v, fallback) {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  }

  function findHw(id) {
    return state.hardware.find((h) => h.id === id);
  }

  function findAlgo(id) {
    return state.algos.find((a) => a.id === id);
  }

  function autoStreams(hw) {
    const mb = Number(hw.decodeMb);
    if (!mb || !hw.vramGb) return 0;
    return Math.floor(Number(hw.vramGb) * 1000 / mb);
  }

  function hwStreams(hw) {
    return hw.streamMode === "fixed" ? Number(hw.streamFixed) || 0 : autoStreams(hw);
  }

  function streamHintText(hw) {
    const n = hwStreams(hw);
    return hw.streamMode === "auto"
      ? t("当前 {count} 路（{vram}G/{decode}M）", { count: n, vram: hw.vramGb, decode: hw.decodeMb })
      : t("当前 {count} 路", { count: n });
  }

  function syncAutoStreams(hw) {
    if (hw.streamMode === "auto") hw.streamFixed = autoStreams(hw);
  }

  function syncStreamDisplay(tr, hw) {
    syncAutoStreams(hw);
    const input = tr.querySelector("[data-k='streamFixed']");
    if (input && (hw.streamMode === "auto" || document.activeElement !== input)) {
      input.value = hwStreams(hw);
    }
    const hint = tr.querySelector(".stream-hint");
    if (hint) hint.textContent = streamHintText(hw);
  }

  function setHint(text, ok) {
    const el = $("saveHint");
    el.textContent = text;
    el.className = ok ? "hint save-ok" : "hint";
  }

  function renderHwTable() {
    $("hwTable").querySelector("tbody").innerHTML = state.hardware.map((h) => `
      <tr data-id="${h.id}">
        <td><input type="text" data-k="name" value="${esc(h.name)}" /></td>
        <td><input type="number" min="0" step="0.1" data-k="vramGb" value="${h.vramGb}" /></td>
        <td><input type="number" min="1" step="1" data-k="decodeMb" value="${h.decodeMb}" /></td>
        <td>
          <div style="display:grid;grid-template-columns:78px 1fr;gap:4px">
            <select data-k="streamMode">
              <option value="auto" ${h.streamMode === "auto" ? "selected" : ""}>${t("自动")}</option>
              <option value="fixed" ${h.streamMode === "fixed" ? "selected" : ""}>${t("固定")}</option>
            </select>
            <input type="number" min="0" step="1" data-k="streamFixed" value="${hwStreams(h)}" ${h.streamMode === "auto" ? "disabled" : ""} />
          </div>
          <div class="hint stream-hint">${streamHintText(h)}</div>
        </td>
        <td><input type="number" min="0" step="1" data-k="maxDetectFps" value="${h.maxDetectFps}" /></td>
        <td><button class="btn sm danger" data-act="del-hw">${t("删除")}</button></td>
      </tr>
    `).join("");
  }

  function renderAlgoTable() {
    $("algoTable").querySelector("tbody").innerHTML = state.algos.map((a) => `
      <tr data-id="${a.id}">
        <td><input type="text" data-k="name" value="${esc(a.name)}" /></td>
        <td><input type="number" min="0" step="0.1" data-k="vramGb" value="${a.vramGb}" /></td>
        <td><input type="number" min="0" step="0.1" data-k="equiv" value="${a.equiv}" /></td>
        <td><input type="number" min="0" step="0.1" data-k="defaultFps" value="${a.defaultFps}" /></td>
        <td><button class="btn sm danger" data-act="del-algo">${t("删除")}</button></td>
      </tr>
    `).join("");
  }

  function renderAll() {
    renderHwTable();
    renderAlgoTable();
  }

  async function save(immediate) {
    clearTimeout(state.timer);
    const run = async () => {
      setHint(t("正在保存…"));
      const res = await fetch("/api/admin/catalog", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hardware: state.hardware, algos: state.algos })
      });
      if (res.status === 401) {
        location.href = "/login?next=/admin";
        return;
      }
      const data = await res.json();
      if (!data.ok) {
        setHint(data.error || t("保存失败"));
        return;
      }
      setHint(t("已保存"), true);
    };
    if (immediate) return run();
    state.timer = setTimeout(run, 350);
  }

  function applyCatalog(data) {
    state.hardware = data.hardware || [];
    state.algos = data.algos || [];
    renderAll();
  }

  $("hwTable").addEventListener("input", (e) => {
    const tr = e.target.closest("tr");
    const hw = tr && findHw(tr.dataset.id);
    if (!hw) return;
    const k = e.target.dataset.k;
    if (!k) return;
    if (k === "name") hw.name = e.target.value;
    else hw[k] = numOr(e.target.value, hw[k]);
    if (k === "vramGb" || k === "decodeMb" || k === "streamFixed") {
      syncStreamDisplay(tr, hw);
    }
    save();
  });

  $("hwTable").addEventListener("change", (e) => {
    if (e.target.dataset.k !== "streamMode") return;
    const hw = findHw(e.target.closest("tr").dataset.id);
    hw.streamMode = e.target.value;
    if (hw.streamMode === "fixed") hw.streamFixed = autoStreams(hw) || hw.streamFixed;
    else syncAutoStreams(hw);
    renderHwTable();
    save(true);
  });

  $("hwTable").addEventListener("click", (e) => {
    if (e.target.dataset.act !== "del-hw") return;
    if (state.hardware.length <= 1) return alert(t("至少保留一项硬件"));
    state.hardware = state.hardware.filter((h) => h.id !== e.target.closest("tr").dataset.id);
    renderAll();
    save(true);
  });

  $("algoTable").addEventListener("input", (e) => {
    const tr = e.target.closest("tr");
    const algo = tr && findAlgo(tr.dataset.id);
    if (!algo) return;
    const k = e.target.dataset.k;
    if (k === "name") algo.name = e.target.value;
    else algo[k] = numOr(e.target.value, algo[k]);
    save();
  });

  $("algoTable").addEventListener("click", (e) => {
    if (e.target.dataset.act !== "del-algo") return;
    if (state.algos.length <= 1) return alert(t("至少保留一项算法"));
    state.algos = state.algos.filter((a) => a.id !== e.target.closest("tr").dataset.id);
    renderAll();
    save(true);
  });

  $("btnAddHw").addEventListener("click", () => {
    const hw = {
      id: uid("hw"), name: t("新硬件"), vramGb: 24, decodeMb: 400,
      streamMode: "auto", streamFixed: 60, maxDetectFps: 100
    };
    hw.streamFixed = autoStreams(hw);
    state.hardware.push(hw);
    renderAll();
    save(true);
  });

  $("btnAddAlgo").addEventListener("click", () => {
    state.algos.push({ id: uid("algo"), name: t("新算法"), vramGb: 2, equiv: 1, defaultFps: 1 });
    renderAll();
    save(true);
  });

  $("btnReset").addEventListener("click", async () => {
    if (!confirm(t("确定恢复默认的硬件和算法参数吗？评估页将使用新的参数。"))) return;
    const res = await fetch("/api/admin/reset", { method: "POST" });
    if (res.status === 401) {
      location.href = "/login?next=/admin";
      return;
    }
    applyCatalog(await res.json());
    setHint(t("已恢复默认"), true);
  });

  async function boot() {
    const res = await fetch("/api/admin/catalog");
    if (res.status === 401) {
      location.href = "/login?next=/admin";
      return;
    }
    applyCatalog(await res.json());
  }

  $("languageSelect").addEventListener("change", (e) => {
    I18n.setLocale(e.target.value);
    renderAll();
  });

  I18n.apply();
  boot();
})();
