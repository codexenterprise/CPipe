(function () {
  'use strict';
  const STORAGE_KEY = 'cpipe-capacity-planner-preview-v1';
  const extraEn = {
    '视频与识别任务': 'Video and analysis tasks',
    '选择计算方式': 'Choose calculation method',
    '按视频路数选设备': 'Choose equipment by stream count',
    '计算需要采购的设备数量': 'Calculate the equipment quantity to purchase',
    '查看已有设备容量': 'Check existing device capacity',
    '计算单张 / 台支持的视频路数': 'Calculate streams supported per card / unit',
    '每秒分析帧数': 'Analysis FPS',
    '帧/秒': 'FPS',
    '识别任务（全部视频使用相同识别任务）': 'Analysis tasks (applied to every video stream)',
    '＋ 添加识别任务': '+ Add analysis task',
    '修改需求后重新计算': 'Recalculate after changing requirements',
    '设备选择': 'Device selection',
    '尚未计算设备': 'Calculate to see device options.',
    '选择一种设备以生成配置清单': 'Select one device to create the configuration.',
    '主机配置说明': 'Host configuration guidance',
    '查看 CPU 与内存要求': 'View CPU and memory requirements',
    '清单预览': 'Configuration preview',
    '复制与导出使用以下内容': 'Only the content below will be copied or exported',
    '配置尚未生成': 'Configuration not created yet',
    '填写需求并计算，再选择一种设备。': 'Enter your requirements, calculate, then select one device.',
    '导出 Excel': 'Export Excel',
    '删除': 'Delete',
    '设备暂不支持当前需求': 'This device cannot support the current requirements.',
    '选择设备后重新计算': 'Recalculate after selecting a device.',
    '暂时无法计算设备，请重试。': 'Could not calculate devices. Please try again.',
    '加载失败，请刷新页面重试。': 'Loading failed. Refresh the page to try again.'
  };
  const state = { hardware: [], algos: [], row: null, result: null, phase: 'empty', request: null, revision: 0, exporting: false };
  const $ = (id) => document.getElementById(id);
  const x = (key, values = {}) => {
    const translated = I18n.locale === 'en' ? (extraEn[key] || I18n.t(key)) : key;
    return String(translated).replace(/\{(\w+)\}/g, (match, name) => Object.hasOwn(values, name) ? values[name] : match);
  };
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]));
  const hardware = (id) => state.hardware.find((item) => item.id === id);
  const algorithm = (id) => state.algos.find((item) => item.id === id);
  const edge = (device) => device?.id === 'orin-nx-16g';
  const sizing = () => state.row?.mode !== 'capacity';
  const taskName = (id) => I18n.algorithmName(algorithm(id)?.name || '');
  const validFps = (value) => String(value).trim() !== '' && Number.isFinite(Number(value)) && Number(value) >= 0;
  const validCameras = (value) => validFps(value) && Number.isSafeInteger(Number(value)) && Number(value) > 0;
  function unit(device, count) { return I18n.unit(edge(device), count); }
  function rowError() {
    if (!state.row) return '';
    if (sizing() && !validCameras(state.row.cameras)) return '请输入大于 0 的整数视频路数';
    if (!sizing() && !hardware(state.row.hwId)) return '请选择设备';
    if (!state.row.algos.length) return '请添加至少一项识别任务';
    if (state.row.algos.some((item) => !validFps(item.fps))) return '每秒分析帧数须为大于或等于 0 的数字';
    return '';
  }
  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.row)); }
    catch { $('notice').hidden = false; $('notice').textContent = x('浏览器无法保存输入，刷新后可能丢失本次修改。'); }
  }
  function loadDemand() {
    let saved;
    try { saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) || JSON.parse(localStorage.getItem('cpipe-capacity-planner-demand-v4')); }
    catch { /* Start clean when browser storage is unavailable or malformed. */ }
    state.row = {
      mode: saved?.mode === 'capacity' ? 'capacity' : 'sizing',
      cameras: validCameras(saved?.cameras) ? Number(saved.cameras) : '',
      hwId: hardware(saved?.hwId) ? saved.hwId : state.hardware[0].id,
      selectedHwId: hardware(saved?.selectedHwId) ? saved.selectedHwId : '',
      algos: (Array.isArray(saved?.algos) ? saved.algos : []).filter((item) => item && algorithm(item.id))
        .map((item) => ({ id:item.id, fps:validFps(item.fps) ? Number(item.fps) : '' }))
    };
  }
  function renderStatic() {
    document.documentElement.lang = I18n.locale === 'zh' ? 'zh-CN' : 'en';
    document.title = I18n.t('视频分析设备选型 · Code_X');
    const labels = {
      pageTitle:'视频分析设备选型', languageLabel:'语言', modeLabel:'选择计算方式', modeSizingTitle:'按视频路数选设备',
      modeSizingHelp:'计算需要采购的设备数量', modeCapacityTitle:'查看已有设备容量', modeCapacityHelp:'计算单张 / 台支持的视频路数',
      requirementsHeading:'视频与识别任务', cameraLabel:'视频数量', streamUnit:'路',
      taskLabel:'识别任务（全部视频使用相同识别任务）', fpsLabel:'每秒分析帧数', addTask:'＋ 添加识别任务', recalculateHint:'修改需求后重新计算',
      deviceHeading:'设备选择', hardwareHeading:'主机配置说明', hardwareSubheading:'查看 CPU 与内存要求', hostGuidance:'独立显卡主机',
      cpuGuidance:'CPU：总物理核心数不少于视频路数的一半（向下取整），且最低 8 核；主频不低于 2.6 GHz。',
      memoryGuidance:'内存：至少 32 GB，且大于所用显卡总显存的 1.5 倍。', streamGuidance:'视频路数按实际计划接入量，不代入设备最大支持路数。',
      edgeGuidance:'边缘设备（如 Orin NX 16G）', edgeGuidanceCopy:'CPU 和内存由所购整机规格决定，不套用上述主机公式。',
      previewHeading:'清单预览', previewHint:'复制与导出使用以下内容', btnCopyInfo:'复制配置信息', btnExport:'导出 Excel', btnCloseCopy:'关闭',
      copyHeading:'请手动复制配置信息', copyHelp:'浏览器未允许自动复制，文本已全选，请按 Ctrl+C / ⌘C 复制。'
    };
    for (const [id, key] of Object.entries(labels)) $(id).textContent = x(key);
    $('languageSelect').value = I18n.locale;
    $('languageSelect').setAttribute('aria-label', x('语言'));
    $('modebar').setAttribute('aria-label', x('选择计算方式'));
    for (const [id,active] of [['modeSizing',sizing()],['modeCapacity',!sizing()]]) {
      $(id).classList.toggle('active',active);
      $(id).setAttribute('aria-pressed',String(active));
    }
  }
  function renderAlgorithms() {
    $('algorithmRows').innerHTML = state.row.algos.length ? state.row.algos.map((item, index) => {
      const name = taskName(item.id);
      return `<div class="task-row"><label for="fps-${index}">${esc(name)}</label><input id="fps-${index}" data-fps="${index}" type="number" min="0" step="0.1" inputmode="decimal" value="${esc(item.fps)}" aria-label="${esc(x('{name}每秒分析帧数，第 {index} 项',{name,index:index+1}))}" aria-invalid="${!validFps(item.fps)}" aria-describedby="inputStatus"><span class="unit">${esc(x('帧/秒'))}</span><button class="remove-task" type="button" data-remove="${index}" aria-label="${esc(x('删除第 {index} 项 {name}',{index:index+1,name}))}">${esc(x('删除'))}</button></div>`;
    }).join('') : `<p class="task-empty">${esc(x('添加需要的识别任务，每项可以单独设置分析频率。'))}</p>`;
    $('algorithmOptions').innerHTML = state.algos.map((item) => `<button type="button" data-add="${esc(item.id)}">${esc(taskName(item.id))}</button>`).join('');
  }
  function option(candidate) {
    if (!candidate?.ok || !candidate.hasAlgos || !Number.isSafeInteger(candidate.n) || candidate.n <= 0) return null;
    const device = hardware(candidate.hwId);
    if (!device) return null;
    const quantity = sizing() ? Math.ceil(Number(state.row.cameras) / candidate.n) : 1;
    if (!Number.isSafeInteger(quantity) || !Number.isSafeInteger(quantity * candidate.n)) return null;
    return { device, capacity:candidate.n, quantity, unit:unit(device, quantity) };
  }
  function selected() {
    if (state.phase !== 'ready' || rowError()) return null;
    return option(sizing() ? state.result?.candidates.find((item) => item.hwId === state.row.selectedHwId) : state.result);
  }
  function renderDevices() {
    if (!state.row) return;
    $('cameraField').hidden = !sizing();
    const ready = state.phase === 'ready';
    const candidates = sizing() ? (ready ? state.result.candidates : []) : state.hardware.map((device) => {
      const result = ready && device.id === state.row.hwId ? state.result : null;
      return result ? { ...result, hwId:device.id } : { hwId:device.id };
    });
    if (!candidates.length) {
      $('deviceList').innerHTML = '';
      $('deviceStatus').textContent = x(state.phase === 'loading' ? '正在计算…' : '尚未计算设备');
      return;
    }
    $('deviceStatus').textContent = sizing() ? x('选择一种设备以生成配置清单') : x(ready ? '使用当前识别任务与分析频率。' : '选择设备后重新计算');
    $('deviceList').innerHTML = candidates.map((candidate) => {
      const device = hardware(candidate.hwId);
      const result = option(candidate);
      const checked = sizing() ? state.row.selectedHwId === device.id && Boolean(result) : state.row.hwId === device.id;
      const suffix = result ? `<b>${result.quantity} ${esc(result.unit)}</b>` : ready && sizing() ? `<span class="device-unavailable">${esc(x('设备暂不支持当前需求'))}</span>` : '';
      return `<label class="device-option${checked ? ' selected' : ''}"><input type="radio" name="device" value="${esc(device.id)}" ${checked ? 'checked' : ''} ${sizing() && !result ? 'disabled' : ''}><strong>${esc(device.name)}</strong>${suffix}</label>`;
    }).join('');
  }
  function configReport() {
    const choice = selected();
    if (!choice) return null;
    return {
      locale:I18n.locale,
      fields:[
        ...(sizing() ? [['target',x('视频数量'),Number(state.row.cameras),x('路')]] : []),
        ['device',x('设备型号'),choice.device.name,''], ['quantity',x('设备数量'),choice.quantity,choice.unit],
        ['capacity',x(edge(choice.device) ? '每台支持路数' : '每张支持路数'),choice.capacity,x('路')],
        ...(choice.quantity > 1 ? [['total',x('合计支持路数'),choice.quantity * choice.capacity,x('路')]] : [])
      ],
      algorithms:state.row.algos.map((item,index) => [index+1,taskName(item.id),Number(item.fps)])
    };
  }
  function renderPreview() {
    const report = configReport();
    $('btnCopyInfo').disabled = !report;
    $('btnExport').disabled = !report || state.exporting;
    if (!report) {
      $('configPaper').innerHTML = `<div class="paper-empty"><strong>${esc(x('配置尚未生成'))}</strong><span>${esc(x('填写需求并计算，再选择一种设备。'))}</span></div>`;
      return;
    }
    const quantityIndex = report.fields.findIndex(([key]) => key === 'quantity');
    $('configPaper').innerHTML = `<h2 class="paper-title">${esc(x('配置清单'))}</h2><table class="config-table"><tbody>${report.fields.map(([key,label,value,fieldUnit],index) => `<tr${index === quantityIndex ? ' class="quantity"' : ''}><th scope="row">${esc(label)}</th><td>${esc(value)}${fieldUnit ? ` ${esc(fieldUnit)}` : ''}</td></tr>`).join('')}</tbody></table><h3 class="task-heading">${esc(x('识别任务'))}</h3><table class="tasks-table"><thead><tr><th>${esc(x('识别任务'))}</th><th>${esc(x('每秒分析帧数'))}</th></tr></thead><tbody>${report.algorithms.map(([,name,fps]) => `<tr><td>${esc(name)}</td><td>${esc(x('{fps} 帧/秒',{fps}))}</td></tr>`).join('')}</tbody></table>`;
  }
  function render(skipTaskRows = false) {
    if (!state.row) return;
    renderStatic();
    $('targetCameras').value = state.row.cameras;
    $('targetCameras').setAttribute('aria-invalid', String(Boolean(rowError()) && !validCameras(state.row.cameras)));
    if (!skipTaskRows) renderAlgorithms();
    renderDevices(); renderPreview();
    const loading = state.phase === 'loading';
    $('btnCalculate').disabled = loading;
    $('btnCalculate').textContent = x(loading ? '正在计算…' : state.phase === 'ready' ? '重新计算' : sizing() ? '查看所需设备' : '查看支持路数');
    $('inputStatus').textContent = x(rowError());
  }
  function invalidate(skipTaskRows = false) {
    state.request?.abort(); state.revision++; state.phase = 'dirty'; state.result = null;
    if (sizing()) state.row.selectedHwId = '';
    $('exportStatus').textContent = ''; persist(); render(skipTaskRows);
  }
  async function getJson(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) throw Error('HTTP failure');
    const data = await response.json();
    if (!data?.ok) throw Error('API failure');
    return data;
  }
  async function evaluate() {
    state.request?.abort();
    const revision = ++state.revision;
    if (rowError()) { state.phase = 'dirty'; render(); return; }
    state.phase = 'loading'; state.result = null; render();
    const queries = (sizing() ? state.hardware : [hardware(state.row.hwId)]).map((device,index) => ({ id:String(index), hwId:device.id, algos:state.row.algos.map((item) => ({ id:item.id, fps:Number(item.fps) })) }));
    const controller = new AbortController(); state.request = controller;
    const timeout = setTimeout(() => controller.abort(),12000);
    try {
      const data = await getJson('/api/evaluate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:queries}),signal:controller.signal});
      if (revision !== state.revision) return;
      const results = queries.map((query) => {
        const matches = Array.isArray(data.results) ? data.results.filter((item) => item?.id === query.id) : [];
        const item = matches[0];
        const valid = matches.length === 1 && item?.ok === true && item.hasAlgos === true && Number.isSafeInteger(item.n) && item.n >= 0;
        return { ...(valid ? item : {ok:false}), hwId:query.hwId };
      });
      state.result = sizing() ? {candidates:results} : results[0]; state.phase = 'ready';
      if (sizing() && !option(state.result.candidates.find((item) => item.hwId === state.row.selectedHwId))) state.row.selectedHwId = '';
      persist();
    } catch {
      if (revision !== state.revision) return;
      state.phase = 'error'; state.result = null; $('exportStatus').textContent = x('暂时无法计算设备，请重试。');
    } finally { clearTimeout(timeout); if (revision === state.revision) render(); }
  }
  $('targetCameras').addEventListener('input', () => { state.row.cameras = $('targetCameras').value; invalidate(); });
  $('algorithmRows').addEventListener('input', (event) => {
    const index = Number(event.target.dataset.fps); if (!Number.isInteger(index) || !state.row.algos[index]) return;
    state.row.algos[index].fps = event.target.value;
    event.target.setAttribute('aria-invalid',String(!validFps(event.target.value)));
    invalidate(true);
  });
  $('algorithmRows').addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove]'); if (!button) return;
    state.row.algos.splice(Number(button.dataset.remove),1); invalidate();
  });
  $('algorithmOptions').addEventListener('click', (event) => {
    const id = event.target.closest('[data-add]')?.dataset.add; const item = algorithm(id); if (!item) return;
    state.row.algos.push({id,fps:Number(item.defaultFps)}); $('algoPicker').open = false; invalidate();
  });
  $('deviceList').addEventListener('change', (event) => {
    if (event.target.name !== 'device') return;
    if (sizing()) {
      state.row.selectedHwId = event.target.value; persist();
      $('deviceList').querySelectorAll('.device-option').forEach((item) => item.classList.toggle('selected',Boolean(item.querySelector('input:checked'))));
      $('exportStatus').textContent = ''; renderPreview();
    }
    else { state.row.hwId = event.target.value; invalidate(); }
  });
  $('btnCalculate').addEventListener('click',evaluate);
  function setMode(mode) {
    if (state.row.mode === mode) return;
    if (mode === 'capacity' && state.row.selectedHwId) state.row.hwId = state.row.selectedHwId;
    state.row.mode = mode; invalidate();
  }
  $('modeSizing').addEventListener('click', () => setMode('sizing'));
  $('modeCapacity').addEventListener('click', () => setMode('capacity'));
  $('languageSelect').addEventListener('change', () => { I18n.setLocale($('languageSelect').value); $('exportStatus').textContent = ''; render(); });
  for (const id of ['algoPicker','hardwareNotes']) $(id).addEventListener('keydown',(event) => { if (event.key === 'Escape') { $(id).open = false; $(id).querySelector('summary').focus(); } });
  document.addEventListener('click',(event) => { if (!$('algoPicker').contains(event.target)) $('algoPicker').open = false; });
  $('btnCopyInfo').addEventListener('click',async () => {
    const report = configReport(); if (!report) return;
    const text = [...report.fields.map(([,label,value,fieldUnit]) => x('{label}：{value}',{label,value:`${value}${fieldUnit ? ' '+fieldUnit : ''}`})),x('识别任务明细'),...report.algorithms.map(([index,name,fps]) => `${index}. ${name}：${x('{fps} 帧/秒',{fps})}`)].join('\n');
    try { if (!navigator.clipboard?.writeText) throw Error(); await navigator.clipboard.writeText(text); $('exportStatus').textContent = x('已复制配置信息。'); }
    catch { $('copyText').value = text; $('copyFallback').showModal(); $('copyText').focus(); $('copyText').select(); }
  });
  $('btnExport').addEventListener('click',async () => {
    const report = configReport(); if (!report) return;
    const revision = state.revision; state.exporting = true; render(); $('exportStatus').textContent = x('正在生成 Excel 配置清单…');
    try {
      const blob = await window.createConfigWorkbook(report); if (revision !== state.revision || report.locale !== I18n.locale) throw Error();
      const url = URL.createObjectURL(blob), link = document.createElement('a'); link.href = url; link.download = x('配置清单')+'.xlsx'; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url),60000);
      $('exportStatus').textContent = x('Excel 配置清单已生成，请在浏览器下载中查看。');
    } catch { $('exportStatus').textContent = x('Excel 导出失败，请重试；也可先复制配置信息。'); }
    finally { state.exporting = false; render(); }
  });
  async function boot() {
    I18n.apply();
    try {
      const data = await getJson('/api/catalog'); state.hardware = data.hardware; state.algos = data.algos;
      if (!state.hardware.length || !state.algos.length) throw Error();
      loadDemand(); $('modeSizing').disabled = false; $('modeCapacity').disabled = false; render(); if (!rowError()) await evaluate();
    } catch { $('notice').hidden = false; $('notice').textContent = x('加载失败，请刷新页面重试。'); }
  }
  boot();
})();
