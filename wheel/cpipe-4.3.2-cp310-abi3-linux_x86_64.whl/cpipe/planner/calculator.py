"""VRAM / compute / decode stream capacity estimates."""


def decode_mb(hw: dict) -> float:
    return float(hw.get("decodeMb") or 0)


def decode_gb(hw: dict) -> float:
    return decode_mb(hw) / 1000.0


def gb_to_streams(gb: float, hw: dict) -> int:
    mb = decode_mb(hw)
    if mb <= 0:
        return 0
    return int(float(gb) * 1000 // mb)


def auto_streams(hw: dict) -> int:
    return gb_to_streams(hw.get("vramGb") or 0, hw)


def hw_streams(hw: dict) -> int:
    if hw.get("streamMode") == "fixed":
        return int(hw.get("streamFixed") or 0)
    return auto_streams(hw)


def _num(value, default=0.0) -> float:
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def calculate(hw: dict | None, algo_defs: dict[str, dict], row: dict) -> dict:
    """Estimate max streams for one scenario. algo_defs is id -> algorithm."""
    if not hw:
        return {"ok": False, "error": "Select hardware"}

    override = row.get("streamOverride")
    n_decode = hw_streams(hw) if override is None or override == "" else int(_num(override))

    selected = []
    for item in row.get("algos") or []:
        algo = algo_defs.get(item.get("id"))
        if not algo:
            continue
        selected.append({"def": algo, "fps": _num(item.get("fps"))})

    algo_vram = sum(_num(x["def"].get("vramGb")) for x in selected)
    cost_per_stream = sum(x["fps"] * _num(x["def"].get("equiv")) for x in selected)
    remain = _num(hw.get("vramGb")) - algo_vram
    per_stream = decode_gb(hw)

    if remain < 0:
        n_vram = 0
    else:
        n_vram = gb_to_streams(remain, hw)

    if not selected or cost_per_stream <= 0:
        n_compute = None
    else:
        n_compute = int(_num(hw.get("maxDetectFps")) // cost_per_stream)

    candidates = [n_vram, n_decode]
    if n_compute is not None:
        candidates.append(n_compute)
    n = max(0, min(candidates))

    if not selected:
        bottleneck = "Select algorithms to calculate"
    elif remain < 0:
        bottleneck = "Algorithm VRAM exceeds device VRAM"
    elif n == 0:
        bottleneck = "This combination cannot support 1 stream"
    else:
        hits = []
        if n == n_vram:
            hits.append("VRAM")
        if n_compute is not None and n == n_compute:
            hits.append("Compute")
        if n == n_decode:
            hits.append("Decode")
        bottleneck = " & ".join(hits) + " limited"

    return {
        "ok": True,
        "n": n,
        "nVram": n_vram,
        "nCompute": n_compute,
        "nDecode": n_decode,
        "algoVram": algo_vram,
        "remain": remain,
        "costPerStream": cost_per_stream,
        "perStream": per_stream,
        "maxDetectFps": _num(hw.get("maxDetectFps")),
        "selected": [
            {
                "id": x["def"].get("id"),
                "name": x["def"].get("name"),
                "fps": x["fps"],
                "equiv": _num(x["def"].get("equiv")),
                "vramGb": _num(x["def"].get("vramGb")),
            }
            for x in selected
        ],
        "bottleneck": bottleneck,
        "hasAlgos": bool(selected),
    }


def public_result(full: dict) -> dict:
    """Planner page returns stream count and bottleneck only."""
    if not full.get("ok"):
        return {"ok": False, "error": full.get("error") or "Cannot calculate"}
    return {
        "ok": True,
        "n": full["n"] if full.get("hasAlgos") else None,
        "bottleneck": full["bottleneck"],
        "maxStreams": full["nDecode"],
        "hasAlgos": full["hasAlgos"],
    }


def admin_detail(full: dict) -> str:
    if not full.get("ok"):
        return full.get("error") or "Cannot calculate"
    if not full.get("hasAlgos"):
        return f"No algorithms selected. Decode limit {full['nDecode']}, VRAM can decode {full['nVram']}"
    n_compute = full["nCompute"]
    n_compute_txt = "∞" if n_compute is None else n_compute
    parts = [
        f"Algorithm VRAM Σ = {full['algoVram']} G",
        f"Remaining VRAM = {full['remain'] + full['algoVram']} - {full['algoVram']} = {full['remain']} G",
        f"N_vram = floor({full['remain']} / {full['perStream']}) = {full['nVram']}",
        "Compute per stream = "
        + " + ".join(f"{x['name']} {x['fps']}×{x['equiv']}" for x in full["selected"])
        + f" = {full['costPerStream']} detection frames",
        f"N_compute = floor({full['maxDetectFps']} / {full['costPerStream'] or '—'}) = {n_compute_txt}",
        f"N_decode = {full['nDecode']}",
        f"N = min({full['nVram']}, {n_compute_txt}, {full['nDecode']}) = {full['n']}",
    ]
    return "\n".join(parts)
