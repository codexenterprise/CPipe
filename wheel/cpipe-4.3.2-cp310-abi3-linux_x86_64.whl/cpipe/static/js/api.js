// API Functions
const API = {
    CHAT_TIMEOUT_MS: 180000,

    // Create axios instance
    request: axios.create({
        baseURL: CONFIG.apiBaseUrl,
        timeout: 120000
    }),

    // Get workflow
    getWorkflow() {
        return this.request.get('/api/workflow');
    },

    // Save to file
    saveToFile(data) {
        return this.request.post('/api/save-to-file', data);
    },

    // Get edge parameters
    getEdgeParams() {
        return this.request.get('/api/edge-labels');
    },

    // Get node parameters
    getNodeParams(nodeType) {
        return this.request.get(`/api/node-params?node_type=${nodeType}`);
    },

    // Get task parameters
    getTaskParams(nodeType, taskType) {
        return this.request.get(`/api/task-params?task_type=${taskType}&node_type=${nodeType}`);
    },

    // Get video files
    getVideoFiles() {
        return this.request.get('/api/list-video-files');
    },

    // Get model files
    getModelFiles() {
        return this.request.get('/api/list-model-files');
    },

    // Upload file
    uploadFile(file, additionalData = {}) {
        const formData = new FormData();
        formData.append('files', file);

        // Add additional data
        Object.entries(additionalData).forEach(([key, value]) => {
            formData.append(key, String(value));
        });

        return this.request.post('/api/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
    },

    // Upload multiple files
    uploadFiles(files, additionalData = {}) {
        const formData = new FormData();
        
        // Add all files
        files.forEach(file => {
            formData.append('files', file);
        });

        // Add additional data
        Object.entries(additionalData).forEach(([key, value]) => {
            formData.append(key, String(value));
        });

        return this.request.post('/api/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
    },

    // Chat（async：返回 Promise，便于调用方 await）
    async chat(formData) {
        return await this.request.post('/api/chat', formData, {
            timeout: this.CHAT_TIMEOUT_MS,
        });
    },

    // Restart server
    restartServer() {
        return this.request.post('/api/restart');
    },

    // checkName
    checkName(data) {
        return this.request.post('/api/validate-node-name', data);
    }
};
