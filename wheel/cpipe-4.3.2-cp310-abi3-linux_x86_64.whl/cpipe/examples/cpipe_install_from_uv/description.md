介绍如何使用uv快速安装cpipe的依赖。
