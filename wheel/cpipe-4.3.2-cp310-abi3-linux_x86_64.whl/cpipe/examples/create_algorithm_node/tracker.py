from cpipe.module.model.tracker.tracker import Tracker
from cpipe.module.model.yolov7 import YOLOv7
from cpipe.module.streamer import VideoStreamer
from cpipe.module.insight import CPipeInsight
from cpipe.module.node import Node

if __name__ == "__main__":

    streamer1 = VideoStreamer(node_name="streamers", stream="rtmp://192.168.8.7:1935/live/7777", process_frame_interval=1)

    chache = YOLOv7(node_name="chache",
                       model_path="../../src/dongsheng/dongsheng_huowu_new.engine",
                       input_size=(3, 640, 640),
                       class_names=['materials'],
                       max_batch_size=1,
                       conf_thres=0.4,
                       )

    tk = Tracker(node_name="tracker",
                 scale_ratio=5,
                 config_tracker={
                                'det_thresh': 0.25,  # 目标检测阈值
                                'max_age': 90,  # 超过5帧没有检测到目标，将目标删除
                                'min_hits': 5,  # 目标出现3帧后才开始跟踪
                                'iou_threshold': 0.01,  # iou阈值
                                'delta_t': 90,  # 时间间隔
                                # 'inertia': 0.01,  # 时间间隔
                                },
                 tracker_type='ocsort',
                 secondary_class_names=['materials'],
                 dump_images=True
                 )


    cpipeinsight = CPipeInsight(http_insight=True, save_video=True)

    streamer1 += [chache, tk, cpipeinsight]

    Node.launch(check_node=True, check_interval=5, auto_restart=False)
