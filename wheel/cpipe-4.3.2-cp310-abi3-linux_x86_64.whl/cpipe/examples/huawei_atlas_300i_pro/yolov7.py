import numpy as np
from cpipe.module.model.yolov7 import YOLOv7
from cpipe.module.node import Node
from cpipe.module.insight import CPipeInsight
from cpipe.module.streamer import VideoStreamer

if __name__ == "__main__":
    stream = VideoStreamer(node_name="stream", stream="../../../PAPER_20250331141736_20210204_D5.mp4", process_frame_interval=1)

    zhu_det = YOLOv7(node_name="YOLOv7",
                     model_path="../../../models/yolov7-tiny_rknn_om_batch4.om",
                     input_size=(3, 640, 640),
                    #  class_names=['person', ...],
                     max_batch_size=4,
                     valid_class_names=["person"],
                     save_top_n_objects=32,
                     area_flag=True,
                     device="npu:0",
                     anchor=np.array([12.0, 16.0, 19.0, 36.0, 40.0, 28.0, 36.0, 75.0, 76.0, 55.0, 72.0, 146.0, 142.0, 110.0, 192.0, 243.0, 459.0, 401.0]).reshape(3, -1, 2).tolist()
                     )


    cp = CPipeInsight(http_insight=True)

    stream += [zhu_det, cp]

    Node.launch()
