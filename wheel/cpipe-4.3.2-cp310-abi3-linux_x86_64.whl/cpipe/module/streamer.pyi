from _typeshed import Incomplete
from cpipe.config.config import SHARE_MEMORY_MODE as SHARE_MEMORY_MODE, VIDEO_CUDA_MODE as VIDEO_CUDA_MODE
from cpipe.module.cdata import CData as CData, CImage as CImage
from cpipe.module.cevent import CEvent as CEvent
from cpipe.module.cmask import CMask as CMask
from cpipe.module.cprocessors import CProcessors as CProcessors
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CIntList as CIntList, CNone as CNone, CStrList as CStrList
from cpipe.module.insight import Insight as Insight
from cpipe.module.node import Node as Node, NodeType as NodeType
from cpipe.module.thirdparty.hikvision import Hikvision as Hikvision
from cpipe.module.utils import ChineseText as ChineseText, cudaSetDevice as cudaSetDevice
from multiprocessing import shared_memory as shared_memory
from typing import Annotated, Any, ClassVar, Literal

class Streamer(Node):
    SET_VIDEO_PROGRESS_IN_OPERATION: ClassVar[int]
    SET_VIDEO_PROGRESS_PAUSE: ClassVar[int]
    stream: Annotated[CFilePath | str | int, 'The stream address. e.g. rtsp://*** or rtmp://*** or file.mp4 or 0(USB Camera)']
    all_ready: Annotated[CBool, 'Whether to wait for all consumers to be ready.']
    device: Annotated[str, 'The device of the model, CPU(cpu) or GPU(cuda:x).']
    process_frame_interval_value: Annotated[int, 'The process frame interval of the node.']
    video_fps: Annotated[Any, 'The video fps of the node.']
    video_width: Annotated[Any, 'The video width of the node.']
    video_height: Annotated[Any, 'The video height of the node.']
    video_channels: Annotated[Any, 'The video channels of the node.']
    node_type: Annotated[NodeType, 'The type of the node.']
    video_duration: Annotated[Any, 'The video duration of the node.']
    video_progress: Annotated[Any, 'The video progress of the node.']
    set_video_progress: Annotated[Any, 'The set video progress of the node. -2:inoperation, -1: pause, other: set the video progress.']
    capture_mode: Annotated[Literal['FFMPEG', 'GSTREAMER'], 'The capture mode of the node.']
    cv_open_timeout_ms: Annotated[int, 'The timeout of the cv2.VideoCapture.open() function.']
    cv_read_timeout_ms: Annotated[int, 'The timeout of the cv2.VideoCapture.read() function.']
    new_stream: Incomplete
    cmask: CMask
    actual_fps: Incomplete
    _process_frame_interval: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        """
        Streamer is the base class for the streamer node.
        Args:
            node_name: (str) The name of the node.
            stream: (str) The stream address.
            queue_size: (int) The size of the queue.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        """
    @property
    def process_frame_interval(self):
        """
        Get the process frame interval.
        Returns: (int) The interval of processing frames.

        """
    @process_frame_interval.setter
    def process_frame_interval(self, value) -> None:
        """
        Set the process frame interval.
        Args:
            value: (int) The interval of processing frames.

        Returns: None

        """
    def video_resolution_changed(self) -> None:
        """
        Check if the video resolution changed.
        Returns: (bool) True or False
        """
    def _connect(self) -> None:
        """
        Connect to the stream. This function should be implemented in the subclass.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the streamer node. This function should be implemented in the subclass.
        Returns: None

        """
    @staticmethod
    def get_video_type(path):
        """
        Get the video type.
        Args:
        """
    def check_all_ready(self) -> None:
        """
        Check if all consumers are ready.
        Returns: None

        """

class VideoStreamer(Streamer):
    hikvision_platform: Annotated[CBool, 'Whether to use the Hikvision platform.']
    base_url: Annotated[str, 'The base url of the Hikvision platform.']
    appKey: Annotated[str, 'The appKey of the Hikvision platform.']
    appSecret: Annotated[str, 'The appSecret of the Hikvision platform.']
    short_connection_delay_value: Annotated[float, 'The short connection delay of the video.']
    sleep_time: Annotated[float | CNone, 'The sleep time of the video.']
    block_mode: Annotated[CBool, 'Whether to block the frame.']
    once_mode: Annotated[CBool, 'Whether to run once. If True, the streamer will run once and then exit.']
    delay_start_time: Annotated[float, 'The delay start time of the video.']
    rotate: Annotated[Literal[0, 90, 180, 270], 'The rotate of the video.']
    ground_image: Annotated[Any, 'The ground image of the node.']
    _short_connection_delay: Incomplete
    hikvision_cameras_info: Incomplete
    hikvision: Incomplete
    cmask: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        '''
        VideoStreamer is the base class for the video streamer node.
        Args:
            node_name: (str) The name of the node.
            stream: (str) The stream address.
            queue_size: (int) The size of the queue.
            process_frame_interval: (int) The interval of processing frames.
            hikvision_platform: (bool) Whether to use the Hikvision platform.
            base_url: (str) The base url of the Hikvision platform.
            appKey: (str) The appKey of the Hikvision platform.
            appSecret: (str) The appSecret of the Hikvision platform.
            short_connection_delay: (float) The short connection delay.
            sleep_time: (float) The sleep time(second, e.g. 0.04s) with video interframe sleep. Just for file mode. e.g. stream="file.mp4"
            block_mode: (bool) Whether to block the frame. Just for file mode. e.g. stream="file.mp4"
            once_mode:  (bool) Whether to run once. Just for file mode. e.g. stream="file.mp4"
            delay_start_time: (float) The delay start time. Just for file mode. e.g. stream="file.mp4"
            all_ready: (bool) Whether to wait for all consumers to be ready.
            rotate: (int) The rotate of the video. 0: no rotate, 90: rotate 90 degrees, 180: rotate 180 degrees, 270: rotate 270 degrees.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).

        '''
    @property
    def short_connection_delay(self):
        """
        Get the short connection delay.
        Returns: (float) The short connection delay.
        """
    @short_connection_delay.setter
    def short_connection_delay(self, value) -> None:
        """
        Set the short connection delay.
        """
    new_stream: Incomplete
    def evet_set_stream(self, data):
        """
        Set the stream.
        Args:
            data: (str) The stream address.

        Returns: None

        """
    def event_get_stream(self, data):
        """
        Get the stream.
        Returns: (str) The stream address.
        """
    def reset_stream(self, stream):
        """
        Reset the stream.
        Args:
            stream: (str) The stream address.

        Returns: None

        """
    def need_reset_stream(self):
        """
        Check if need to reset the stream.
        Returns: (bool) True or False

        """
    def get_hk_camera_rtsp(self, camera_name):
        """
        Get the rtsp stream of the Hikvision platform.
        Args:
            camera_name: (str) The name of the camera.

        Returns: (str) The rtsp stream.

        """
    def get_rtsp_info(self):
        """
        Get the rtsp information.
        Returns: (int, int, int) The video fps, width and height.

        """
    def get_one_image(self):
        """
        Get one image from the stream.
        Returns: (np.ndarray) The image.

        """
    @staticmethod
    def _get_cuda_color_format():
        """
        Get the BGR(3 channels) color format value of the cudacodec VideoReader.

        cudacodec defaults to BGRA(4 channels), so this value must be applied via
        cap.set(...) right after a reader is created.

        Returns: (int) The BGR color format value.
        """
    def _create_cuda_reader(self, first_frame_idx: int = 0):
        """
        Create a cudacodec VideoReader for the current stream and set the BGR color format.

        cudacodec does NOT support seeking via cap.set(cv2.CAP_PROP_POS_FRAMES, ...): its
        set() only accepts a ColorFormat, and CAP_PROP_POS_FRAMES==1 happens to equal
        cudacodec.BGRA==1, so such a call silently switches the output to 4-channel BGRA
        instead of seeking. Seeking is therefore done by recreating the reader with
        VideoReaderInitParams.firstFrameIdx.

        Args:
            first_frame_idx: (int) The frame index to start decoding from.
        Returns: The cudacodec VideoReader object.
        """
    @staticmethod
    def _release_cap(cap) -> None:
        """
        Release a VideoCapture or cudacodec.VideoReader.

        cv2.VideoCapture has release(); cv2.cudacodec.VideoReader does not.
        The CUDA reader is freed by dropping the last Python reference so the
        C++ destructor can tear down NVDEC.
        """
    stream: Incomplete
    def _connect(self, wait_connect: bool = True):
        """
        Connect to the stream.
        Args:
            wait_connect: (bool) Whether to wait for the connection to be successful.
        Returns: (cv2.VideoCapture, bool) The cv2.VideoCapture object and the flag.

        """
    def check_video_info(self):
        """
        Check the video information.
        Returns: (bool) True or False

        """
    def stream_start_cpu(self) -> None:
        """
        Start the streamer node with CPU mode.
        Returns: None

        """
    def stream_start_cuda(self) -> None:
        """
        Start the streamer node with CUDA mode.
        Returns: None

        """
    def file_start_cpu(self) -> None:
        """
        Start the streamer node with CPU mode.
        Returns: None

        """
    def file_start_cuda(self) -> None:
        """
        Start the streamer node with CUDA mode.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the streamer node.
        Returns: None

        """

class VideoStreamers(Node):
    streams: Annotated[CStrList, 'The stream addresses.']
    processor_num: Annotated[int, 'The number of processors.']
    interval_time: Annotated[float, 'After each stream is completed, wait for the interval_time before starting to pull the next stream.(seconds)']
    round_interval_time: Annotated[float, "After all the videos in the streams have completed their rotation, wait for the duration of the 'round_interval_time' and then continue to re-rotate.(seconds)"]
    hikvision_platform: Annotated[CBool, 'Whether to use the Hikvision platform.']
    base_url: Annotated[str, 'The base url of the Hikvision platform.']
    appKey: Annotated[str, 'The appKey of the Hikvision platform.']
    appSecret: Annotated[str, 'The appSecret of the Hikvision platform.']
    dead_thres_time: Annotated[int, 'The dead threshold time.']
    process_pool_queue_size: Annotated[int, 'The process pool queue size.']
    all_ready: Annotated[CBool, 'Whether to wait for all consumers to be ready.']
    device: Annotated[str, 'The device of the model, CPU(cpu) or GPU(cuda:x).']
    node_type: Annotated[NodeType, 'The type of the node.']
    daemon: bool
    def __init__(self, *args, **kwargs) -> None:
        """
        VideoStreamers is the base class for the video streamers node.
        Args:
            node_name: (str) The name of the node.
            streams: (list) The stream addresses.
            processor_num: (int) The number of processors.
            interval_time: (float) After each stream is completed, wait for the interval_time before starting to pull the next stream.(seconds)
            round_interval_time: (float) After all the videos in the streams have completed their rotation, wait for the duration of the 'round_interval_time' and then continue to re-rotate.(seconds)
            hikvision_platform: (bool) Whether to use the Hikvision platform.
            base_url: (str) The base url of the Hikvision platform.
            appKey: (str) The appKey of the Hikvision platform.
            appSecret: (str) The appSecret of the Hikvision platform.
            dead_thres_time: (int) The dead threshold time.
            process_pool_queue_size: (int) The process pool queue size.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        """
    def task(self, args) -> None:
        """
        Task function. This function will be called by the CProcessor.
        Args:
            args: The arguments.

        Returns: None

        """
    def check_all_ready(self) -> None:
        """
        Check if all consumers are ready.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the video streamers' node.
        Returns: None

        """

class ImageStreamer(Streamer):
    stream: Annotated[Any, 'Folder/file path or multiprocessing.Queue.']
    output_wh: Annotated[CIntList, 'The output width and height.']
    padding: Annotated[CBool, 'Whether to padding the image.']
    play_interval: Annotated[float, 'The play interval.']
    ground_image_path: Annotated[CNone | str, 'The ground image path.']
    block_mode: Annotated[CBool, 'Whether to block the frame.']
    once_mode: Annotated[CBool, 'Whether to run once.']
    all_ready: Annotated[CBool, 'Whether to wait for all consumers to be ready.']
    device: Annotated[str, 'The device of the model, CPU(cpu) or GPU(cuda:x).']
    video_fps: Incomplete
    video_width: Incomplete
    video_height: Incomplete
    cmask: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        '''
        ImageStreamer is the base class for the image streamer node.
        Args:
            node_name: (str) The name of the node.
            stream: (str) The stream is folder or file path or Queue object(python multiprocessing.Queue).
                    Examples:
                    folder path: "./test_images".
                    file path: "./test_images/test.jpg".
                    Queue format: {"images_path": ["./test_images/test.jpg", "./test_images/test1.png", ...], "images_info"[{...}, {...}, ...]} or {"images_array": [np.ndarray, np.ndarray, ...], "images_info"[{...}, {...}, ...]}.
            queue_size: (int) The size of the queue.
            output_wh: (tuple) The output width and height.
            padding: (bool) Whether to padding the image.
            play_interval: (float) The play interval.
            process_frame_interval: (int) The interval of processing frames.
            ground_image_path: (str) The ground image path.
            block_mode: (bool) Whether to block the frame.
            once_mode: (bool) Whether to run once.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        Examples:
            1.
            ImageStreamer("image_streamer", "./test_images", 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=True, all_ready=True, device="cuda:0")
            2.
            ImageStreamer("image_streamer", "./test_images/test.jpg", 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=True, all_ready=True, device="cuda:0")
            3.
            queue = multiprocessing.Queue(64)
            ImageStreamer("image_streamer", queue, 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=False, all_ready=True, device="cuda:0")

        '''
    def get_one_image(self):
        """
        Get one image from the stream.
        Returns: (np.ndarray) The image.

        """
    def _start(self) -> None:
        """
        Start the streamer node.
        Returns: None

        """

class MCPStreamer(Streamer):
    show_chinese: ClassVar[ChineseText]
    show_args: ClassVar[dict]
    image_show_wh: Annotated[CIntList, 'The size of the image to show.']
    mcp_tool_name: Annotated[str, 'The name of the mcp tool.']
    mcp_transport: Annotated[str, 'The transport of the mcp server.']
    mcp_host: Annotated[str, 'The host of the mcp server.']
    mcp_port: Annotated[int, 'The port of the mcp server.']
    just_return_box_json: Annotated[CBool, 'Whether to return the box JSON data only.']
    block_mode: Annotated[CBool, 'Whether to block the frame.']
    all_ready: Annotated[CBool, 'Whether to wait for all consumers to be ready.']
    device: Annotated[str, 'The device of the model, CPU(cpu) or GPU(cuda:x).']
    stream: Annotated[None, 'The stream address. e.g. rtsp://*** or file.mp4 or 0(USB Camera)']
    cevents: Incomplete
    cmask: Incomplete
    Image: Incomplete
    PILImage: Incomplete
    cmcp: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        """
        ImageStreamer is the base class for the image streamer node.
        Args:
            node_name: (str) The name of the node.
            queue_size: (int) The size of the queue.
            mcp_tool_name: (str) The name of the mcp tool. Clearly describe the capabilities of this MCP.
            mcp_transport: (str) The transport of the mcp server. Just support streamable-http.
            mcp_host: (str) The host of the mcp server.
            mcp_port: (int) The port of the mcp server.
            just_return_box_json: (bool) Whether to return the box JSON data only.
            process_frame_interval: (int) The interval of processing frames.
            image_show_wh: (tuple) The size of the image to show.
            block_mode: (bool) Whether to block the frame.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        Examples:

        """
    def mcp_report(self, data) -> None:
        """
        MCP report with event.
        Args:
            data: (tuple) The data.
        """
    def _build_mcp_tool(self): ...
    def get_one_image(self):
        """
        Get one image from the stream.
        Returns: (np.ndarray) The image.

        """
    def inference(self, image_base64: str = '', image_path: str = '', image_url: str = '', result_inference_image: bool = True, result_embedding: bool = True, image_json: dict = {}):
        '''
        Inference the image. The reasoning results include target detection/classification/segmentation/face recognition/key points/OCR, etc.
        The image can be provided in one of the following ways:
        - image_base64: (str) The base64 of the image.
        - image_path: (str) The local file path of the image. e.g. "./test.jpg"
        - image_url: (str) The url of the image. e.g. "http://****.png"
        - result_inference_image: (bool) Whether to return the inference image. And show bboxes on the image.
        - result_embedding: (bool) Whether to return the embedding(512/768).
        - image_json: (dict) The JSON data of the image.
        Args:
            image_base64: (str) The base64 of the image.
            image_path: (str) The path of the image.
            image_url: (str) The url of the image.
            result_inference_image: (bool) Whether to return the inference image. And show bboxes on result image.
            result_embedding: (bool) Whether to return the embedding(512/768).
            image_json: (dict) The JSON data of the image.

        Returns:
            Image: The image base64 string.
            dict: The inference result. The format is:
                e.g: {
                "box_coord": [x1, y1, x2, y2],
                "box_polygon_coord": [x1, y1, x2, y1, x2, y2, x1, y2],
                "box_angle": 0,
                "box_score": 0.9,
                "box_class": 0,
                "box_class_name": "person",
                "box_img": [height, width, channel], # default is None
                "box_key_points": [[x1, y1], [x2, y2], [x3, y3], [x4, y4], [x5, y5], ...], # default is None
                "box_key_point_scores": [0.9, 0.9, 0.9, 0.9, 0.9, ...], # default is None
                "box_key_point_names": ["nose", "left_eye", "right_eye", "left_ear", "right_ear", ...], # default is None
                "box_mask": [height, width], # default is None
                "box_embedding": [512], # 512/768 embedding vector, default is None
                "box_embedding_name": "person", # default is None
                "box_embedding_score": 0.9, # default is None
                "box_text": "this is a person, she is 18 years old", # default is None
                "classification": {
                                    "names": ["person", "girl"],
                                    "scores": [0.9, 0.8],
                                    "classes": [1, 2]
                                }, # default is None
                "person": {
                            "person_box_coord": [x1, y1, x2, y2],
                            "person_box_score": 0.9,
                            "person_embedding": [512],
                            "person_score": 0.9,
                            "person_name": "Lily",
                            "face_box_coord": [x1, y1, x2, y2],
                            "face_box_score": 0.9,
                            "face_points": [[x1, y1], [x2, y2], [x3, y3], [x4, y4], [x5, y5], ...],
                            "face_embedding": [512],
                            "face_score": 0.9,
                            "face_name": "Lily\'s face",
                            "face_img": [height, width, channel],
                            "track": {
                                        "track_id": 1,
                            }, # default is None
                        }, # default is None
                "track": {"track_id": 1}, # default is None
        '''
    def _start(self) -> None:
        """
        Start the streamer node.

        Returns: None
        """
