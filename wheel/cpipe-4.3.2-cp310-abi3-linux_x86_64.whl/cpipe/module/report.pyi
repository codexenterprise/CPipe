import multiprocessing
from cpipe.config.config import CLOGER_LEVEL as CLOGER_LEVEL, CLOGER_LEVEL_DEBUG as CLOGER_LEVEL_DEBUG
from cpipe.module.node import Node as Node, NodeType as NodeType
from typing import Annotated, Callable

class Report(Node):
    """
    Report is the base class for the report node.
    """
    node_type: NodeType
    queue_size: int
    receive_func: Annotated[Callable | None, 'The function to receive the data. It should be a function that takes a single argument (the data) and returns None.']
    send_queue: multiprocessing.Queue
    def is_connected(self):
        """
        Check if the report is connected.
        Returns: True if connected, False otherwise.
        """
    def connect(self) -> None:
        """
        Connect to the report.
        Returns: None
        """
    def receive(self) -> None:
        """
        Receive the data from the report.
        Returns: The data.
        """
    def _start(self) -> None:
        """
        Start the report node.
        Returns: None

        """
    def send(self, data) -> None:
        """
        Send the data. This function should be implemented in the subclass.
        Args:
            data: The data to send.

        Returns:

        """
