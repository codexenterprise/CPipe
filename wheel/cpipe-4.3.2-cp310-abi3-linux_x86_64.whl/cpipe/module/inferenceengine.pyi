from _typeshed import Incomplete
from cpipe.config.config import SHARE_MEMORY_MODE as SHARE_MEMORY_MODE
from cpipe.module.cdata import CData as CData
from cpipe.module.cinferencehook import CHook as CHook
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CIntList as CIntList, CNone as CNone, CStrList as CStrList
from cpipe.module.node import Node as Node, NodeType as NodeType
from typing import Annotated, Any, Literal

class InferenceEngine(Node):
    """
    InferenceEngine is the base class for the model inference node.
    """
    model_path: Annotated[CFilePath | str | CNone, 'The path of the model. support onnx/engine/cpipe/codex model.']
    triton_mode: Annotated[Literal['GRPC', 'HTTP', 'SHARE_MEMORY'], 'The triton mode.']
    input_size: Annotated[CNone | CIntList, 'The size of the input image.']
    class_names: Annotated[CNone | CStrList | CFilePath, '\n    If class_names is None, the class names will be read from the label file of the model(model_path.split(".")[0] + ".txt").(Recommend)\n    The class names of the model. e.g [\'person\', \'cat\', ...] or [[fruits, animals], [apple, cat]] or \'model_files/yolov10n.txt\'.\n    All class names need to be provided completely!\n    txt file format:\n    1. object detection:\n    person\n    cat\n    dog\n    ...\n    2. multi-class classification:\n    fruits, animals\n    apple, cat\n    ...\n    3. single-class classification:\n    apple, cat, dog, car\n    ']
    threading_num: Annotated[int, 'The number of preprocessing threads.']
    max_batch_size: Annotated[int | CNone, 'The maximum batch size.']
    input_names: Annotated[CNone | CStrList, 'The input names of the model.']
    output_names: Annotated[CNone | CStrList, 'The output names of the model.']
    secondary_class_names: Annotated[CNone | CStrList, 'The class names of the previous node that need to be processed in the two-stage mode.']
    dump_images: Annotated[CBool, 'Whether to dump the images.']
    device: Annotated[str, 'The device of the model, CPU(cpu) or GPU(cuda:x). default is cuda:0.\n    for RKNN model:\n    The device of the model. eg: rknn:7 or rknn:0\n                        NPU_CORE_AUTO  = 0                                   # default, run on NPU core randomly.\n                        NPU_CORE_0     = 1                                   # run on NPU core 0.\n                        NPU_CORE_1     = 2                                   # run on NPU core 1.\n                        NPU_CORE_2     = 4                                   # run on NPU core 2.\n                        NPU_CORE_0_1   = 3                                   # run on NPU core 1 and core 2.\n                        NPU_CORE_0_1_2 = 7                                   # run on NPU core 1 and core 2 and core 3.\n                        NPU_CORE_ALL   = 0xffff                              # run on all NPU cores.\n    ']
    warmup: Annotated[CBool, 'Whether to warm up the model.']
    gray_mode: Annotated[CBool, 'Whether to use gray mode.']
    area_flag: Annotated[CBool, 'Whether to use the area mask.']
    area_info: Annotated[dict, 'The area information of the model.']
    hook_inputs: Annotated[CHook | CNone, 'The hook function of the inputs(Perform some logical operations on the input frames before the algorithm preprocessing.).']
    hook_outputs: Annotated[CHook | CNone, 'The hook function of the outputs(Perform some logical operations on the output data before the algorithm postprocessing.).']
    node_type: Annotated[NodeType, 'The type of the node.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    model: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    @staticmethod
    def parse_class_names(class_names, model_path): ...
    def update_mask(self, data) -> None:
        """
        Update the mask of the streamer.
        """
    @property
    def _device(self):
        """
        Get the device of the model.
        Returns: None

        """
    @staticmethod
    def onnx2tensorrt(model_path, max_batch_size: int = 1, input_height=None, input_width=None, min_shapes=None, opt_shapes=None, max_shapes=None, input_names=None, fp16_mode: bool = True, int8_mode: bool = False, tf32_mode: bool = False) -> None:
        """
        ONNX to TensorRT 
        
        Args:
            model_path:onnx/cpipe/codex model path
            max_batch_size: max batch size
            input_height: input height
            input_width: input width
            min_shapes: min input shape
            opt_shapes: opt input shape
            max_shapes: max input shape
            input_names: input names
            fp16_mode: use fp16 mode
            int8_mode: use int8 mode
            tf32_mode: use tf32 mode

        """
    _half: bool
    def half(self) -> None:
        """
        Set the model to half precision.
        Returns: None

        """
    def set_threading_num(self, num) -> None:
        """
        Set the number of preprocessing threads
        Args:
            num: preprocessing threading num

        Returns: None

        """
    def preprocess(self, inputs, *args, **kwargs):
        """
        Model input data preprocessing method.
        Args:
            inputs: input data
            *args:
            **kwargs:

        Returns: input data

        """
    def infer(self, inputs, *args, **kwargs):
        """
        Model inference method.
        Args:
            inputs: input data
            *args:
            **kwargs:

        Returns: model output data

        """
    def postprocess(self, inputs, *args, **kwargs):
        """
        Model output data post-processing method.
        Args:
            inputs: input data
            *args:
            **kwargs:

        Returns: output data

        """
    def forward(self, inputs, *args, **kwargs):
        """
        Model inference logic processing.
        Args:
            inputs: input data
            *args:
            **kwargs:

        Returns: output data

        """
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None:
        """
        The result processing function of the model inference (or logic) of the current node in the one-stage mode is completed,
         and the result is processed and saved to the CData object.
        Args:
            pred: model output.
            new_cdata: The CData object generated by the current node.
            frames: The original image of each batch corresponding to the inference.
            streamer_names: The stream name corresponding to each batch.
        Returns: None

        """
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None:
        """
        The result processing function of the model inference (or logic) of the current node in the two-stage mode is completed,
         and the result is processed and saved to the CData object.
        Args:
            pred: model output.
            new_cdata: The CData object generated by the current node.
            streamer_names: The stream name corresponding to each batch.
            box_idxes: The index of the Box in det_boxes corresponding to each batch.
            boxes: A list of all Box objects.
        Returns: None

        """
    def _loadModel(self, model_path=None) -> None:
        """
        Load the model of the current node, if model_path is None, the model is not loaded.
        Args:
            model_path:model path

        Returns: None

        """
    def load_model(self) -> None:
        """
        Load the model of the current node.
        Args:

        Returns: None

        """
    def get_streamer_area(self, need_update_mask_map: bool = False) -> None:
        """
        Initialize the cmask data corresponding to the current node for subsequent model inference.
        Returns: None

        """
    def before_start(self) -> None:
        """
        This method can be used to customize the initialization operation of the current node, which will be executed before the node is ready.
        Returns: None

        """
    def __call__(self, inputs, return_cdata_format: bool = False, frames_stream_names=(), *args, **kwargs):
        """
        Model inference method.
        Args:
            inputs: input data
            frames_stream_names: The stream name corresponding to each batch. e.g. ['stream1', 'stream2']
            return_cdata_format: return cdata format
            *args:
            **kwargs:

        Returns: output data

        """
    def _start(self) -> None:
        """
        The entry function for the current node (process) to run in one-stage mode, all the logic processing of the current node is completed here.
        Returns: None

        """
    def _start_secondary(self) -> None:
        """
        The entry function for the current node (process) to run in two-stage mode, all the logic processing of the current node is completed here.
        Returns: None

        """
