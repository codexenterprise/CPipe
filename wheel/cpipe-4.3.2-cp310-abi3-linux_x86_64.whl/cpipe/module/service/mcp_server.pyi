from _typeshed import Incomplete
from mcp.server.lowlevel import Server
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from typing import Any

__all__ = ['build_server', 'mount_mcp_server']

def build_server(specs: dict[str, dict[str, Any]] | None = None) -> Server: ...

class _MCPEndpoint:
    """Raw ASGI endpoint, so Starlette routes the request without wrapping it as a request/response function."""
    manager: Incomplete
    def __init__(self, manager: StreamableHTTPSessionManager) -> None: ...
    async def __call__(self, scope, receive, send) -> None: ...

def mount_mcp_server(app, path: str = '/mcp') -> int:
    """Mount the MCP server on a FastAPI/Starlette app before it starts. Returns the number of tools served."""
