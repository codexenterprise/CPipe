from _typeshed import Incomplete
from cpipe.config.config import AGENT_WORKSPACE_DIR as AGENT_WORKSPACE_DIR
from cpipe.module.clogger import CLogger as CLogger
from cpipe.module.service.agent import CPipeAgent as CPipeAgent
from fastapi import FastAPI as FastAPI, File as File, UploadFile as UploadFile
from pydantic import BaseModel
from typing import Annotated, Literal

class ChatReq(BaseModel):
    """聊天请求体。

    属性：
    - session_id: 可选，会话标识；不传则自动生成新会话
    - message: 必填，用户输入消息
    - file_paths: 可选，文件路径列表
    - chat_mode: 预留模式开关，目前未参与 agent 行为切换
    """
    session_id: Annotated[str | None, 'The session id.']
    message: Annotated[str, 'The message.']
    file_paths: Annotated[list[str] | None, 'The file paths.']
    chat_mode: Annotated[Literal['normal', 'knowledge'], 'The chat mode.']

class ChatService:
    """Chat HTTP routes backed by :class:`CPipeAgent`."""
    tmp_dir: Incomplete
    session_ttl_seconds: Incomplete
    session_cleanup_interval_seconds: Incomplete
    agent: Incomplete
    _chat_lock: Incomplete
    def __init__(self, *, session_ttl_seconds: int = ..., session_cleanup_interval_seconds: int = 10) -> None: ...
    def register_routes(self, app: FastAPI) -> ChatService:
        """Register ``/api/upload`` and ``/api/chat`` on the given FastAPI app."""
