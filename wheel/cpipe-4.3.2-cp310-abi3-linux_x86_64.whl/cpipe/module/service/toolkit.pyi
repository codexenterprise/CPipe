from dataclasses import dataclass, field
from langchain_core.tools import StructuredTool
from typing import Any, Callable

__all__ = ['ToolResult', 'ToolRegistry', 'build_langchain_tools']

@dataclass
class ToolResult:
    """Drop-in replacement for ``cagent.core.tools.ToolResult``."""
    success: bool
    output: Any = ...
    error: str | None = ...
    metadata: dict[str, Any] = field(default_factory=dict)
    images: list[bytes] = field(default_factory=list)

class ToolRegistry:
    """Decorator-based collector of tool specs."""
    TOOL_LIST: list[dict[str, Any]]
    @staticmethod
    def tool(*, name: str | None = None, description: str | None = None, parameters: dict[str, Any] | None = None, read_only: bool = False, destructive: bool = False) -> Callable[[Callable[..., Any]], Callable[..., Any]]: ...

def build_langchain_tools(extra_dict_tools: dict[str, dict[str, Any]] | None = None) -> list['StructuredTool']:
    """Materialise every collected tool spec as a LangChain ``StructuredTool``.

    Args:
        extra_dict_tools: Additional tool specs keyed by name; useful for
            tools harvested at runtime (e.g. ``Node.get_agent_tools()``).
    """
