from _typeshed import Incomplete
from dataclasses import dataclass
from langchain_openai import ChatOpenAI

__all__ = ['CPipeAgent', 'AgentRunResult']

@dataclass
class AgentRunResult:
    """Stable return shape used by the chat HTTP layer."""
    response: str
    success: bool = ...
    error: str | None = ...

class CPipeAgent:
    """Thin wrapper assembling deepagents with CPipe's tools and config."""
    root_dir: Incomplete
    _agent: Incomplete
    def __init__(self, root_dir) -> None: ...
    @staticmethod
    def _build_model() -> ChatOpenAI: ...
    def _build_backend(self): ...
    def run(self, session_id: str, user_message: str) -> AgentRunResult: ...
