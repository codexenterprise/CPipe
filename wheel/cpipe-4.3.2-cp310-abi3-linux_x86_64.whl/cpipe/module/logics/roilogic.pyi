from cpipe.module.cdata import CData as CData
from cpipe.module.logic import Logic as Logic
from typing import Annotated, Literal

class ROILogic(Logic):
    """
    ROI区域判断Logic - 无需编码，在可视化界面绘制区域即可
    自动过滤区域内/外的目标
    
    使用场景:
    - 只关注特定区域的目标（如门口、通道）
    - 排除干扰区域的目标
    - 越界检测
    """
    roi_mode: Annotated[Literal['inside', 'outside', 'cross'], 'ROI模式']
    use_center_point: Annotated[bool, '使用中心点判断']
    cross_direction: Annotated[Literal['any', 'in', 'out'], '越界方向']
    target_positions: dict
    def _start(self) -> None:
        """自动执行，无需用户编写代码"""
    def _apply_roi_filter(self, cdata: CData) -> CData:
        """应用ROI过滤"""
    def _filter_by_position(self, boxes, roi_mask, stream_name):
        """根据位置过滤目标"""
    def _detect_crossing(self, boxes, roi_mask, stream_name):
        """检测越界行为"""
