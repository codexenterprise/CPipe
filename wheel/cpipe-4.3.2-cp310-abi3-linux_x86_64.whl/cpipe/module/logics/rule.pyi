class CRule:
    @staticmethod
    def done(*args, **kwargs): ...
    @staticmethod
    def undone(*args, **kwargs): ...
    @staticmethod
    def compute_horizontal_contained_angle(bboxes, *args, **kwargs): ...
    @staticmethod
    def base_compute_horizontal_contained_angle(box1, box2, angle_threshold): ...
    @staticmethod
    def iou_with_name(bboxes, *args, **kwargs): ...
    @staticmethod
    def iou_with_subName(bboxes, *args, **kwargs): ...
    @staticmethod
    def ious_with_name(bboxes, *args, **kwargs): ...
    @staticmethod
    def in_the_left(bboxes, *args, **kwargs): ...
    @staticmethod
    def in_the_right(bboxes, *args, **kwargs): ...
    @staticmethod
    def exist_labels(bboxes, *args, **kwargs): ...
    @staticmethod
    def find_labels(bboxes, *args, **kwargs): ...
    @staticmethod
    def point_in_box(point, box): ...
    @staticmethod
    def xywhr2xyxyxyxy(center): ...
    @staticmethod
    def is_box_inside(inner_box, outer_box):
        """
        判断一个box是否在另外一个box的内部
        :param inner_box: 内部box的坐标 (x1, y1, x2, y2)
        :param outer_box: 外部box的坐标 (x1, y1, x2, y2)
        :return: True 如果inner_box在outer_box内部，否则 False
        """
    @staticmethod
    def is_box_center_inside(inner_box, outer_box):
        """
        判断一个box的中心点是否在另外一个box的内部
        :param inner_box: 内部box的坐标 (x1, y1, x2, y2)
        :param outer_box: 外部box的坐标 (x1, y1, x2, y2)
        :return: True 如果inner_box在outer_box内部，否则 False
        """
    @staticmethod
    def box_padding(box, padding, image_hw) -> None: ...
    @staticmethod
    def box_iou(box1, box2):
        """
        Return the IoU of two bounding boxes
        """
    @staticmethod
    def point_in_polygon(point, polygon):
        """
        判断点是否在多边形内部
        :param point: 待检测的点 (x, y)
        :param polygon: 多边形顶点列表 [(x1, y1), (x2, y2), ..., (xn, yn)]
        :return: True 如果点在多边形内部或边界上，否则 False
        """
    @staticmethod
    def polygons_intersect_with_box(polygon1, box):
        """
        判断两个多边形是否有交集（包含边界接触）
        :param polygon1: 多边形1顶点列表 [(x1, y1), ...]
        :param box: 检测框 (x1, y1, x2, y2)
        :return: True 有交集或边界接触，False 无交集
        """
    @staticmethod
    def point_in_rectangle(point, box): ...
