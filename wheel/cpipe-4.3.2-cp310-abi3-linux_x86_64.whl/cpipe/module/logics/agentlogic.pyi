from _typeshed import Incomplete
from cpipe.module.cdata import CData as CData
from cpipe.module.logic import Logic as Logic
from typing import Annotated

class AgentLogic(Logic):
    '''
    Agent智能Logic - 集成LLM，可以用自然语言描述逻辑规则
    
    使用场景:
    - 复杂的业务逻辑判断
    - 需要上下文理解的场景
    - 自动生成报警信息
    
    示例提示词:
    - "当检测到3个以上的人在门口停留超过10秒，生成告警"
    - "如果画面中出现车辆和人同时存在，且距离小于2米，发出警告"
    - "统计过去1分钟内进入区域的人数，如果超过50人，触发告警"
    '''
    agent_prompt: Annotated[str, 'Agent提示词']
    enable_llm: Annotated[bool, '启用LLM']
    llm_model: Annotated[str, 'LLM模型']
    llm_api_key: Annotated[str | None, 'API Key']
    llm_api_base: Annotated[str | None, 'API Base URL']
    context_seconds: Annotated[float, '上下文时间窗口']
    history_data: list
    last_decision: dict
    def _start(self) -> None:
        """自动执行"""
    llm: Incomplete
    def _init_llm(self) -> None:
        """初始化LLM客户端"""
    def _add_to_history(self, cdata: CData):
        """添加数据到历史记录"""
    def _make_decision(self, cdata: CData) -> dict:
        """执行决策"""
    def _build_context(self, cdata: CData) -> dict:
        """构建上下文信息"""
