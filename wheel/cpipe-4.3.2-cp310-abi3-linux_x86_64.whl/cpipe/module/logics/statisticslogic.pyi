from cpipe.module.cdata import CData as CData
from cpipe.module.logic import Logic as Logic
from typing import Annotated, Literal

class StatisticsLogic(Logic):
    """
    统计Logic - 自动统计和聚合数据
    
    使用场景:
    - 人流量统计
    - 车流量统计  
    - 停留时间分析
    - 热力图生成
    """
    stat_type: Annotated[Literal['count', 'flow', 'dwell_time', 'heatmap'], '统计类型']
    time_window: Annotated[float, '时间窗口（秒）']
    target_classes: Annotated[list, '目标类别']
    output_interval: Annotated[float, '输出间隔（秒）']
    statistics: dict
    last_output_time: float
    def _start(self) -> None:
        """自动执行"""
    def _update_statistics(self, cdata: CData):
        """更新统计数据"""
    def _cleanup_old_data(self, current_time) -> None:
        """清理过期数据"""
    def _output_statistics(self, cdata: CData):
        """输出统计结果"""
