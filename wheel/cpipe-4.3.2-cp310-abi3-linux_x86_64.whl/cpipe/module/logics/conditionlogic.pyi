from cpipe.module.cdata import CData as CData
from cpipe.module.logic import Logic as Logic
from typing import Annotated, Literal

class ConditionLogic(Logic):
    """
    条件判断Logic - 无需编码，纯配置化
    通过可视化配置条件表达式，满足条件才输出结果
    
    使用场景:
    - 目标数量达到阈值才告警
    - 特定类别的目标才处理
    - 目标停留时间判断
    """
    condition_type: Annotated[Literal['count', 'class_filter', 'score_threshold', 'area_threshold', 'time_threshold'], '条件类型']
    target_classes: Annotated[list[str], '目标类别列表']
    count_operator: Annotated[Literal['>', '>=', '<', '<=', '=='], '数量比较操作符']
    count_threshold: Annotated[int, '数量阈值']
    score_threshold: Annotated[float, '置信度阈值']
    min_area: Annotated[int, '最小面积']
    max_area: Annotated[int, '最大面积']
    time_seconds: Annotated[float, '时间阈值（秒）']
    pass_when_true: Annotated[bool, '条件为真时传递']
    target_history: dict
    def _start(self) -> None:
        """自动执行，无需用户编写代码"""
    def _apply_condition(self, cdata: CData) -> CData:
        """应用条件逻辑"""
    def _count_condition(self, cdata: CData) -> CData:
        """数量条件判断"""
    def _class_filter(self, cdata: CData) -> CData:
        """类别筛选"""
    def _score_filter(self, cdata: CData) -> CData:
        """置信度筛选"""
    def _area_filter(self, cdata: CData) -> CData:
        """面积筛选"""
    def _time_filter(self, cdata: CData) -> CData:
        """时间阈值判断（目标停留时间）"""
    @staticmethod
    def _compare(value, threshold, operator):
        """比较操作"""
    @staticmethod
    def _has_data(cdata: CData) -> bool:
        """检查是否有有效数据"""
