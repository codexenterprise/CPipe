import numpy as np
from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box, CData as CData
from cpipe.module.node import Node as Node, NodeType as NodeType
from typing import Annotated, Any, Callable, ClassVar, Sequence

class Logic(Node):
    node_type: Annotated[NodeType, 'The type of the node.']
    cmask_info: Annotated[dict, "The cmask info of the logic node. for example: {'streamer_name': {'mask_name': mask_info}}"]
    def get_cmask_info(self, wait_for_video_loaded: bool = True):
        """
        Get the cmask info of the logic node.
        Returns: The cmask info of the logic node. 
        for example: {'streamer_name': {'mask_name': mask_info}}, mask_info is a list of polygons. 
        if the video height or width is 0, the mask_info will be None. You can wait for the video to be loaded.
        """
    def _start(self) -> None:
        """
        Start the logic node.
        Returns: None

        """

class Frame:
    """
    One frame of one streamer, handed to a function decorated with ``cpipe.logic``.

    Attributes:
        streamer_name: The name of the streamer this frame comes from.
        node: The logic node running the function (``node.logger``, ``node.event_send`` ...).
        cdata: The raw CData of this round, shared by every streamer in it.
    """
    TEXT_START_XY: ClassVar[tuple[int, int]]
    TEXT_LINE_HEIGHT: ClassVar[int]
    node: Incomplete
    cdata: Incomplete
    streamer_name: Incomplete
    _image: Incomplete
    _text_lines: int
    def __init__(self, node: FunctionLogic, cdata: CData, streamer_name: str) -> None: ...
    @property
    def boxes(self) -> list[Box]:
        """All boxes of this frame. Assign a new list to filter what downstream nodes receive."""
    @boxes.setter
    def boxes(self, boxes: Sequence[Box]): ...
    def boxes_of(self, *class_names: str) -> list[Box]:
        """Boxes whose box_class_name is one of class_names."""
    @property
    def image(self) -> np.ndarray:
        """The original frame (BGR). It is shared with other nodes, do not draw on it; use crop() or draw_*()."""
    @property
    def height(self) -> int: ...
    @property
    def width(self) -> int: ...
    @property
    def timestamp(self) -> float:
        """The time.time() when the streamer produced this frame."""
    def crop(self, box: Box, pad: int = 0) -> np.ndarray:
        """A copy of the image region of box, expanded by pad pixels on each side."""
    def roi(self, name: str) -> np.ndarray | None:
        """Pixel polygon of the ROI drawn on the web page for this node, or None if it is not drawn."""
    def in_roi(self, box: Box, name: str, anchor: str = 'center') -> bool:
        '''
        Whether box is inside the ROI. An ROI that is not drawn yet covers the whole frame.
        Args:
            anchor: "center" uses the box center, "bottom" the bottom center (feet of a person).
        '''
    def _shows(self) -> list: ...
    def draw_text(self, text: str, xy: tuple[int, int] | None = None, color: tuple[int, int, int] = (0, 0, 255), size: int = 40):
        """Draw text on the CPipeInsight page. Without xy, texts are stacked from the top-left corner."""
    def draw_line(self, p1: tuple[int, int], p2: tuple[int, int], color: tuple[int, int, int] = (0, 0, 255), thickness: int = 2): ...
    def draw_polygon(self, points: Sequence[tuple[int, int]], color: tuple[int, int, int] = (0, 0, 255), thickness: int = 2): ...
    def message(self, text: str):
        """Show a line in the message panel of this streamer on the CPipeInsight page."""

class FunctionLogic(Logic):
    """
    Logic node whose per-frame behaviour is a plain function. Create subclasses with ``cpipe.logic``.
    """
    frame_func: ClassVar[Callable[[Frame], Any] | None]
    preset_rois: ClassVar[tuple[str, ...]]
    ERROR_LOG_INTERVAL: ClassVar[float]
    def __init__(self, *args, **kwargs) -> None: ...
    def _start(self) -> None: ...

def logic(func: Callable[[Frame], Any] | None = None, *, rois: Sequence[str] = ()):
    '''
    Turn a function that handles one Frame into a Logic node class.

    Example:
        import cpipe as cp

        @cp.logic(rois=["area"])
        def intrusion(frame: cp.Frame):
            for box in frame.boxes_of("person"):
                if frame.in_roi(box, "area", anchor="bottom"):
                    frame.draw_text("有人闯入!")

        stream += [detect, intrusion(), cpipeinsight]

    Args:
        func: The function called once per streamer frame. Its return value is ignored;
              the frame, with any changes, is always passed to the next nodes.
        rois: ROI names to draw on the web page for this node, read with frame.roi(name) / frame.in_roi(box, name).
    Returns: A Logic node class named after the function; call it (with node_name=..., queue_size=...) to create the node.
    '''
