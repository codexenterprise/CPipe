from cpipe.config.config import *
from _typeshed import Incomplete
from cpipe.module.clogger import CLogger as CLogger
from cpipe.module.security import AESHelper as AESHelper, Security as Security, cp_m_i as cp_m_i, cp_m_p as cp_m_p
from cpipe.module.utils import cudaSetDevice as cudaSetDevice

class Cmodel:
    TRT_MODEL_LIST: Incomplete
    ONNX_MODEL_LIST: Incomplete
    TORCH_MODEL_LIST: Incomplete
    OM_MODEL_LIST: Incomplete
    RKNN_MODEL_LIST: Incomplete
    MODEL_TYPE_TRT: str
    MODEL_TYPE_ONNX: str
    MODEL_TYPE_TORCH: str
    MODEL_TYPE_RKNN: str
    MODEL_TYPE_OM: str
    MODEL_TYPE_TRITON: str
    logger: Incomplete
    node_name: Incomplete
    model_path: Incomplete
    model_type: Incomplete
    _warmup: Incomplete
    input_size: Incomplete
    _device: Incomplete
    input_names: Incomplete
    output_names: Incomplete
    max_batch_size: Incomplete
    triton_mode: Incomplete
    __model: Incomplete
    def __init__(self, node_name, model_path, input_size=None, max_batch_size=None, device: str = 'cuda:0', warmup: bool = True, input_names=None, output_names=None, triton_mode=None) -> None:
        '''
        Initialize a CPipe inference model instance.
        Args:
            node_name: Delete the mask of the node.
            model_path:The path of the model file.
            input_size: The size of the input image. None means get input size from model.
            max_batch_size: The maximum batch size of the model. None means get max batch size from model, ONNX model set 1 if is dynamic batch size.
            device: The device of the model. Default is "cuda:0".
            warmup: Whether to warm up the model.
            input_names: The input names of the model.
            output_names: The output names of the model.
            triton_mode: Whether to use triton mode, and triton mode: HTTP / GRPC / SHARE_MEMORY

        '''
    @classmethod
    def get_encryption_model(cls, model_path):
        """
        Get the encryption model.
        Args:
            model_path:The path of the model file.

        Returns: The encryption model.
        """
    @classmethod
    def onnx2tensorrt(cls, model_path, max_batch_size: int = 1, input_height=None, input_width=None, min_shapes=None, opt_shapes=None, max_shapes=None, input_names=None, fp16_mode: bool = True, int8_mode: bool = False, tf32_mode: bool = False):
        '''
        ONNX to TensorRT 
        
        Args:
            model_path:onnx/cpipe/codex model path
            max_batch_size: max batch size
            input_height: input height
            input_width: input width
            min_shapes: min input shape
            opt_shapes: opt input shape
            max_shapes: max input shape
            input_names: input names
            fp16_mode: use fp16 mode
            int8_mode: use int8 mode
            tf32_mode: use tf32 mode
        example:
            # no batch size
            from cpipe.module.cmodel import Cmodel
            Cmodel.onnx2tensorrt("./yolov10n.onnx", [(1, 3, 640, 640)], [(1, 3, 640, 640)], [(1, 3, 640, 640)], input_names=["images"], fp16_mode=True, int8_mode=False)
            # with dynamic batch size
            from cpipe.module.cmodel import Cmodel
            Cmodel.onnx2tensorrt("./yolov10n.onnx", [(1, 3, 640, 640)], (1, 3, 640, 640), [(16, 3, 640, 640)], input_names=["images"], fp16_mode=True, int8_mode=False)
        Returns:
            True: success
            False: failed
        '''
    @staticmethod
    def get_model_type(model_path):
        """
        Get the model type from the model path.
        Args:
            model_path:The path of the model file.

        Returns: The model type.

        """
    def _model(self, input_data, input_dict=None, vaild_indexes=None):
        """
        The model inference function.
        Args:
            input_data: The input data.
            input_dict: The input dictionary. e.g. {'input_name1': input_data, 'input_name2': input_data2, ...}. inputs or input_dict is required.
            vaild_indexes: The valid indexes of the input_dict.
        Returns: The model inference result.

        """
    def om_loadModel(self, model_path):
        """
        Load the OM model(HUAWEI Ascend).
        Args:
            model_path:The path of the model file.

        Returns: The model.

        """
    @staticmethod
    def inspect_rknn(rknn_lite):
        """
        Use RKNN runtime to parse the input information of the RKNN model.
        Args:
            rknn_lite: The RKNNLite object after init_runtime.

        Returns: A dictionary containing model information.
        """
    def rknn_loadModel(self, model_path):
        """
        Load the RKNN model.
        Args:
            model_path:The path of the model file.
            input_size: The size of the input image. None means get input size from model.
            max_batch_size: The maximum batch size of the model. None means get max batch size from model(RKNN model is static shape, batch is dims[0]).
            device: The device of the model. eg: RKNNLite.NPU_CORE_AUTO
                        NPU_CORE_AUTO  = 0                                   # default, run on NPU core randomly.
                        NPU_CORE_0     = 1                                   # run on NPU core 0.
                        NPU_CORE_1     = 2                                   # run on NPU core 1.
                        NPU_CORE_2     = 4                                   # run on NPU core 2.
                        NPU_CORE_0_1   = 3                                   # run on NPU core 1 and core 2.
                        NPU_CORE_0_1_2 = 7                                   # run on NPU core 1 and core 2 and core 3.
                        NPU_CORE_ALL   = 0xffff                              # run on all NPU cores.
            input_names: The input names of the model.
            output_names: The output names of the model.

        Returns: The model, input names, output names.

        """
    @staticmethod
    def inspect_tensorrt(engine, trt):
        """
        Use TensorRT to parse the input information of the model.
        Args:
            engine: The engine of the model.
            trt: The TensorRT module.

        Returns: A dictionary containing model information.
        """
    def trt_loadModel(self, model_path):
        """
        Load the TensorRT model.
        Args:
            model_path:The path of the model file.
            input_size: The size of the input image. None means get input size from model.
            max_batch_size: The maximum batch size of the model. None means get max batch size from model.
            device: The device of the model.
            input_names: The input names of the model.
            output_names: The output names of the model.

        Returns: The model, input names, output names.

        """
    @staticmethod
    def inspect_onnx(onnx_session):
        """
        Use onnxruntime to parse the input information of the ONNX model.
        Args:
            onnx_session: onnxruntime.InferenceSession object

        Returns: A dictionary containing model information.
        """
    def onnx_loadModel(self, model_path):
        """
        Load the ONNX model.
        Args:
            model_path:The path of the model file.

        Returns: The model, input names, output names.

        """
    def torch_loadModel(self, model_path):
        """
        Load the TorchScript model.
        Args:
            model_path:The path of the model file.

        Returns: The model, [], [].

        """
    def triton_loadModel(self, model_path):
        """
        Load the Triton model.
        Args:
            model_path:The Triton model name.

        Returns: The model.

        """
    def loadModel(self, model_path) -> None:
        """
        Load the model.
        Args:
            model_path:The path of the model file.

        Returns: None

        """
    def __call__(self, inputs, list_mode: bool = False, input_dict=None, copy_model: bool = False):
        """
        Model inference function.
        Args:
            inputs: The input data(batch_imgs).
            list_mode: Whether to return the result in list mode.
            input_dict: The input dictionary. e.g. {'input_name1': input_data, 'input_name2': input_data2, ...}. inputs or input_dict is required.
            copy_model: Whether to each batch inference copy the input_dict.

        Returns: The model inference result.

        """
