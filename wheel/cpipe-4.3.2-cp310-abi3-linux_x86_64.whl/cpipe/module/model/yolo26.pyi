import numpy as np
from _typeshed import Incomplete
from cpipe.module.cinferencer import CClassifier as CClassifier, CInstanceSegmentation as CInstanceSegmentation, CPose as CPose
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.dataprocessing import class_preprocess as class_preprocess, load_data as load_data, non_max_suppression as non_max_suppression, preprocess_yolov7 as preprocess_yolov7, preprocess_yolov7_rknn as preprocess_yolov7_rknn, scale_coords as scale_coords, scale_coords_points as scale_coords_points
from cpipe.module.model.yolov10 import YOLOv10 as YOLOv10
from typing import Annotated, Any

class YOLO26CLS(CClassifier):
    """
    MMShuffleNet can classify the image, for the model file from codex training platform.
    """
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    mean: Annotated[np.ndarray, 'The mean of the model.']
    std: Annotated[np.ndarray, 'The std of the model.']
    need_softmax: Annotated[bool, 'Whether to use softmax for post-processing.']
    def preprocess(self, frames, *args, **kwargs):
        """
        The preprocess function of the model.
        Args:
            frames: The frames.
            *args: frames_stream_names. eg ['stream1', 'stream2']
            **kwargs: The keyword arguments.

        Returns: The batch_imgs, frames, batch_size

        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """

class YOLO26(YOLOv10):
    """
    YOLOv26 can detect the objects in the image.
    """

def _to_tensor(data): ...
def _binary_masks(proto, coeffs, boxes, in_h, in_w):
    """Crop mask logits on the proto grid, then upsample once to the network input."""

class YOLO26InstanceSeg(CInstanceSegmentation):
    """
    YOLO26InstanceSeg segments objects. ONNX/TensorRT use the NMS-free head
    (det: N,300,6+nm and proto: N,nm,H/4,W/4). RKNN falls back to one-to-many and runs NMS.
    """
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    def __init__(self, *args, **kwargs) -> None: ...
    def _kept(self, det):
        """Keep detections above conf_thres. det is (N, 6+nm), already score-sorted."""
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:  frames_stream_names. eg. ['stream1', 'stream2']
            **kwargs:

        Returns: [[bbox_lst, polygon_lst, mask_lst], ...]

        """

class YOLO26Pose(CPose):
    """
    YOLO26Pose estimates keypoints. ONNX/TensorRT output is NMS-free (N, 300, 6+kpt*3).
    RKNN falls back to one-to-many and runs NMS. class_names are keypoint names.
    """
    preprocessor: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:
            **kwargs:

        Returns: predictions, pre_imgs, origin_imgs

        """
    def postprocess(self, inputs, *args, **kwargs): ...
