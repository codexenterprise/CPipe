from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box, Classification as Classification, LLMInfo as LLMInfo
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CFilePath as CFilePath, CIntList as CIntList, CNone as CNone, CStrList as CStrList
from cpipe.module.dataprocessing import letterbox as letterbox, load_data as load_data
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated, Any

MARKER: str
SYSTEM_PROMPT: str
PAD_QUESTION: Incomplete
NUM_GRID_PER_SIDE: int

def preprocess_decider(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for Decider, the output is a letterboxed RGB uint8 image (1, H, W, 3).
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def get_options(question):
    '''
    Get the options of one question.
    Args:
        question: {"type": "noul" / "choice" / "score", "instructions": str, "criteria": ...}

    Returns: option keys, option descriptions
    '''
def get_answer(question, logits, temperature):
    """
    Convert the logits of one question to the answer (the same format as the official pplx-decider).
    Args:
        question: the question
        logits: (num_codes,) logits of the question
        temperature: softmax temperature

    Returns: answer dict
    """
def get_position_ids(image_mask, grid_h, grid_w, length):
    """
    Get the M-RoPE position ids of one prompt with one image. Text tokens use the same index on (t, h, w),
    image tokens use (start, start + row, start + col), and the image takes max(grid_h, grid_w) positions.
    Args:
        image_mask: (T,) bool, True for the image tokens
        grid_h: rows of the image tokens
        grid_w: cols of the image tokens
        length: number of valid tokens, the positions of the padding tokens are 0

    Returns: (3, 1, T) int64
    """

class TRTSession:
    """
    A TensorRT engine with the interface of onnxruntime.InferenceSession. Cmodel is not used here because TRTModule
    does not support BF16 outputs: the logits of the batch 4/8 decoder engines are BF16 (batch 1 is FP32).
    """
    engine: Incomplete
    context: Incomplete
    dtypes: Incomplete
    input_names: Incomplete
    output_names: Incomplete
    def __init__(self, model_path, device_id) -> None: ...
    def get_inputs(self): ...
    def get_providers(self): ...
    def run(self, output_names, input_dict):
        """
        Model inference function.
        Args:
            output_names: not used, all outputs are returned
            input_dict: {input_name: numpy.ndarray}

        Returns: list of float32 numpy.ndarray
        """

class Decider(InferenceEngine):
    """
    Decider (Perplexity Decider Flash) can answer noul / choice / score questions about the image in one forward.
    One-stage mode: the whole frame. Two-stage mode: the boxes of secondary_class_names.
    """
    vision_model_path: Annotated[CFilePath, 'The path of the vision model. vision.onnx / vision_fp16.engine']
    embed_model_path: Annotated[CFilePath, 'The path of the embed model. embed.onnx (runs on CPU)']
    decoder_model_path: Annotated[CFilePath, 'The path of the decoder model (static batch / T / Q). decoder_t320.onnx / decoder_fp16.engine / decoder_b4_fp16.engine']
    ckpt_path: Annotated[CFilePath, 'The directory of the tokenizer / processor / config files.']
    questions: Annotated[dict, "The questions. key: box_class_name / streamer_name / 'default'. value: one noul / choice / score question, or {question_name: question}."]
    scene: Annotated[str, 'The scene description for the model.']
    gpu_mem_limit_gb: Annotated[float, 'The gpu_mem_limit of onnxruntime CUDA.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    model_path: Annotated[CNone, 'The path of the model.']
    input_size: Annotated[CIntList, 'The size of the input image [C, H, W], H and W are multiples of 32. e.g. [3, 320, 320]']
    class_names: Annotated[CStrList, 'The class names of the model.']
    temperature: Incomplete
    codes: Incomplete
    image_token_id: Incomplete
    hf_processor: Incomplete
    merge_size: Incomplete
    vision_utils: Incomplete
    marker_id: Incomplete
    pad_id: Incomplete
    special_tokens: Incomplete
    vision: Incomplete
    embed: Incomplete
    decoder: Incomplete
    model: Incomplete
    Q: Incomplete
    max_batch_size: Incomplete
    def _loadModel(self, model_path=None):
        """
        Load the processor and the vision / embed / decoder models of the current node.
        Args:
            model_path: not used

        Returns: None

        """
    def get_questions(self, streamer_name):
        '''
        Get the questions of one image. The key priority: secondary_class_names > streamer_name > "default".
        Args:
            streamer_name: The stream name of the image.

        Returns: {question_name: question}
        '''
    def escape(self, text):
        """Escape the special tokens in the user text."""
    def encode(self, rgb_image, questions):
        """
        Encode one image and its questions to the inputs of the vision / embed / decoder models.
        Args:
            rgb_image: (H, W, 3) uint8 RGB image
            questions: {question_name: question}

        Returns: dict of the model inputs
        """
    def preprocess(self, frames, *args, **kwargs):
        """
        Model input data preprocessing method.
        Args:
            frames: input data
            *args: frames_stream_names. eg ['stream1', 'stream2']
            **kwargs:

        Returns: batch_imgs, (N, H, W, 3) RGB uint8 on CPU

        """
    def infer(self, inputs, *args, **kwargs):
        """
        Model inference method.
        Args:
            inputs: batch_imgs
            *args: frames_stream_names. eg ['stream1', 'stream2']
            **kwargs:

        Returns: [{question_name: answer}, ...], None for the image that failed to encode

        """
    def _write(self, bbox, one_ret, streamer_name) -> None:
        """Write the answers of one image to the classification and llm_info of the Box."""
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
