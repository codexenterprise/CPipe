import torch
from _typeshed import Incomplete
from cpipe.module.cinferencer import CSemanticSegmentation as CSemanticSegmentation
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.node import Node as Node
from typing import Annotated, Any

def mm_ss_preprocessor(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for classification
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """

class MMSemanticSegmentation(CSemanticSegmentation):
    """
    MMSemanticSegmentation can segment the image.
    """
    mean: Annotated[torch.Tensor, 'The mean of the model.']
    std: Annotated[torch.Tensor, 'The std of the model.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    def preprocess(self, frames, *args, **kwargs): ...
    stdinv: Incomplete
    def before_start(self) -> None: ...
    def postprocess(self, inputs, *args, **kwargs): ...
