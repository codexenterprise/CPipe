from _typeshed import Incomplete
from cpipe.module.cinferencer import CFace as CFace
from cpipe.module.cvalidator import CFilePath as CFilePath, CNone as CNone, CStrList as CStrList
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.inferenceengine import Cmodel as Cmodel
from cpipe.module.node import Node as Node
from typing import Annotated, Any

arcface_dst: Incomplete

def estimate_norm(lmk, image_size: int = 112, mode: str = 'arcface'):
    """
    Estimate the normalization.
    Args:
        lmk: (np.ndarray) The landmark.
        image_size: (int) The image size.
        mode: (str) The mode.

    Returns: The normalization.

    """
def norm_crop(img, landmark, image_size: int = 112, mode: str = 'arcface'):
    """
    Normalize the image.
    Args:
        img: (np.ndarray) The image.
        landmark: (np.ndarray) The landmark.
        image_size: (int) The image size.
        mode: (str) The mode.

    Returns: The normalized image.

    """
def preprocessor_fun(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for classification
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """

class Adaface(CFace):
    """
    Adaface is a class for Adaface. It just can get the feature(embedding) of the image.
    """
    face_quality_model_path: Annotated[CFilePath | CNone, 'The path of the face quality model.']
    face_quality_thresh: Annotated[float, 'The face quality threshold.']
    output_names: Annotated[CStrList, 'The output names of the model.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    input_mean: float
    input_std: Incomplete
    bgr2gray_kernel: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    face_quality_model: Incomplete
    def before_start(self) -> None: ...
    @staticmethod
    def matching(embeddings, face_embeddings):
        """
        Matching function.
        Args:
            embeddings: The embeddings.
            face_library: The face library.

        Returns: The matching result.

        """
    model: Incomplete
    def get_embedding(self, imgs):
        """
        Get the embedding of the image.
        Args:
            imgs: (torch.Tensor) The image tensor.

        Returns:

        """
    def get_feat(self, imgs):
        """
        Get the feature of the image
        Args:
            imgs: (torch.Tensor) The image tensor.

        Returns: The feature of the image.

        """
    def infer(self, inputs, *args, **kwargs): ...
    def preprocess(self, inputs, *args, **kwargs): ...
