import torch
from cpipe.module.cdata import Box as Box
from cpipe.module.cvalidator import CStrList as CStrList
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated

def pad_resize(img, width, height):
    """
    Pad and resize the image.
    Args:
        img: The image.
        width: The width.
        height: The height.

    Returns: The padded and resized image.

    """
def preprocess(self, raw_bgr_image, num) -> None:
    """
    Preprocess the input image.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """

class RTMPose(InferenceEngine):
    """
    RTMPose can detect the hand pose in the image.
    """
    num_joints: Annotated[int, 'The number of joints.']
    mean: Annotated[torch.Tensor, 'The mean of the model.']
    std: Annotated[torch.Tensor, 'The std of the model.']
    output_names: Annotated[CStrList, 'The output names of the model.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    def before_start(self) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def postprocess(self, inputs, *args, **kwargs): ...
