import numpy as np
from cpipe.module.cinferencer import CClassifier as CClassifier
from cpipe.module.cvalidator import CBool as CBool
from cpipe.module.dataprocessing import load_data as load_data, mm_class_preprocess as mm_class_preprocess
from typing import Annotated, Any

class MMResnet50(CClassifier):
    """
    MMResnet50 can classify the image, for the model file from codex training platform.
    """
    mean: Annotated[np.ndarray, 'The mean of the model.']
    std: Annotated[np.ndarray, 'The std of the model.']
    need_softmax: Annotated[CBool, 'Whether to use softmax.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    def preprocess(self, frames, *args, **kwargs):
        """
        The preprocess function of the model.
        Args:
            frames: The frames.
            *args: frames_stream_names. eg ['stream1', 'stream2']
            **kwargs: The keyword arguments.

        Returns: The batch_imgs, frames, batch_size

        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """
