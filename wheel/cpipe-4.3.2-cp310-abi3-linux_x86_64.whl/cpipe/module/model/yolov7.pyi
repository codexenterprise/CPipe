from _typeshed import Incomplete
from cpipe.module.cinferencer import CDetector as CDetector
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CIntList as CIntList, CNone as CNone
from cpipe.module.dataprocessing import preprocess_yolov7_rknn as preprocess_yolov7_rknn, scale_coords as scale_coords
from typing import Annotated

class YOLOv7(CDetector):
    """
    YOLOv7 can detect the objects in the image.
    """
    anchor: Annotated[CIntList | CNone, 'The anchor of the model.']
    preprocessor: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:  frames_stream_names. eg. ['stream1', 'stream2']
            **kwargs:

        Returns:

        """
    def box_process(self, position, anchors): ...
    def filter_boxes(self, boxes, box_confidences, box_class_probs):
        """Filter boxes with box threshold. It's a bit different with origin yolov5 post process!

        # Arguments
            boxes: ndarray, boxes of objects.
            box_confidences: ndarray, confidences of objects.
            box_class_probs: ndarray, class_probs of objects.

        # Returns
            boxes: ndarray, filtered boxes.
            classes: ndarray, classes for boxes.
            scores: ndarray, scores for boxes.
        """
    def nms_boxes(self, boxes, scores):
        """Suppress non-maximal boxes.

        # Arguments
            boxes: ndarray, boxes of objects.
            scores: ndarray, scores of objects.

        # Returns
            keep: ndarray, index of effective boxes.
        """
    def post_process(self, input_data, anchors): ...
    def infer_onnx(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:  frames_stream_names. eg. ['stream1', 'stream2']
            **kwargs:

        Returns:

        """
