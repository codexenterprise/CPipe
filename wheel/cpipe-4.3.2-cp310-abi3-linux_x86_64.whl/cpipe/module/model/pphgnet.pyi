import torch
from cpipe.module.cdata import Box as Box, Person as Person
from cpipe.module.cinferencer import CEmbedding as CEmbedding
from cpipe.module.cvalidator import CStrList as CStrList
from cpipe.module.dataprocessing import embedding_preprocess as embedding_preprocess, load_data as load_data
from cpipe.module.node import Node as Node
from typing import Annotated, Any

class PPHGNet(CEmbedding):
    """
    PPHGNet can get the attribution of the image(person), the image is person image.
    """
    conf_thres: Annotated[float, 'The confidence threshold.']
    mean: Annotated[torch.Tensor, 'The mean of the node.']
    std: Annotated[torch.Tensor, 'The std of the node.']
    preprocessor: Annotated[Any, 'The processor of the node.']
    class_names: Annotated[CStrList, 'The attribute names of the model.']
    def before_start(self) -> None:
        """
        The function to be executed before the start of the model.
        Returns: None

        """
    def preprocess(self, frames, *args, **kwargs): ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
