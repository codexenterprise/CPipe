from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box, Person as Person
from cpipe.module.cinferencer import CDetector as CDetector
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CBool as CBool, CStrList as CStrList
from cpipe.module.dataprocessing import distance2bbox as distance2bbox, distance2kps as distance2kps, load_data as load_data, preprocess_retinaface as preprocess_retinaface
from cpipe.module.node import Node as Node
from typing import Annotated, Any

class Retinaface(CDetector):
    """
    Retinaface is a class for face detection model. It can detect the face in the image.
    """
    face_recognition_width_limit: Annotated[int, 'The face recognition width limit of pixel.']
    face_recognition_height_limit: Annotated[int, 'The face recognition height limit of pixel.']
    face_filtering: Annotated[CBool, 'The face filtering flag.']
    face_wh_ratio: Annotated[float, 'The face width and height ratio.']
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    save_person_image: Annotated[CBool, 'The save person image flag.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    output_names: Annotated[CStrList, 'The output names of the model.']
    det_thresh: Annotated[float, 'The detection threshold.']
    fmc: int
    _feat_stride_fpn: Incomplete
    _num_anchors: int
    use_kps: bool
    mean: float
    std: Incomplete
    _anchor_cache: Incomplete
    def _init_vars(self) -> None:
        """
        Initialize the variables.
        Returns: None

        """
    def preprocess(self, frames, *args, **kwargs): ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    def infer(self, inputs, *args, **kwargs): ...
