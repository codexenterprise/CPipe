from cpipe.module.cdata import Classification as Classification
from cpipe.module.cinferencer import CTemporal as CTemporal
from cpipe.module.cmodel import Cmodel as Cmodel
from typing import Annotated, ClassVar

class STGCN(CTemporal):
    """
    STGCN can classify tracked pose sequences with ONNX/TensorRT.
    """
    clip_len: Annotated[int, 'Number of frames used during model training.']
    topk: Annotated[int, 'Number of action predictions saved on each box.']
    NUM_KEYPOINTS: ClassVar[int]
    def setup(self) -> None:
        """
        Initialize the STGCN algorithm.
        Returns: None

        """
    def preprocess(self, box, frame):
        """
        Preprocess one pose frame for STGCN.
        Args:
            box: pose detection result
            frame: source image

        Returns: normalized pose tensor on the model device

        """
    def _uniform_sample(self, num_frames):
        """
        Uniformly sample frames with the MMAction2 test-time rule.
        Args:
            num_frames: number of source frames

        Returns: sampled frame indexes

        """
    def _interpolate_frames(self, input_buffer):
        """Linearly interpolate a short pose sequence along the time axis."""
    def build_input(self, input_buffer):
        """
        Build the input data for STGCN.
        Args:
            input_buffer: tracked pose sequence on the model device

        Returns: sampled model input

        """
    def postprocess(self, outputs):
        """Return the highest-scoring action classes for fall-rule processing."""
    @staticmethod
    def to_cdata(box, prediction) -> None:
        """Save the top-k action predictions to the tracked person box."""
