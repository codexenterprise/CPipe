from _typeshed import Incomplete
from cpipe.config.config import CLOGER_LEVEL as CLOGER_LEVEL, CLOGER_LEVEL_DEBUG as CLOGER_LEVEL_DEBUG
from cpipe.module.cvalidator import CBool as CBool, CNone as CNone
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated

class HumanFLowStatistics(InferenceEngine):
    '''
    HumanFLowStatistics can count the human flow in the image, you need to set the area flag and the area info(must have "__in__", "__out__").
    '''
    model_path: Annotated[CNone, 'The model path.']
    missing_count_thres: Annotated[int, 'The missing count threshold.']
    area_flag: Annotated[CBool, 'The area flag.']
    dump_images: Annotated[CBool, 'The dump images flag.']
    class_names: Annotated[CNone, 'The class names of the model.']
    in_and_out_line: Incomplete
    in_and_out_count: Incomplete
    list_overlapping_line_in: Incomplete
    list_overlapping_line_out: Incomplete
    in_out_masks: Incomplete
    missing_count: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def get_streamer_area(self) -> None: ...
    def _start(self) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    def is_cross_line(self, center_x: int, center_y: int, track_id: int, name: str):
        """
        judge whether the track is across the line.
        Args:
            center_x: (int) The center x.
            center_y: (int) The center y.
            track_id: (int) The track id.
            name: (str) The name.

        """
