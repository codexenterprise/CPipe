import numpy as np
from cpipe.module.cinferencer import CClassifier as CClassifier
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.dataprocessing import class_preprocess as class_preprocess, class_preprocess_rknn as class_preprocess_rknn, load_data as load_data, mm_class_preprocess as mm_class_preprocess
from typing import Annotated, Any

class MMShuffleNet(CClassifier):
    """
    MMShuffleNet can classify the image, for the model file from codex training platform.
    """
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    mean: Annotated[np.ndarray, 'The mean of the model.']
    std: Annotated[np.ndarray, 'The std of the model.']
    need_softmax: Annotated[bool, 'Whether to use softmax for post-processing.']
    def preprocess(self, frames, *args, **kwargs):
        """
        The preprocess function of the model.
        Args:
            frames: The frames.
            *args: frames_stream_names. eg ['stream1', 'stream2']
            **kwargs: The keyword arguments.

        Returns: The batch_imgs, frames, batch_size

        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """

class ShuffleNet(CClassifier):
    """
    ShuffleNet can classify the image.
    """
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    def __init__(self, *args, **kwargs) -> None: ...
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """
    def infer_rknn(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """
