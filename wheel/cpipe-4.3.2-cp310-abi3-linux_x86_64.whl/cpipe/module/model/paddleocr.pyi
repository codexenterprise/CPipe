from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CIntList as CIntList, CNone as CNone, CStrList as CStrList
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.model.paddleplate import boxes_from_bitmap as boxes_from_bitmap, normalize_det_image as normalize_det_image, resize_det_image as resize_det_image, to_numpy as to_numpy
from cpipe.module.node import Node as Node
from typing import Annotated, Literal

CLS_MEAN: Incomplete
CLS_STD: Incomplete

class PaddleOCR(InferenceEngine):
    """
    PaddleOCR is a class for PaddleOCR model.

    cls_model_path is the text-line orientation classifier (0 degree or 180 degree).
    A 180 degree line is rotated before recognition. Leave it empty to skip.
    """
    keys_txt_path: Annotated[CFilePath, 'The path of the keys txt file.']
    cls_model_path: Annotated[CFilePath | CNone, 'Text line orientation model, 0 or 180 degree. Empty skips it.']
    rotate_tall: Annotated[CBool, 'Rotate 90 degrees counterclockwise when the image height is greater than its width.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    input_size: Annotated[CIntList, 'The size of the input image.']
    cls_model: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def _loadModel(self, model_path=None) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    @staticmethod
    def pre_process(self, raw_bgr_image, num) -> None: ...
    def _correct_textline(self, frames):
        """Rotate a text line 180 degrees when the classifier says it is upside down."""
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def postprocess(self, inputs, *args, **kwargs):
        """
        Post process method.
        Args:
            inputs: The inputs.
            *args:
            **kwargs:

        Returns:

        """

class PaddleOCRv6(PaddleOCR): ...

class PaddleOCRDet(InferenceEngine):
    '''
    PP-OCRv6 text detection.

    Official postprocess: thresh 0.2, box_thresh 0.45, unclip_ratio 1.4.
    Boxes are text quads. A following PaddleOCR node can recognize them with secondary_class_names=["text"].
    '''
    class_names: Annotated[CStrList, 'The class names of the model.']
    det_limit_side_len: Annotated[int, 'Resize limit for detection. min grows the short side, max shrinks the long side.']
    det_limit_type: Annotated[Literal['min', 'max'], 'min grows the short side to the limit. max shrinks the long side to the limit.']
    det_thresh: Annotated[float, 'Binarization threshold of the detection map.']
    box_thresh: Annotated[float, 'Minimum score of a text box.']
    unclip_ratio: Annotated[float, 'Expansion ratio of a detected text box.']
    max_candidates: Annotated[int, 'Maximum number of text boxes kept from one image.']
    def _detect(self, images, streamer_names=()): ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def postprocess(self, inputs, *args, **kwargs): ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
