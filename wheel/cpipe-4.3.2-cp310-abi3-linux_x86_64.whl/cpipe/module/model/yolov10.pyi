from _typeshed import Incomplete
from cpipe.module.cinferencer import CDetector as CDetector
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.dataprocessing import non_max_suppression as non_max_suppression, preprocess_yolov7_rknn as preprocess_yolov7_rknn, scale_coords as scale_coords

class YOLOv10(CDetector):
    """
    YOLOv10 can detect the objects in the image.
    """
    preprocessor: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def postprocess_rknn(self, output):
        """
        Decode the raw RKNN output into the same layout as the ONNX e2e output
        (batch, max_det, 6), so it can be consumed by the common logic in `infer`.

        Note: although YOLOv10/26 is NMS-free, ultralytics disables the end2end
        branch when exporting to RKNN (NPU does not support topk), so the .rknn
        model outputs the one2many head: (batch, 4 + nc, anchors) with xywh boxes,
        which requires NMS here.

        Args:
            output: np.ndarray of shape (batch, 4 + nc, anchors). e.g. (1, 84, 8400).

        Returns: torch.Tensor of shape (batch, max_det, 6): [x1, y1, x2, y2, score, cls]
        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:  frames_stream_names. eg. ['stream1', 'stream2']
            **kwargs:

        Returns:

        """
