from _typeshed import Incomplete

class TritonInference:
    model_name: Incomplete
    output_names: Incomplete
    dtype_map: Incomplete
    pb_utils: Incomplete
    to_dlpack: Incomplete
    from_dlpack: Incomplete
    infer: Incomplete
    grpcclient: Incomplete
    client: Incomplete
    httpclient: Incomplete
    def __init__(self, model_name: str, output_names: list, server_url: str = None, triton_mode: str = 'GRPC') -> None: ...
    def infer_gpu_shared(self, input_dict):
        """
        Use Triton Inference Server with GPU shared memory for inference.
        Args:
            input_dict: A dictionary where keys are input tensor names and values are torch.Tensor on GPU.

        Returns: A list of torch.Tensor outputs on GPU.
        """
    def infer_grpc(self, input_dict):
        """
        Use Triton Inference Server with GRPC for inference.
        Args:
            input_dict: A dictionary where keys are input tensor names and values are torch.Tensor.

        Returns: A list of numpy arrays outputs.
        """
    def infer_http(self, input_dict):
        """
        Use Triton Inference Server with HTTP for inference.
        Args:
            input_dict: A dictionary where keys are input tensor names and values are torch.Tensor.

        Returns: A list of numpy arrays outputs.
        """
    def __call__(self, inputs): ...
    def __del__(self) -> None: ...
