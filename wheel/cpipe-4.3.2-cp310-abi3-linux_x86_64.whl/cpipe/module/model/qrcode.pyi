from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box
from cpipe.module.cvalidator import CNone as CNone, CStrList as CStrList
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated

class QRCode(InferenceEngine):
    '''
    Decode a QR code with zxing-cpp and write the text onto ``box_text``.

    This node does not load a weight file. Detection comes from the upstream
    YOLO node. Two-stage mode is the one that matches a distant camera. Point
    ``secondary_class_names`` at the detector class, for example ``["qrcode"]``.
    The YOLO box is expanded by ``crop_padding`` before decoding. One-stage mode
    runs the decoder on the whole frame and creates a box for each code.
    '''
    model_path: Annotated[CNone, 'Unused. This node decodes with zxing-cpp and does not load a weight file.']
    class_names: Annotated[CStrList, 'Class name used when this node creates boxes.']
    crop_padding: Annotated[float, 'Expand each upstream box by this fraction of its width and height before decoding.']
    min_side: Annotated[int, 'Upscale a crop whose short side is below this many pixels, then decode again.']
    input_size: Annotated[CNone, 'Unused. This node does not run through Cmodel.']
    secondary_class_names: Annotated[CStrList, 'Class name used when this node creates boxes.']
    zxing: Incomplete
    hook_inputs: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def _loadModel(self, model_path=None) -> None:
        """
        Import zxing-cpp. There is no weight file to load.
        """
    def _pad_crop(self, image, box=None, **kwargs): ...
    def _crop(self, image, box): ...
    def _views(self, image): ...
    def _decode_zxing(self, image, scale): ...
    def _decode(self, image): ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
