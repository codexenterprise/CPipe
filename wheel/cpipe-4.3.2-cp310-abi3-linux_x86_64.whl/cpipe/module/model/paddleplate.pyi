from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CNone as CNone, CStrList as CStrList
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated, Literal

DET_MEAN: Incomplete
DET_STD: Incomplete

def load_charset(keys_txt_path, use_space_char: bool = True):
    """Index 0 is the CTC blank. A trailing space matches CTCLabelDecode."""
def resize_det_image(image, limit_side_len, limit_type, max_side_len: int = 2048):
    """Resize one side to the limit, snap both sides to 32, then cap the long side."""
def to_numpy(value): ...
def normalize_det_image(image): ...
def get_mini_boxes(contour): ...
def box_score_fast(bitmap, box): ...
def unclip_box(box, unclip_ratio): ...
def boxes_from_bitmap(pred, bitmap, dest_width, dest_height, box_thresh, unclip_ratio, min_size: int = 3, max_candidates: int = 1000): ...
def get_rotate_crop_image(image, points): ...
def resize_norm_rec_image(image, img_h, img_w): ...
def ctc_greedy_decode(logits, charset):
    """Greedy CTC. Accepts softmax or raw logits, shape [N, T, C]."""

class PaddlePlate(InferenceEngine):
    """PP-OCRv3 plate detector plus recognizer. Two-stage mode writes the plate onto the vehicle box_text."""
    det_model_path: Annotated[CFilePath, 'PP-OCRv3 plate detection model.']
    rec_model_path: Annotated[CFilePath, 'PP-OCRv3 plate recognition model.']
    keys_txt_path: Annotated[CFilePath, 'PP-OCR character dictionary, ppocr_keys_v1.txt.']
    model_path: Annotated[CNone, 'Unused. Detection and recognition use det_model_path and rec_model_path.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    det_limit_side_len: Annotated[int, 'Detection resize limit. 736 fits a vehicle crop. A full frame of small plates needs about 1600.']
    det_limit_type: Annotated[Literal['min', 'max'], 'min grows the short side to the limit. max shrinks the long side to the limit.']
    det_thresh: Annotated[float, 'Binarization threshold of the detection map.']
    box_thresh: Annotated[float, 'Minimum score of a plate box.']
    unclip_ratio: Annotated[float, 'Expansion ratio of a detected text box.']
    min_text_len: Annotated[int, 'Drop recognition results shorter than this.']
    max_text_len: Annotated[int, 'Drop recognition results longer than this.']
    use_space_char: Annotated[CBool, 'Append a space character, matching PP-OCR CTCLabelDecode.']
    charset: Incomplete
    model: Incomplete
    max_batch_size: Incomplete
    rec_model: Incomplete
    det_max_side_len: Incomplete
    def _loadModel(self, model_path=None) -> None: ...
    def _to_model_input(self, batch, model): ...
    def _detect_batch(self, images):
        """Pad a chunk to one height and width so TensorRT runs the crops in a single forward."""
    def _recognize(self, crops): ...
    def _recognize_images(self, images): ...
    def _make_plate(self, text, rec_score, box): ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs): ...
