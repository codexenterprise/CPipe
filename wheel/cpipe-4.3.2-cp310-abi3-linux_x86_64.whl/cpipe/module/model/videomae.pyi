import torch
from _typeshed import Incomplete
from cpipe.module.cinferencer import CClassifier as CClassifier
from cpipe.module.cvalidator import CBool as CBool
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.node import Node as Node
from typing import Annotated, Any

def get_resize_sizes(im_h, im_w, size): ...
def videomae_preprocess(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for video MAE
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """

class VideoMAE(CClassifier):
    """
    VideoMAE can classify the video frames.
    """
    preprocessor: Annotated[Any, 'The preprocessor of the node.']
    num_frames: Annotated[int, 'Number of frames for model inference.']
    warmup: Annotated[CBool, 'Whether to warm up the model.']
    mean: Annotated[torch.Tensor, 'The mean of the model.']
    std: Annotated[torch.Tensor, 'The std of the model.']
    input_buffers: Incomplete
    class_len: Incomplete
    def before_start(self) -> None:
        """
        The function to be executed before the start of the model.
        Returns: None

        """
    def preprocess(self, frames, *args, **kwargs):
        """
        Model input data preprocessing method.
        Args:
            inputs: input data
            *args:
            **kwargs:

        Returns: input data

        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0]: batch_imgs, inputs[1]: original image, inputs[2]: batch_size
            *args:
            **kwargs:

        Returns: The result of the model.

        """
