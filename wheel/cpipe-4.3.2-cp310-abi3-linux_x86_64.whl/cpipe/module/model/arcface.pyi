from cpipe.module.model.adaface import Adaface as Adaface

class Arcface(Adaface):
    """
    Arcface is a class for Adaface. It just can get the feature(embedding) of the image.
    """
    def get_feat(self, imgs):
        """
        Get the feature of the image
        Args:
            imgs: (torch.Tensor) The image tensor.

        Returns: The feature of the image.

        """
