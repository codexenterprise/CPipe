from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box, Person as Person
from cpipe.module.cmodel import Cmodel as Cmodel
from cpipe.module.cvalidator import CFilePath as CFilePath, CNone as CNone, CStrList as CStrList
from cpipe.module.model.adaface import Adaface as Adaface
from cpipe.module.model.facematching import FaceLibrary as FaceLibrary
from cpipe.module.node import Node as Node
from cpipe.module.service.toolkit import ToolResult as ToolResult
from typing import Annotated

class FaceRecognition(Adaface):
    """
    FaceRecognition is a class for face recognition model. It can recognize the face and the face library(or face images).
    """
    matching_score_thresh: Annotated[float, 'The matching score threshold.']
    face_images_path: Annotated[CNone | CFilePath, 'The path of the face images. The image after cropping the human face. default: ./face_images']
    faces_library: Annotated[FaceLibrary, 'The face library.']
    secondary_class_names: Annotated[CStrList, 'The class names of the model.']
    face_embeddings: Incomplete
    def load_face_library(self, update: bool = False) -> None: ...
    def update_face_image_event(self, data): ...
    def get_face_library_info_event(self, data): ...
    def add_face_to_library(self, face_name: str, image_path: str) -> ToolResult:
        '''
        Add the face images(support .png and .jpg format) to the face recognition library. 
        Args:
            face_name: (str) The name of the face.
            image_path: (str) The path of the face image. e.g. "./tmp_files/George.jpg"
        Returns: (str) The result of the face recognition library.
        '''
    def delete_face_name(self, face_name: str) -> ToolResult: ...
    def list_face_names(self) -> ToolResult: ...
    def get_feat(self, imgs):
        """
        Get the feature of the image
        Args:
            imgs: (torch.Tensor) The image tensor.

        Returns: The feature of the image.

        """
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
