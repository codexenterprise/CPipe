from _typeshed import Incomplete
from cpipe.module.cinferencer import CEmbedding as CEmbedding
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CIntList as CIntList, CNone as CNone, CStrList as CStrList
from cpipe.module.model.adaface import Adaface as Adaface
from cpipe.module.model.arcface import Arcface as Arcface
from cpipe.module.node import Node as Node
from typing import Annotated, Literal

class FaceLibrary:
    face_embeddings: Incomplete
    face_names: Incomplete
    face_images_path: Incomplete
    face_model: Incomplete
    gray_mode: Incomplete
    input_size: Incomplete
    def __init__(self, face_embeddings=None, face_names=None, face_images_path=None, face_model=None, gray_mode: bool = False, input_size=(112, 112)) -> None:
        '''
        FaceLibrary is a class for face library.
        Args:
            face_embeddings: (np.ndarray) The face embeddings.
            face_names: (list) The face names.
            face_images_path: (str) The path of the face images.
            face_model_config: (dict) The config of the face model. e.g. {"face_model_type": "adaface", "model_path": ""}
            gray_mode: (bool) The gray mode flag.
            input_size: (tuple) The input size. e.g. (112, 112)

        '''
    def get_features(self):
        """
        Get the features of the face images.
        Returns: The features of the face images.

        """

class FaceMatching(CEmbedding):
    """
        FaceMatching is a class for face embedding matching model.
    """
    secondary_class_names: Annotated[CStrList, 'The class names of the model.']
    matching_score_thresh: Annotated[float, 'The matching score threshold.']
    face_images_path: Annotated[CNone | CFilePath, 'The path of the face images. The image after cropping the human face.']
    matching: Annotated[Literal['cosine', 'euclidean'], 'The matching function.']
    face_model_type: Annotated[Literal['adaface', 'arcface'], "The type of the face model. e.g. 'adaface' or 'arcface'"]
    max_batch_size: Annotated[int, 'The max batch size.']
    input_size: Annotated[CIntList, 'The input size.']
    faces_library: Annotated[FaceLibrary, 'The face library.']
    class_names: Annotated[CNone, 'The class names of the model.']
    warmup: Annotated[CBool, 'Whether to warm up the model.']
    to_cdata: Incomplete
    _start: Incomplete
    def __init__(self, *args, **kwargs) -> None: ...
    def infer(self, inputs, *args, **kwargs): ...
    face_embeddings: Incomplete
    def before_start(self) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    def _start_secondary(self) -> None: ...
