from _typeshed import Incomplete
from cpipe.module.cdata import Box as Box
from cpipe.module.cvalidator import CFilePath as CFilePath, CStrList as CStrList
from cpipe.module.dataprocessing import load_data as load_data
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from typing import Annotated

def create_center_weight(input_size=[48, 48]): ...

class MoveNet(InferenceEngine):
    """
    MoveNet can detect the object pose in the image.
    """
    num_joints: Annotated[int | None, 'The number of joints.']
    hm_th: Annotated[float, 'The heatmap threshold.']
    feature_size: Incomplete
    center_weight: Incomplete
    range_weight_x: Incomplete
    range_weight_y: Incomplete
    class_names: Incomplete
    def before_start(self) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    @staticmethod
    def pre_process(self, raw_bgr_image, num): ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def maxPoint(self, heatmap, center: bool = True):
        """
        Get the max point of heatmap
        Args:
            heatmap: The heatmap.
            center: The center flag.

        Returns: The x, y of the max point.

        """
    def postprocess(self, inputs, *args, **kwargs):
        """
        Post process method.
        Args:
            inputs: The inputs.
            *args:
            **kwargs:

        Returns:

        """

class MoveNetPersonPose(InferenceEngine):
    """
    MoveNetPersonPose can detect the person pose in the image.
    """
    num_joints: Annotated[int, 'The number of joints.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    def before_start(self) -> None: ...
    def to_cdata(self, pred, new_cdata, frames, streamer_names, *args, **kwargs) -> None: ...
    def to_cdata_secondary(self, pred, new_cdata, streamer_names, box_idxes, boxes, *args, **kwargs) -> None: ...
    @staticmethod
    def pre_process(self, raw_bgr_image, num): ...
    def preprocess(self, frames, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def postprocess(self, inputs, *args, **kwargs):
        """
        Post process method.
        Args:
            inputs: The inputs.
            *args:
            **kwargs:

        Returns:

        """
