from cpipe.config.config import *
import multiprocessing
import threading
from _typeshed import Incomplete
from cpipe.module.cbuffer import CBuffer as CBuffer
from cpipe.module.cdata import CData as CData, CImage as CImage
from cpipe.module.cevent import CEventQueue as CEventQueue
from cpipe.module.clogger import CLogger as CLogger
from cpipe.module.cmask import CMask as CMask
from cpipe.module.cqueue import BaseQueue as BaseQueue, CQueue as CQueue
from cpipe.module.cvalidator import CBool as CBool
from cpipe.module.discovery import Discovery as Discovery
from cpipe.module.security import Security as Security
from cpipe.module.utils import get_node_subclasses as get_node_subclasses
from enum import Enum
from pydantic import BaseModel
from typing import Annotated, Any, ClassVar, Literal

class NodeType(str, Enum):
    Streamer = 'Streamer'
    Other = 'Other'
    Algorithm = 'Algorithm'
    Insight = 'Insight'
    Logic = 'Logic'
    Report = 'Report'
    Nodes = 'Nodes'

class Node(BaseModel):
    model_config: Incomplete
    TYPE_Streamer: ClassVar[NodeType]
    TYPE_Algorithm: ClassVar[NodeType]
    TYPE_Insight: ClassVar[NodeType]
    TYPE_Logic: ClassVar[NodeType]
    TYPE_Report: ClassVar[NodeType]
    TYPE_Nodes: ClassVar[NodeType]
    NODE_STATE_ALIVE: ClassVar[int]
    NODE_STATE_DEAD: ClassVar[int]
    CPIPE_EXIT_WAIT_TIME: ClassVar[float]
    EVENT_UPDATE_MASK: ClassVar[str]
    EVENT_PAUSE_NODE: ClassVar[str]
    EVENT_GET_WRITABLE_FIELDS: ClassVar[str]
    EVENT_SET_UNWORKING_CONSUMER_NAMES: ClassVar[str]
    __allNodes__: Incomplete
    __PAIRS__: Incomplete
    __NEED_RESTART__: Incomplete
    __NEED_EXIT__: Incomplete
    __CPIPE_PID__: Incomplete
    __LAUNCH_CONFIG_PATH__: Incomplete
    __SPUORT_NODES__: Incomplete
    __SPUORT_NODE_NAMES__: Incomplete
    __exiting__: Incomplete
    logger: ClassVar[CLogger]
    node_name: Annotated[str, 'The name of the node.']
    queue_size: Annotated[int, 'The size of the queue.']
    banding_streamer_list: Annotated[dict, 'The list of the banding streamer nodes. The key is the streamer name, the value is the streamer node.']
    inputs: Annotated[list[BaseQueue], 'The list of the inputs(BaseQueue) of the node.']
    node_type: Annotated[NodeType, 'The type of the node.']
    queue: Annotated[CQueue, 'The queue of the node.']
    event_queue: Annotated[CEventQueue, 'The event queue of the node.']
    event_callback: Annotated[dict, 'The event callback of the node.']
    group_node: Annotated[dict, 'The group node of the node.']
    parent_node_name: Annotated[str | None, 'The parent node name of the node.']
    processor: Annotated[multiprocessing.Process | None, 'The processor of the node.']
    daemon: Annotated[CBool, 'The daemon of the node.']
    event_thread: Annotated[threading.Thread | None, 'The event thread of the node.']
    pid: Annotated[Any, 'The pid of the node.']
    exit_code: Annotated[Any, 'The exit code of the node.']
    ready_flag: Annotated[Any, 'The ready of the node.']
    state: Annotated[Any, 'The state of the node.']
    pause: Annotated[Any, 'If True, the node will be paused.']
    death_num: Annotated[int, 'The death num of the node.']
    special_mask: Annotated[dict, 'The special mask of the node.']
    dump_frame_history: Annotated[dict, 'The dump frame history of the node.']
    startup_functions: Annotated[list, 'The startup functions of the node.']
    just_validate_magic: Annotated[Literal['False'], 'just validate magic.']
    event_queue_size: Annotated[int, 'The size of the event queue.']
    def __init__(self, *args, **kwargs) -> None:
        """
        CPipe node base class.
        """
    def __hash__(self): ...
    @classmethod
    def _coerce_node_name(cls, v): ...
    @staticmethod
    def on_startup(order: int = 0):
        """
        decorator: a function that takes another function as input and returns a new function with additional functionality.
        Args:
            order: the order of the function, the smaller the number, the earlier the execution, the default is 0
        """
    @staticmethod
    def event(event_name):
        """
        decorator: a function that takes another function as input and returns a new function with additional functionality.
        Args:
            event_name: (str) The name of the event.
        """
    @staticmethod
    def agent_tool(name: str, description: str, parameters: dict):
        """
        Register the agent tool.
        Args:
            name: (str) The name of the tool.
            description: (str) The description of the tool.
            parameters: (dict) The parameters of the tool.
        """
    @classmethod
    def get_agent_tools(cls):
        """
        Get the agent tools of the node.
        Returns:
            dict: The agent tools of the node. The key is the tool name, the value is the tool information.
            The tool information is a dictionary with the following keys:
            - name: (str) The name of the tool.
            - description: (str) The description of the tool.
            - parameters: (dict) The parameters of the tool.
        """
    def event_register(self, event: str, callback: Any):
        """
        Register the event callback function.
        Args:
            event: (str) The event name.
            callback: (Any) The callback function.
        """
    def set_unworking_consumer_names(self, data):
        '''
        set node names to working or unworking in the current node.
        Args:
            data: format: {"working": ["node name1", ...], "unworking": ["node name2", ...]}
        Returns: new unworking consumer names
        '''
    def update_mask(self, data) -> None:
        """
        Update the mask of the streamer.
        Args:
            data: (Any) The data. The data need to be serializable(mutilprocessing.Queue).
        """
    def pause_node(self, data):
        """
        Pause the node.
        Args:
            data: (bool) If True, the node will be paused.
        """
    def get_writable_fields(self, data):
        """
        Get the writable fields of the node.
        Returns:
            dict: The writable fields of the node.
        """
    def _event_thread(self) -> None:
        """
        The event thread.
        """
    def event_send(self, event: str, data: Any | None = None, timeout: float = 120.0):
        """
        Send the event to the event thread and wait for its response.

        Thread-safe: this can be called concurrently (e.g. from multiple HTTP
        requests) against the same node without responses being mixed up
        between callers.

        Args:
            event: (str) The event name.
            data: (Any) The data. The data need to be serializable(mutilprocessing.Queue).
            timeout: (float) Max seconds to wait for the event callback to respond.
                Pass a larger value for events whose callback can legitimately take a long time (e.g. an event that triggers an LLM call).
        Returns: (Any) The return value of the event callback function, or `None`
            if the call timed out (the timeout is logged as an error).
        """
    def preset_mask(self, mask_name, mask_type, required: bool = False) -> None:
        '''
        Set the special mask for the node.
        Args:
            mask_name: (str) The name of the mask. Note: The mask name must be unique. if required is True, the mask name will be changed to __{mask_name}__
            mask_type: (str) The type of the mask. e.g. "polygons" or "lines"
            required: (bool) Whether the mask is required.
        '''
    @classmethod
    def save_all_nodes(cls, file_path) -> None: ...
    @classmethod
    def load_all_nodes(cls, file_path) -> None: ...
    def lastly(self, signum, frame) -> None:
        """
        The last function to be executed before the node is terminated.
        Args:
            signum: (int) The signal number.
            frame: (frame) The frame.

        Returns:

        """
    def close(self, exit_flag: bool = False) -> None:
        """
        Close the node, the node will be clear shared memory, if used share memory.
        Returns:

        """
    def ready(self) -> None:
        """
        Set the node to ready state.
        Returns None
        """
    def unready(self) -> None:
        """
        Set the node to unready state.
        Returns: None

        """
    def is_ready(self):
        """
        Check if the node is ready.
        Returns: (bool) True or False.

        """
    def get_pid(self):
        """
        Get the PID of the node.
        Returns: (int) The PID of the node.

        """
    def get_exitcode(self):
        """
        Get the exit code of the node.
        Returns: (int) The exit code of the node.

        """
    def get_state(self):
        """
        Get the state of the node. 0: alive(Node.NODE_STATE_ALIVE), 1: dead(Node.NODE_STATE_DEAD)
        Returns:

        """
    def get_frames(self, wait_time: int = 0, block: bool = True, need_all_frames: bool = False):
        """
        Get all frames from the input queue.
        Args:
            wait_time: (float)In blocking mode(block=True), this parameter takes effect, at least one frame is obtained, otherwise it will wait for wait_time seconds before returning.
            block: (bool) Whether to block.
            need_all_frames: (bool) Whether to get all frames.

        Returns: (CData) The data of the frames.

        """
    def get_streamer_frame(self, cimage: CImage):
        """
        Get the frame from the streamer.
        Args:
            cimage: (CImage) The image object.

        Returns: (np.ndarray) The frame, (float) The timestamp when this frame was generated.

        """
    def get_cbuffer_with_streamer_name(self, streamer_name):
        """
        Get the cbuffer with the streamer name.
        Args:
            streamer_name: (str) The name of the streamer.
        """
    def __create_node_buffer(self, queue_size, buffer_size=None) -> None:
        """
        Create the node buffer.
        Args:
            queue_size: (int) The size of the queue.
            buffer_size: (tuple) The size of the buffer.

        Returns: None

        """
    def set_input_queue(self, queues: list[BaseQueue]):
        """
        Set the input queue for the current node, these queues will subscribe to the output queue of the current node.
        Args:
            queues: (List[BaseQueue]) The input queue.

        Returns:

        """
    def feed_to(self, nodes: list['Node']):
        """
        Feed to the list of input nodes, for example: [node1, node2, node3], all input nodes will subscribe to the output queue of the current node.
        Args:
            nodes: (List['Node']) The input nodes. For example: [node1, node2, node3]

        Returns: self

        """
    def __str__(self) -> str:
        """
        Get the string of the node.
        Returns: (str) The string of the node.

        """
    def __add__(self, others):
        """
        Overload the addition operator, add the current node to other nodes, that is, the other nodes are the subsequent nodes of the self node.
        Args:
            others: (Node) The input node.

        Returns: self

        """
    def start_processor(self, inference_mode: bool = False) -> None: ...
    def start(self) -> None:
        """
        Start the node, the node will start a new process to run.
        Returns: None

        """
    def _start(self) -> None:
        """
        The entry function for the current node (process) to run, all the logic processing of the current node is completed here.
        Returns: None

        """
    @classmethod
    def get_captain_names(cls):
        """
        Get all the captain names. Captain: The node that has the Streamer node as the input.
        Returns: (List[str]) The list of captain names.

        """
    def get_my_captain_names(self):
        """
        Get the captain names of the current node. Captain: The node that has the Streamer node as the input.
        Returns: (List[str]) The list of captain names.

        """
    @classmethod
    def terminate(cls, exit_flag: bool = False, clear_nodes: bool = False) -> None:
        """
        Terminate all nodes of CPipe.
        Args:
            clear_nodes: (bool) Whether to clear all nodes.
            exit_flag: (bool) Whether to exit CPipe.

        Returns:

        """
    @classmethod
    def restart(cls, delay: int = 1) -> None:
        """
        Restart CPipe.
        Args:
            delay: (int) The delay time before restarting.

        Returns:

        """
    @classmethod
    def exit(cls, info=None, delay: int = 1) -> None:
        """
        Exit CPipe.
        Args:
            info: (str) The exit information.
            delay: (int) The delay time before exiting

        Returns:

        """
    @staticmethod
    def import_node(package_str, parameters, just_validate_parameters: bool = False):
        """
        Import the node class from the package string and create the node object.
        Args:
            package_str: (str) The package string.
            parameters: (dict) The parameters of the node.
            just_validate_parameters: (bool) Whether to validate the parameters.

        Returns: (Node) The node object. or (str) The error message.
        """
    @classmethod
    def init_support_nodes(cls) -> None:
        """
        Init the support nodes.
        Returns: None
        """
    @classmethod
    def create_link_from_json(cls) -> None:
        '''
        Create node connection relationships and initialize nodes based on the configuration file (launch.yaml).
        launch.yaml path: configured through Node.launch(launch_config_path="./launch.yaml")
        Returns: None

        '''
    @classmethod
    def get_module_name(cls, streams):
        """
        Determine the class module name of the streamer that needs to be imported through the video stream address or file name address.
        Args:
            streams: (List[str]) The stream address or file name address.

        Returns:

        """
    @classmethod
    def add_link(cls, node_name, streams, captain_names):
        """
        Add a link to the configuration file (launch.yaml) and initialize the node.
        Args:
            node_name: (str) The name of the node.
            streams: (List[str]) The stream address or file name address.
            captain_names: (List[str]) The captain names.

        Returns: (bool, str) Whether the operation is successful, the reason for the failure.

        """
    @classmethod
    def modify_link(cls, node_name, streams, captain_names):
        """
        Modify the link in the configuration file (launch.yaml) and reinitialize the node.
        Args:
            node_name: (str) The name of the node.
            streams: (List[str]) The stream address or file name address.
            captain_names: (List[str]) The captain names.

        Returns: (bool, str) Whether the operation is successful, the reason for the failure.

        """
    @classmethod
    def del_link(cls, node_name):
        """
        Delete the link in the configuration file (launch.yaml) and reinitialize the node.
        Args:
            node_name: (str) The name of the node.

        Returns: (bool, str) Whether the operation is successful, the reason for the failure.

        """
    @classmethod
    def handler(cls, signum, frame) -> None: ...
    @classmethod
    def register_signal(cls) -> None: ...
    def get_info(self) -> str:
        """
        Get the information of the node.
        Returns: (str) The information of the node.
        """
    @classmethod
    def save_node_to_json_file(cls, node_type: str, node_class_name: str, node_class_params: dict = {}): ...
    @classmethod
    def show_logo(cls) -> None:
        """
        Show the logo of CPipe.
        """
    @classmethod
    def launch(cls, check_node: bool = True, check_interval: int = 60, auto_restart: bool = True, launch_config_path=None, auto_handle_signal: bool = True, node_ready_timeout: int = 30, discovery: bool = True) -> None:
        """
        Launch all nodes that have been initialized (all nodes that inherit the Node class).
        Args:
            auto_handle_signal: (bool) Whether to automatically handle the signal.
            check_node: (bool) Turn on the node detection function, restart it if a node dies. If you receive a restart signal, restart the entire cpipe.
            check_interval: (int) Node detection interval time(seconds). Only effective when check_node is True.
            auto_restart: (bool) Whether to automatically restart the node when the node dies. Only effective when check_node is True.
            launch_config_path: The path of the configuration file (cpipe.json).
                                cpipe.json : The configuration file of the node connection relationship and the initialization parameters of the node.
            node_ready_timeout: (float) The timeout for the node to be ready. Only effective when check_node is True.
            discovery: (bool) Whether to enable discovery.
        Returns: None

        """
    def node_to_json(self): ...
    @classmethod
    def edge_to_json(cls, source_node, target_node): ...
