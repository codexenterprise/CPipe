from _typeshed import Incomplete
from cpipe.config.config import CLOGER_LEVEL as CLOGER_LEVEL, CLOGER_LEVEL_DEBUG as CLOGER_LEVEL_DEBUG
from cpipe.module.node import Node as Node
from cpipe.module.report import Report as Report

class WebsocketReport(Report):
    ws_url: str
    ws: Incomplete
    def init(self) -> None:
        """
        WebsocketReport is a class for sending data through websocket.
        Args:
            node_name: (str) The name of the node.
            queue_size: (int) The size of the queue.
            ws_url: (str) The url of the websocket server.
            receive_func: (Callable) The function to receive the data. It should be a function that takes a single argument (the data) and returns None.
        """
    def is_connected(self):
        """
        Check if the report is connected.
        Returns: True if connected, False otherwise.
        """
    def receive(self):
        """
        Receive the data from the websocket server.
        Returns: The data.
        """
    @staticmethod
    def default_dump(obj):
        """
        Convert numpy classes to JSON serializable objects.
        Args:
            obj: The object to convert.

        Returns: The converted object.

        """
    def connect(self):
        """
        Connect to the websocket server.
        Returns: True if connected, False otherwise.

        """
    def send(self, data, *args):
        """
        Send the data.
        Args:
            data: The data to send.
            *args: The arguments.

        Returns: None

        """
