from lark_oapi.api.im.v1 import *
from lark_oapi.api.speech_to_text.v1 import *
import lark_oapi as lark
import typing as t
from _typeshed import Incomplete
from cpipe.config.config import AGENT_WORKSPACE_DIR as AGENT_WORKSPACE_DIR
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath, CNone as CNone
from cpipe.module.node import Node as Node
from cpipe.module.report import Report as Report
from typing import Annotated

def load_audio(path: str, sample_rate: int = 16000, pcm_int16: bool = False):
    """
    load audio to (samples: np.float32, sample_rate: int).
    support .wav / .pcm / .mp3
    - pcm_sample_rate: only .pcm use, default 16000.
    - pcm_int16: True when .pcm use int16, otherwise use float32.
    """
def feishu_receive_fun_v1(data: lark.im.v1.P2ImMessageReceiveV1) -> None: ...

class FeishuReport(Report):
    """
    FeishuReport is the base class for the feishu report node. https://open.feishu.cn
    """
    app_id: Annotated[str, 'The app id of the feishu.']
    app_secret: Annotated[str, 'The app secret of the feishu.']
    open_id: Annotated[CNone | str, 'The open id of the feishu.']
    chat_id: Annotated[CNone | str, 'The chat id of the feishu.']
    agent_mode: Annotated[CBool, 'Whether to use the agent mode.']
    agent_port: Annotated[int, 'using cpipeinsight port(default is 9966).']
    stt_path: Annotated[CFilePath | str | CNone, 'The path of the stt. support sherpa_onnx and sense_voice with agent mode.']
    tenant_token: Annotated[CNone | str, 'The tenant token of the feishu.']
    token_expire_time: Annotated[CNone | float, 'The token expire time of the feishu.']
    stt_model: Annotated[t.Any | None, 'The stt model.']
    client: Annotated[lark.Client | None, 'The client.']
    ws_client: Annotated[lark.ws.Client | None, 'The websocket client.']
    receive_func: Incomplete
    def init_client(self) -> None: ...
    def is_token_expired(self): ...
    def get_tenant_access_token(self): ...
    def download_file(self, save_path: str, file_key: str, message_id: str, file_type: str = 'image', is_audio: bool = False): ...
    def audio_to_text_with_api(self, audio_path: str): ...
    def audio_to_text_with_local_model(self, audio_path: str, sample_rate: int = 16000): ...
    def feishu_receive_fun_v1_with_cpipe_agent(self, data: lark.im.v1.P2ImMessageReceiveV1) -> None: ...
    def reply_a_emoji(self, message_id: str, emoji_type: str): ...
    def reply_to_feishu(self, answer: str, message_id: str): ...
    def send(self, data, *args) -> None:
        """
        Send a message to the feishu.
        Args:
            data: The data to send.
            *args: The arguments.

        Returns: None

        """
