from cpipe.module.report import Report as Report

class MCPReport(Report):
    """
        MCPReport is a class for sending data through MCP. It must be used in conjunction with MCPStreamer.
        Args:
            node_name: (str) The name of the node.
            queue_size: (int) The size of the queue. 
    """
    queue_size: int
    mcp_streamer_node: dict
    def _start(self) -> None:
        """
        Start the report node.
        Returns: None

        """
    def send(self, data) -> None:
        """
        Send the data.
        Args:
            data: Contains the streamer name, image and bboxes.

        Returns: None

        """
