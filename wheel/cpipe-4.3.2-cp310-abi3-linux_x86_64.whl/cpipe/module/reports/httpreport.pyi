from cpipe.module.report import Report as Report
from typing import Literal

class HTTPReport(Report):
    host: str
    port: int
    url: str
    report_type: Literal['POST', 'PUT', 'GET']
    repeat_time: int
    timeout_base: int
    success_code: tuple
    headers: dict
    def send(self, data, token=None):
        """
        Send the data.
        Args:
            data: The data to send.
            token: The token.

        Returns: The code

        """
