from _typeshed import Incomplete
from cpipe.module.cvalidator import CNone as CNone
from cpipe.module.node import Node as Node
from cpipe.module.report import Report as Report

class MQTTReport(Report):
    username: CNone | str
    password: CNone | str
    broker: str
    port: int
    qos: int
    _need_connect: bool
    _client: Incomplete
    def init_client(self) -> None: ...
    def connect(self):
        """
        Connect to the MQTT server.
        Returns: None

        """
    def send(self, topic, *args):
        """
        Send the data.
        Args:
            topic: The topic of the message.
            *args: The arguments.

        Returns: None

        """
    def disconnect(self) -> None:
        """
        Disconnect from the MQTT server.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the report node.
        Returns: None

        """
