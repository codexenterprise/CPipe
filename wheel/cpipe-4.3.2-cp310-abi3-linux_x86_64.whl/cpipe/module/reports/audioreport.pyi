import numpy as np
from _typeshed import Incomplete
from cpipe.module.cvalidator import CBool as CBool, CStrList as CStrList
from cpipe.module.inferenceengine import InferenceEngine as InferenceEngine
from cpipe.module.node import Node as Node
from cpipe.module.service.toolkit import ToolResult as ToolResult
from queue import Queue
from typing import Annotated, Literal

class AudioReport(InferenceEngine):
    lang_code: Annotated[Literal['ch', 'en'], 'The language code.']
    input_names: Annotated[CStrList, 'The input names of the model.']
    output_names: Annotated[CStrList, 'The output names of the model.']
    class_names: Annotated[CStrList, 'The class names of the model.']
    max_batch_size: Annotated[int, 'The maximum batch size.']
    warmup: Annotated[CBool, 'Whether to warm up the model.']
    play_queue: Annotated[Queue, 'The play queue of the audio texts.']
    discard_oldest_audio: Annotated[CBool, 'Whether to discard the oldest audio when the queue is full. If False, blocking wait for the queue.']
    play_face_name: Annotated[CBool, 'Whether to play the face name.']
    play_face_name_interval: Annotated[float, 'The interval of playing the face name. If the face name is played within the interval, it will not be played again.']
    @staticmethod
    def g2p_en(text: str) -> list[str]:
        """Convert English to IPA phonemes using phonemizer+espeak-ng.

        Requires: apt-get install espeak-ng; pip install phonemizer
        """
    @staticmethod
    def g2p_zh(text: str) -> list[str]:
        '''Convert Mandarin Chinese to IPA-like phonemes using misaki[zh].

        Requires: pip install "misaki[zh]"
        '''
    @staticmethod
    def phonemes_to_ids(phonemes: list[str], vocab: dict[str, int], max_len: int = 510) -> np.ndarray: ...
    @staticmethod
    def load_style_tensor(voice_path: str, phoneme_len: int) -> np.ndarray: ...
    vocab: Incomplete
    style: Incomplete
    speed: Incomplete
    def model_init(self) -> None: ...
    def preprocess(self, inputs, *args, **kwargs): ...
    def infer(self, inputs, *args, **kwargs): ...
    def play_thread(self) -> None: ...
    def play_audio_event(self, text: str): ...
    def play_audio(self, text: str) -> ToolResult: ...
    def _start(self) -> None:
        """
        The entry function for the current node (process) to run in one-stage mode, all the logic processing of the current node is completed here.
        Returns: None

        """
