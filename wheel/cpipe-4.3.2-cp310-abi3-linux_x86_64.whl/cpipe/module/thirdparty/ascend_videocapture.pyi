from _typeshed import Incomplete

_CAP_PROP_FPS: Incomplete
_CAP_PROP_FRAME_WIDTH: Incomplete
_CAP_PROP_FRAME_HEIGHT: Incomplete
_CAP_PROP_FRAME_COUNT: Incomplete
_CAP_PROP_POS_FRAMES: Incomplete
ACL_MEMCPY_DEVICE_TO_HOST: int
_acl_resource_cache: Incomplete
_acl_resource_lock: Incomplete

def _get_acl_resource(device_id):
    """获取(或初始化)当前进程内指定 device 的 AclLiteResource, 单例复用。"""

class AscendVideoCapture:
    '''昇腾 DVPP 硬解版的 cv2.VideoCapture 替身。

    用法与 cv2.VideoCapture 基本一致:
        cap = AscendVideoCapture("rtsp://...")            # 或 "xxx.h264"
        fps = cap.get(cv2.CAP_PROP_FPS)
        ok, frame = cap.read()                             # frame 为 BGR np.ndarray
        cap.release()
    '''
    stream: Incomplete
    device_id: Incomplete
    color: Incomplete
    read_timeout: Incomplete
    _cvt_code: Incomplete
    _fps: int
    _width: int
    _height: int
    _frame_count: int
    _pos: int
    _cap: Incomplete
    _acl_resource: Incomplete
    _opened: bool
    _finished: bool
    _acl: Incomplete
    def __init__(self, stream, device_id: int = 0, color: str = 'BGR', read_timeout: float = 10.0) -> None:
        '''
        Args:
            stream: (str) RTSP 地址或本地文件路径(必须 Annex-B H.264/H.265)。
            device_id: (int) 昇腾 device id。
            color: (str) 输出颜色, "BGR"(默认, 同 cv2) 或 "RGB"。
            read_timeout: (float) read() 等待一帧的最长秒数, 超时视为失败/断流。
        '''
    def _probe_meta(self) -> None:
        """用 PyAV 探一次流的元信息(fps/宽/高/总帧数)。

        cpipe 在连接后、首帧之前就会 get(CAP_PROP_FPS), 且要求 > 0 才算连接成功,
        所以必须在这里先拿到 fps。对 RTSP 会短暂多开一次连接, 属可接受成本。
        """
    def _open(self) -> None: ...
    def _acl_mod(self): ...
    def _image_to_ndarray(self, image):
        """AclLiteImage(NV12, device) -> BGR/RGB np.ndarray, 并裁掉对齐 padding。"""
    def _next_frame(self):
        """阻塞取下一帧(BGR/RGB ndarray); 断流/结束返回 None。"""
    def read(self, dst=None):
        """读取一帧。

        Args:
            dst: (np.ndarray|None) 若提供(如共享内存视图), 结果写入其中(需形状一致)。
        Returns:
            (bool, np.ndarray|None): 成功与否, 及帧数据。
        """
    def grab(self):
        """解一帧但不做颜色转换/返回, 用于跳帧。"""
    def get(self, prop_id): ...
    def set(self, prop_id, value): ...
    def isOpened(self): ...
    def release(self) -> None:
        """释放解码资源。显式调用 destroy() 关闭 acllite 的后台守护解码线程。

        注意: 不在这里释放 AclLiteResource, 因为它是进程内单例, 可能被其他流复用。
        """
    def __del__(self) -> None: ...
