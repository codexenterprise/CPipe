from _typeshed import Incomplete
from cpipe.config.config import CMASK_YAML_PATH as CMASK_YAML_PATH
from cpipe.module.clogger import CLogger as CLogger

class CameraInfo:
    camera_id: Incomplete
    streamer_node_id: Incomplete
    streamer_node_name: Incomplete
    stream: Incomplete
    polygon_dict: Incomplete
    warn_X: Incomplete
    warn_Y: Incomplete
    interval_warn: Incomplete
    save_video: Incomplete
    video_time: Incomplete
    node_names: Incomplete
    node_ids: Incomplete
    cmask: Incomplete
    cmask_with_hw: Incomplete
    video_fps: Incomplete
    detect_fps: Incomplete
    alarm_thresholds: Incomplete
    algo_confidence: Incomplete
    video_h: Incomplete
    video_w: Incomplete
    def __init__(self) -> None: ...
    def get_node_cmask(self): ...
    def get_node_cmask_with_hw(self, video_h, video_w): ...

class CPipeConfig:
    use_trt: bool
    hard_decode: bool
    algo_confidence: dict
    alarm_thresholds: dict
    alarm_interval: int
    detect_fps: float
    cameras: dict[str, CameraInfo]
    node_ids: list
    node_namas_of_ids: dict
    node_types: dict
    def get_process_frame_interval(self, video_fps): ...

class CodexDeployment:
    logger: Incomplete
    project_id: Incomplete
    algorithm_id: Incomplete
    mode_id: Incomplete
    log_type: Incomplete
    ip: Incomplete
    port: Incomplete
    node_names: Incomplete
    websocket_url: Incomplete
    cpipe_configs: CPipeConfig
    save_alarm_info_root: Incomplete
    results_path: Incomplete
    def __init__(self, project_id, algorithm_id, mode_id: str = 'realTime', log_type: int = 4, ip: str = 'localhost', port: int = 8899, remove_cmask_yaml: bool = True, node_names=None, save_alarm_info_root: str = './') -> None: ...
    def format_log(self, msg): ...
    def get_config(self) -> CPipeConfig: ...
    def send_alarm(self, alarm_msg) -> None: ...
    def send_alarm_with_image(self, uniqueId, cameraId, sourcePath, resultPath, labelLst): ...
    def send_alarm_with_video(self, uniqueId, cameraId, sourcePath, resultPath, labelLst) -> None: ...
    def get_rtsp_url(self): ...
