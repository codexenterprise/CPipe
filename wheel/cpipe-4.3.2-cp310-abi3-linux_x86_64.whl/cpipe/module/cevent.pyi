import threading
from _typeshed import Incomplete

class CEvent(threading.Event):
    data: Incomplete
    def __init__(self) -> None: ...

class CEventQueue:
    '''
    Request/response channel between the caller of `Node.event_send()` (e.g. an
    HTTP handler running in FastAPI\'s threadpool, an Agent tool, or another
    node) and the target node\'s dedicated `_event_thread`.

    Two problems are addressed here:

    1. No timeout: the original implementation did `input_queue.put(data)`
       immediately followed by `output_queue.get()` with no timeout. If the
       node\'s event thread never calls `response()` (event callback raises
       an unexpected error before responding, the node process died, the
       callback hangs, ...), the caller blocks forever.

    2. Response cross-talk ("响应串线"): `send()` can be called concurrently
       from multiple threads of the *same* process against the *same*
       `CEventQueue` (this happens in practice because CPipe\'s HTTP server
       runs as a thread inside the main process and can serve several
       concurrent requests that call `event_send()` on the same node).
       With a single shared `output_queue` and no correlation between a
       request and its response, whichever thread calls `get()` first wins
       the first available response - even if it belongs to a different
       caller\'s request.

    Fix: every request carries a unique, monotonically increasing
    `request_id`. `send()` is serialized with a lock so a request and the
    wait for its response form one atomic unit from the queue\'s point of
    view, and any stale response (e.g. one that arrives late after a
    previous call already timed out) is discarded instead of being handed
    to the wrong caller.
    '''
    input_queue: Incomplete
    output_queue: Incomplete
    _send_lock: Incomplete
    _request_id_gen: Incomplete
    def __init__(self, queue_size: int = 10) -> None: ...
    def send(self, data, timeout: int = 30):
        """
        Send `data` to the event thread and wait for the matching response.
        Args:
            data: (Any) The payload to send, typically (event_name, event_data).
            timeout: (float) Max seconds to wait for a response. `None` means
                wait forever (not recommended, kept only for backward compat).
        Returns: (Any) The value passed to `response()` by the event thread.
        Raises:
            TimeoutError: if no matching response arrives within `timeout` seconds.
        """
    def get(self):
        """
        Called by the event thread to fetch the next `(request_id, data)` request.
        """
    def response(self, request_id, data) -> None:
        """
        Called by the event thread to answer the request identified by `request_id`.
        """
