from _typeshed import Incomplete
from cpipe.config.config import CMASK_YAML_PATH as CMASK_YAML_PATH
from cpipe.module.clogger import CLogger as CLogger

class CameraInfo:
    streamer_node_name: None
    stream: None
    polygon_dict: dict

class CPipeConfig:
    use_trt: bool
    hard_decode: bool
    algo_confidence: dict
    alarm_thresholds: dict
    alarm_interval: int
    detect_fps: float
    cameras: list[CameraInfo]
    def get_process_frame_interval(self, video_fps): ...

class CodexDeployment:
    logger: Incomplete
    project_id: Incomplete
    algorithm_id: Incomplete
    mode_id: Incomplete
    log_type: Incomplete
    ip: Incomplete
    port: Incomplete
    websocket_url: Incomplete
    def __init__(self, project_id, algorithm_id, mode_id: str = 'realTime', log_type: int = 4, ip: str = 'localhost', port: int = 8899, remove_cmask_yaml: bool = True) -> None: ...
    def format_log(self, msg): ...
    def get_config(self) -> CPipeConfig: ...
    def send_alarm(self, alarm_msg) -> None: ...
    def get_rtsp_url(self): ...
