import threading
from _typeshed import Incomplete

def clip_coords(boxes, img_shape) -> None:
    """
    Clip bounding xyxy bounding boxes to image shape (height
    Args:
        boxes: bounding boxes (x1, y1, x2, y2)
        img_shape: image shape (height, width)

    Returns: None

    """
def scale_coords(img1_shape, coords, img0_shape, ratio_pad: Incomplete | None = None):
    """
    Rescale coords (xyxy) from img1_shape to img0_shape
    Args:
        img1_shape: original shape of the image
        coords: bounding boxes (x1, y1, x2, y2)
        img0_shape: target shape of the image
        ratio_pad: padding ratio

    Returns: rescaled bounding boxes

    """
def distance2kps(points, distance, max_shape: Incomplete | None = None):
    """Decode distance prediction to bounding box.

    Args:
        points (Tensor): Shape (n, 2), [x, y].
        distance (Tensor): Distance from the given point to 4
            boundaries (left, top, right, bottom).
        max_shape (tuple): Shape of the image.

    Returns:
        Tensor: Decoded bboxes.
    """
def distance2bbox(points, distance, max_shape: Incomplete | None = None):
    """Decode distance prediction to bounding box.

    Args:
        points (Tensor): Shape (n, 2), [x, y].
        distance (Tensor): Distance from the given point to 4
            boundaries (left, top, right, bottom).
        max_shape (tuple): Shape of the image.

    Returns:
        Tensor: Decoded bboxes.
    """
def letterbox(img, new_shape=(640, 640), color=(114, 114, 114), auto: bool = True, scaleFill: bool = False, scaleup: bool = True, stride: int = 32):
    """
    Resize image to a 32-pixel-multiple rectangle while keeping aspect ratio.
    """
def letterbox_cuda(img, new_shape=(640, 640), color=(114, 114, 114), auto: bool = True, scaleFill: bool = False, scaleup: bool = True, stride: int = 32, device: str = 'cuda:0'):
    """
    Resize image to a 32-pixel-multiple rectangle while keeping aspect ratio.
    """
def preprocess_yolov7(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for YOLOv7.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def preprocess_yolov7_rknn(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for YOLOv7.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def preprocess_yolov7_cuda(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for YOLOv7.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def preprocess_retinaface(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for RetinaFace.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def embedding_preprocess(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for embedding model.
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def class_preprocess(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for classification
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """
def mm_class_preprocess(self, raw_bgr_image, num) -> None:
    """
    Preprocess the raw image for classification
    Args:
        self: ProcessThread object
        raw_bgr_image: input image
        num: image index

    Returns: None

    """

class ProcessThread(threading.Thread):
    images: Incomplete
    out_img: Incomplete
    input_w: Incomplete
    input_h: Incomplete
    idx: Incomplete
    worker_num: Incomplete
    device: Incomplete
    batch_scale: Incomplete
    mean: Incomplete
    std: Incomplete
    auto: bool
    half: bool
    area_flag: Incomplete
    area_info: Incomplete
    area_info_streamer_names: Incomplete
    args: Incomplete
    kwargs: Incomplete
    preprocessor: Incomplete
    def __init__(self, idx, worker_num, images, out_img, device, input_w: int = 640, input_h: int = 640, preprocessor: Incomplete | None = None, batch_scale: Incomplete | None = None, area_flag: bool = False, area_info: Incomplete | None = None, area_info_streamer_names: Incomplete | None = None, mean: Incomplete | None = None, std: Incomplete | None = None, *args, **kwargs) -> None:
        """
        CPipe process thread class. Used for multi-thread task processing.
        Args:
            idx: start index
            worker_num: number of workers
            images: input images
            out_img: output images
            device: device of the model
            input_w: input width
            input_h: input height
            preprocessor: preprocessor function
            batch_scale: batch scale data
            area_flag: area flag for area mask
            area_info: area information
            area_info_streamer_names: area information streamer names
            mean: process mean
            std: process std
            *args:
            **kwargs:
        """
    def run(self) -> None:
        """
        Run the process thread.
        Returns: None

        """

def load_data(input_images, device, input_size_hw, num_workers, preprocessor: Incomplete | None = None, area_flag: bool = False, area_info: Incomplete | None = None, area_info_streamer_names: Incomplete | None = None, mean: Incomplete | None = None, std: Incomplete | None = None, batch_scale: bool = False, *args, **kwargs):
    """
    Entry function of data preprocessing method for all models in CPipe.
    Args:
        input_images: input images
        device: device of the model
        input_size_hw: input size
        num_workers: number of workers
        preprocessor: preprocessor function
        area_flag: area flag for area mask
        area_info: area information
        area_info_streamer_names: area information streamer names
        mean: process mean
        std: process std
        batch_scale: batch scale flag
        *args:
        **kwargs:
    """
