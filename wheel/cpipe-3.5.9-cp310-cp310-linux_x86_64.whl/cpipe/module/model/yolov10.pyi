from _typeshed import Incomplete
from cpipe.module.cinferencer import CDetector as CDetector
from cpipe.module.dataprocessing import preprocess_yolov7 as preprocess_yolov7, scale_coords as scale_coords

class YOLOv10(CDetector):
    preprocessor: Incomplete
    def __init__(self, nodeName, modelPath, queue_size, inputSize, class_names=(), valid_class_names: Incomplete | None = None, max_batch_size: int = 1, conf_thres: float = 0.25, iou_thres: float = 0.45, warmup: bool = True, device: str = 'cuda:0', threading_num: int = 4, save_top_n_objects: Incomplete | None = None, area_flag: bool = False, secondary_class_names: Incomplete | None = None, input_names: Incomplete | None = None, output_names: Incomplete | None = None, gray_mode: bool = False, *args, **kwargs) -> None:
        """
        YOLOv10 is a class for YOLOv10 model, which is inherited from CDetector.

        Args:
            nodeName: (str) The name of the node.
            modelPath: (str) The path of the model.
            queue_size: (int) The queue size.
            inputSize: (list) The input size. e.g. [3, 416, 416]
            class_names: (list) The class names.
            valid_class_names: (list) The valid class names.
            max_batch_size: (int) The max batch size.
            conf_thres: (float) The confidence threshold.
            iou_thres: (float) The iou threshold.
            warmup: (bool) The warmup flag.
            device: (str) The device.
            threading_num: (int) The threading number.
            save_top_n_objects: (int) The save top n objects.
            area_flag: (bool) The area flag.
            secondary_class_names: (list) The secondary class names.
            input_names: (list) The input names.
            output_names: (list) The output names.
            gray_mode: (bool) Whether to use gray mode.
        Returns: None

        """
    def infer(self, inputs, *args, **kwargs):
        """
        The infer function of the model
        Args:
            inputs: inputs[0] is pre_imgs, inputs[1] is origin_imgs
            *args:  frames_stream_names. eg. ['stream1', 'stream2']
            **kwargs:

        Returns:

        """
