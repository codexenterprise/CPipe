from _typeshed import Incomplete
from cpipe.config.config import CPIPE_BLOCKING_MODE as CPIPE_BLOCKING_MODE, SHARE_MEMORY_MODE as SHARE_MEMORY_MODE
from multiprocessing import sharedctypes as sharedctypes

class CBuffer:
    name: Incomplete
    share_memory_size: Incomplete
    buffer_length: Incomplete
    buffers: Incomplete
    buffer_locks: Incomplete
    current_index: int
    def __init__(self, name, share_memory_size, buffer_length) -> None:
        """
        CPipe shared memory buffer class, used to store shared memory data.
        Args:
            name: (str) The name of the buffer.
            share_memory_size: (list) The size of the shared memory. [height, width, channel]
            buffer_length: (int) The number of shared content blocks.
        """
    def set(self, value):
        """
        Set the value of the buffer.
        Args:
            value: The value to be set.

        Returns: (np.ndarray, buffer index) The shared memory buffer and the index of the buffer.

        """
    def lock(self) -> None:
        """
        Lock the buffer. If the buffer is locked, the process will wait until the buffer is unlocked. CPIPE_BLOCKING_MODE(config.yaml to enable) must be set to True.
        Returns: None

        """
    def unlock(self, index) -> None:
        """
        Unlock the buffer. CPIPE_BLOCKING_MODE(config.yaml to enable) must be set to True.
        Args:
            index:  The index of the buffer.

        Returns: None

        """
    def get(self, index):
        """
        Get the value of the buffer
        Args:
            index: The index of the buffer.

        Returns: (np.ndarray) The shared memory buffer.

        """
