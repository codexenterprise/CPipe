from _typeshed import Incomplete
from cpipe.config.config import SHARE_MEMORY_MODE as SHARE_MEMORY_MODE, VIDEO_CUDA_MODE as VIDEO_CUDA_MODE
from cpipe.module.cdata import CData as CData, CImage as CImage
from cpipe.module.cmask import CMask as CMask
from cpipe.module.cprocessors import CProcessors as CProcessors
from cpipe.module.node import Node as Node
from cpipe.module.thirdparty.hikvision import Hikvision as Hikvision
from cpipe.module.utils import cudaSetDevice as cudaSetDevice

class Streamer(Node):
    stream: Incomplete
    queue_size: Incomplete
    nodeName: Incomplete
    nodeType: Incomplete
    cmask: Incomplete
    all_ready: Incomplete
    device: Incomplete
    actual_fps: Incomplete
    def __init__(self, nodeName, stream, queue_size, all_ready, device: str = 'cuda:0') -> None:
        """
        Streamer is the base class for the streamer node.
        Args:
            nodeName: (str) The name of the node.
            stream: (str) The stream address.
            queue_size: (int) The size of the queue.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        """
    def _connect(self) -> None:
        """
        Connect to the stream. This function should be implemented in the subclass.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the streamer node. This function should be implemented in the subclass.
        Returns: None

        """
    @staticmethod
    def get_video_type(path):
        """
        Get the video type.
        Args:
        """
    def check_all_ready(self) -> None:
        """
        Check if all consumers are ready.
        Returns: None

        """

class VideoStreamer(Streamer):
    video_fps: Incomplete
    video_width: Incomplete
    video_height: Incomplete
    video_info_dict: Incomplete
    _process_frame_interval: Incomplete
    short_connection_delay: Incomplete
    sleep_time: Incomplete
    block_mode: Incomplete
    once_mode: Incomplete
    delay_start_time: Incomplete
    dump_time: int
    hikvision_platform: Incomplete
    hikvision_cameras_info: Incomplete
    hikvision: Incomplete
    cmask: Incomplete
    def __init__(self, nodeName, stream, queue_size, process_frame_interval: int = 0, hikvision_platform: bool = False, base_url: str = '', appKey: str = '', appSecret: str = '', short_connection_delay: float = 0.0, sleep_time: Incomplete | None = None, block_mode: bool = False, once_mode: bool = False, delay_start_time: int = 0, all_ready: bool = True, device: str = 'cuda:0') -> None:
        '''
        VideoStreamer is the base class for the video streamer node.
        Args:
            nodeName: (str) The name of the node.
            stream: (str) The stream address.
            queue_size: (int) The size of the queue.
            process_frame_interval: (int) The interval of processing frames.
            hikvision_platform: (bool) Whether to use the Hikvision platform.
            base_url: (str) The base url of the Hikvision platform.
            appKey: (str) The appKey of the Hikvision platform.
            appSecret: (str) The appSecret of the Hikvision platform.
            short_connection_delay: (float) The short connection delay.
            sleep_time: (float) The sleep time(second, e.g. 0.04s) with video interframe sleep. Just for file mode. e.g. stream="file.mp4"
            block_mode: (bool) Whether to block the frame. Just for file mode. e.g. stream="file.mp4"
            once_mode:  (bool) Whether to run once. Just for file mode. e.g. stream="file.mp4"
            delay_start_time: (float) The delay start time. Just for file mode. e.g. stream="file.mp4"
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).

        '''
    @property
    def process_frame_interval(self):
        """
        Get the process frame interval.
        Returns: (int) The interval of processing frames.

        """
    @process_frame_interval.setter
    def process_frame_interval(self, value) -> None:
        """
        Set the process frame interval.
        Args:
            value: (int) The interval of processing frames.

        Returns: None

        """
    def reset_stream(self, stream):
        """
        Reset the stream.
        Args:
            stream: (str) The stream address.

        Returns: None

        """
    def need_reset_stream(self):
        """
        Check if need to reset the stream.
        Returns: (bool) True or False

        """
    def get_hk_camera_rtsp(self, camera_name):
        """
        Get the rtsp stream of the Hikvision platform.
        Args:
            camera_name: (str) The name of the camera.

        Returns: (str) The rtsp stream.

        """
    def get_rtsp_info(self):
        """
        Get the rtsp information.
        Returns: (int, int, int) The video fps, width and height.

        """
    def get_one_image(self):
        """
        Get one image from the stream.
        Returns: (np.ndarray) The image.

        """
    def _connect(self):
        """
        Connect to the stream.
        Returns: (cv2.VideoCapture, bool) The cv2.VideoCapture object and the flag.

        """
    def check_video_info(self):
        """
        Check the video information.
        Returns: (bool) True or False

        """
    stream: Incomplete
    def stream_start_cpu(self) -> None:
        """
        Start the streamer node with CPU mode.
        Returns: None

        """
    def stream_start_cuda(self) -> None:
        """
        Start the streamer node with CUDA mode.
        Returns: None

        """
    def file_start_cpu(self) -> None:
        """
        Start the streamer node with CPU mode.
        Returns: None

        """
    def file_start_cuda(self) -> None:
        """
        Start the streamer node with CUDA mode.
        Returns: None

        """
    def _start(self) -> None:
        """
        Start the streamer node.
        Returns: None

        """

class VideoStreamers(Node):
    nodeType: Incomplete
    streams: Incomplete
    processor_num: Incomplete
    interval_time: Incomplete
    round_interval_time: Incomplete
    dead_thres_time: Incomplete
    process_pool_queue_size: Incomplete
    daemon: bool
    def __init__(self, nodeName, streams, queue_size, processor_num, interval_time: float = 0.0, round_interval_time: float = 0.0, hikvision_platform: bool = False, base_url: str = '', appKey: str = '', appSecret: str = '', dead_thres_time: int = 5, process_pool_queue_size: int = 32, all_ready: bool = True, device: str = 'cuda:0') -> None:
        """
        VideoStreamers is the base class for the video streamers node.
        Args:
            nodeName: (str) The name of the node.
            streams: (list) The stream addresses.
            queue_size: (int) The size of the queue.
            processor_num: (int) The number of processors.
            interval_time: (float) The interval time. Each streamer will be processed every interval_time seconds.
            round_interval_time: (float) The round interval time(seconds).
            hikvision_platform: (bool) Whether to use the Hikvision platform.
            base_url: (str) The base url of the Hikvision platform.
            appKey: (str) The appKey of the Hikvision platform.
            appSecret: (str) The appSecret of the Hikvision platform.
            dead_thres_time: (int) The dead threshold time.
            process_pool_queue_size: (int) The process pool queue size.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        """
    def task(self, args) -> None:
        """
        Task function. This function will be called by the CProcessor.
        Args:
            args: The arguments.

        Returns: None

        """
    def _start(self) -> None:
        """
        Start the video streamers' node.
        Returns: None

        """

class ImageStreamer(Streamer):
    block_mode: Incomplete
    once_mode: Incomplete
    video_fps: Incomplete
    video_width: Incomplete
    video_height: Incomplete
    play_interval: Incomplete
    output_wh: Incomplete
    padding: Incomplete
    ground_image_path: Incomplete
    _process_frame_interval: Incomplete
    cmask: Incomplete
    def __init__(self, nodeName, stream, queue_size, output_wh=(1920, 1080), padding: bool = True, play_interval: float = 0.04, process_frame_interval: int = 0, ground_image_path: Incomplete | None = None, block_mode: bool = False, once_mode: bool = True, all_ready: bool = True, device: str = 'cuda:0') -> None:
        '''
        ImageStreamer is the base class for the image streamer node.
        Args:
            nodeName: (str) The name of the node.
            stream: (str) The stream is folder or file path or Queue object(python multiprocessing.Queue).
                    Examples:
                    folder path: "./test_images".
                    file path: "./test_images/test.jpg".
                    Queue format: {"images_path": ["./test_images/test.jpg", "./test_images/test1.png", ...], "images_info"[{...}, {...}, ...]} or {"images_array": [np.ndarray, np.ndarray, ...], "images_info"[{...}, {...}, ...]}.
            queue_size: (int) The size of the queue.
            output_wh: (tuple) The output width and height.
            padding: (bool) Whether to padding the image.
            play_interval: (float) The play interval.
            process_frame_interval: (int) The interval of processing frames.
            ground_image_path: (str) The ground image path.
            block_mode: (bool) Whether to block the frame.
            once_mode: (bool) Whether to run once.
            all_ready: (bool) Whether to wait for all consumers to be ready.
            device: (str) The device of the model, CPU(cpu) or GPU(cuda:x).
        Examples:
            1.
            ImageStreamer("image_streamer", "./test_images", 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=True, all_ready=True, device="cuda:0")
            2.
            ImageStreamer("image_streamer", "./test_images/test.jpg", 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=True, all_ready=True, device="cuda:0")
            3.
            queue = multiprocessing.Queue(64)
            ImageStreamer("image_streamer", queue, 32, output_wh=(1920, 1080), padding=True, play_interval=0.04, block_mode=False, once_mode=False, all_ready=True, device="cuda:0")

        '''
    @property
    def process_frame_interval(self):
        """
        Get the process frame interval.
        Returns: (int) The interval of processing frames.

        """
    @process_frame_interval.setter
    def process_frame_interval(self, value) -> None:
        """
        Set the process frame interval.
        Args:
            value: (int) The interval of processing frames.

        Returns: None

        """
    def get_one_image(self):
        """
        Get one image from the stream.
        Returns: (np.ndarray) The image.

        """
    def _start(self) -> None:
        """
        Start the streamer node.
        Returns: None

        """
