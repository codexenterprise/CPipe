// X6 图形编辑器实例
let graph;
let isLocked = false;
let dnd;


// 初始化 X6 画布
function initGraph() {
    const { Graph, Addon } = X6;


    // 创建图形实例
    graph = new Graph({
        container: document.getElementById('graph-container'),
        // 画布铺满容器
        autoResize: true,
        // 悬浮配置 - 优化防止闪烁
        hovering: {
            tolerance: 5, // 增加容差，减少频繁触发
        },
        selecting: {
            enabled: false,
        },
        // 网格配置
        grid: {
            size: 10,
            visible: true,
            type: 'dot',
            args: {
                color: '#a0a0a0',
                thickness: 1
            }
        },
        // 背景配置
        background: {
            color: '#f5f5f5'
        },
        // 鼠标滚轮缩放 - 禁用默认行为，使用自定义缩放
        mousewheel: {
            enabled: false,
            modifiers: ['ctrl', 'meta'],
        },
        // 画布平移
        panning: {
            enabled: true,
            // modifiers: ['shift'],
            eventTypes: ['leftMouseDown']
        },
        // 节点可移动
        interacting: {
            nodeMovable: true,
        },
        // 连线配置
        connecting: {
          snap: true,
          allowBlank: false,
          allowLoop: false,
          highlight: false,
          connector: {
            name: 'rounded', // 或 'normal', 'smooth'
          },
          connectionPoint: {
            name: 'boundary', // 算法名称
            args: {
              padding: 15,    // 向内偏移距离（关键！）
              selector: '.x6-port-body' // 必须指定端口DOM选择器
            }
          },
          router: {
            name: 'er',
            // args: {
            //   direction: 'V',
            //   offset:15,
            // },
          },
          // connector: {
          //   name: 'rounded',
          //   args: {
          //     radius: 8,
          //   },
          // },
          // anchor: 'center',
          // connectionPoint: 'anchor',
          createEdge() {
            return graph.createEdge({
              attrs: {
                line: {
                  stroke: '#eb2f2f',
                  strokeWidth: 2,
                  targetMarker: null,
                },
              },
              zIndex: -999,
              // 优化edge的pointer-events
              data: {
                pointerEvents: 'stroke'
              }
            })
          },
          validateConnection({ sourceView, targetView, sourceMagnet, targetMagnet, sourcePort, targetPort }) {
            // 必须有 targetMagnet，否则无效
            if (!targetMagnet) {
              return false
            }
            
            // 必须有 sourceMagnet，否则无效
            if (!sourceMagnet) {
              return false
            }

            // 目标必须是输入端口（in group）
            if (targetMagnet.getAttribute('port-group') !== 'in') {
              return false
            }
            
            // 源必须是输出端口（out group）
            if (sourceMagnet.getAttribute('port-group') !== 'out') {
              return false
            }


            return true
          },
        },
        // 高亮配置
        highlighting: {
            magnetAdsorbed: {
                name: 'stroke',
                args: {
                    attrs: {
                        fill: '#5F95FF',
                        stroke: '#5F95FF'
                    }
                }
            }
        },
        // 对齐线
        snapline: true,
        // 历史记录
        history: true,
        // 键盘快捷键
        keyboard: true,
        // 剪贴板
        clipboard: true
    });

    // 初始化小地图
    // initMinimap();


    // 绑定键盘事件
    // bindKeyboard();

    // 添加一些示例节点
    // addSampleNodes();

    // 初始化API
    initAPI();

    // 不再使用 X6 的 DND 插件，改用原生 drop 事件
    // dnd = new Addon.Dnd({
    //     target: graph,
    //     scaled: false,
    //     animation: true,
    // });
    
}

// 初始化小地图
// function initMinimap() {
//     const minimap = new X6.Addon.MiniMap({
//         container: document.getElementById('minimap-container'),
//         width: 200,
//         height: 150,
//         padding: 10,
//         graphOptions: {
//             async: true,
//             getCellView(cell) {
//                 if (cell.isNode()) {
//                     return X6.NodeView;
//                 }
//                 if (cell.isEdge()) {
//                     return X6.EdgeView;
//                 }
//             }
//         }
//     });

//     graph.use(minimap);
// }


// 处理拖拽开始
function handleDragStart(e) {
    const type = e.currentTarget.getAttribute('data-type');
    // 不再使用 DND 插件，改为手动处理
    e.dataTransfer.setData('node-type', type);
    e.currentTarget.style.opacity = '0.6';
}

// 处理拖拽结束
function handleDragEnd(e) {
    e.currentTarget.style.opacity = '1';
}

// 根据类型创建节点
function createNodeByType(type) {
    const commonAttrs = {
        body: {
            stroke: '#5F95FF',
            strokeWidth: 1,
            fill: '#EFF4FF'
        },
        label: {
            fill: '#fff',
            fontSize: 13,
            fontWeight: 500
        }
    };

    const nodeConfigs = {
        Streamer: {
            shape: 'html',
            width: 150,
            height: 89,
            x: 500,
            y: 500,
            attrs: {
                body: {
                    rx: 10, // 圆角矩形
                    ry: 10,
                    strokeWidth: 1,
                },
            },
            html: () => {
                const sc = CONFIG.nodeTypes.find(n => n.type === 'Streamer').color
                const wrap = document.createElement('div');
                wrap.style.width = '100%';
                wrap.style.height = '100%';
                wrap.style.display = 'flex';
                wrap.style.flexDirection = 'column';
                wrap.style.alignItems = 'center';
                wrap.style.justifyContent = 'center';
                wrap.style.background = sc;
                wrap.style.borderRadius = '10px';
                wrap.innerText = 'Hello';
                return wrap;
            },
            ports: getDefaultPorts()
        },
        algorithm: {
            shape: 'rect',
            width: 120,
            height: 50,
            label: 'Algorithm',
            attrs: {
                body: {
                    stroke: 'transparent',
                    strokeWidth: 0,
                    fill: '#3b82f6',
                    rx: 8,
                    ry: 8
                },
                label: commonAttrs.label
            },
            ports: getDefaultPorts()
        },
        logic: {
            shape: 'rect',
            width: 120,
            height: 50,
            label: 'Logic',
            attrs: {
                body: {
                    stroke: 'transparent',
                    strokeWidth: 0,
                    fill: '#f59e0b',
                    rx: 8,
                    ry: 8
                },
                label: commonAttrs.label
            },
            ports: getDefaultPorts()
        },
        report: {
            shape: 'rect',
            width: 120,
            height: 50,
            label: 'Report',
            attrs: {
                body: {
                    stroke: 'transparent',
                    strokeWidth: 0,
                    fill: '#ec4899',
                    rx: 8,
                    ry: 8
                },
                label: commonAttrs.label
            },
            ports: getDefaultPorts()
        },
        insight: {
            shape: 'rect',
            width: 140,
            height: 50,
            label: 'Insight (Created)',
            attrs: {
                body: {
                    stroke: 'transparent',
                    strokeWidth: 0,
                    fill: '#a78bfa',
                    rx: 8,
                    ry: 8
                },
                label: commonAttrs.label
            },
            ports: getDefaultPorts()
        }
    };

    return graph.createNode(nodeConfigs[type] || nodeConfigs.Streamer);
}

// 获取默认端口配置
function getDefaultPorts(type) {
  const obj = {
    groups: {
        in: {
            position: {
                name: 'left',
                // args: {
                //     dx: 0,    // 水平偏移
                //     dy: 4,  // 垂直偏移（负值向上）
                // }
            },
            attrs: {
                circle: {
                    r: 4,
                    magnet: true,
                    strokeWidth: 0,
                    fill: '#000',
                    style: {
                        visibility: 'visible'
                    }
                }
            },
            zIndex: 999 // 提高port的z-index，确保在edge之上
        },
        out: {
            position: {
                name: 'right',
                // args: {
                //     dx: 0,    // 水平偏移
                //     dy: -4,  // 垂直偏移（负值向上）
                // }
            },
            attrs: {
                circle: {
                    r: 4,
                    magnet: true,
                    strokeWidth: 0,
                    fill: '#000',
                    style: {
                        visibility: 'visible'
                    }
                }
            },
            zIndex: 999 // 提高port的z-index，确保在edge之上
        }
    },
    items: []
    };
    if(type === 'Streamer'){
      // Streamer 只有输出端口
      obj.items = [
          { group: 'out', id: 'out_1' },
      ]
    }else if(type === 'Insight'){
      // Insight 只有输入端口
      obj.items = [
          { group: 'in', id: 'in_1' },
      ]
    }else{
      // 其他节点有输入和输出端口
      obj.items = [
          { group: 'in', id: 'in_1' },
          { group: 'out', id: 'out_1' },
      ]
    }
    return obj
}

// 绑定键盘事件
// function bindKeyboard() {
//     // 删除节点
//     graph.bindKey(['backspace', 'delete'], () => {
//         const cells = graph.getSelectedCells();
//         if (cells.length) {
//             graph.removeCells(cells);
//         }
//     });

//     // 复制
//     graph.bindKey('ctrl+c', () => {
//         const cells = graph.getSelectedCells();
//         if (cells.length) {
//             graph.copy(cells);
//         }
//         return false;
//     });

//     // 粘贴
//     graph.bindKey('ctrl+v', () => {
//         if (!graph.isClipboardEmpty()) {
//             const cells = graph.paste({ offset: 32 });
//             graph.cleanSelection();
//             graph.select(cells);
//         }
//         return false;
//     });

//     // 撤销
//     graph.bindKey('ctrl+z', () => {
//         if (graph.canUndo()) {
//             graph.undo();
//         }
//         return false;
//     });

//     // 重做
//     graph.bindKey('ctrl+y', () => {
//         if (graph.canRedo()) {
//             graph.redo();
//         }
//         return false;
//     });
// }

// 自定义鼠标滚轮缩放 - 以鼠标为中心
function initCustomMousewheel() {
    const container = document.getElementById('graph-container');
    
    container.addEventListener('wheel', (e) => {
        // 检查是否按下 Ctrl 或 Meta 键
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            
            // 计算缩放增量（滚轮向下放大，向上缩小）
            const factor = e.deltaY < 0 ? 0.1 : -0.1;
            
            // 获取鼠标在容器中的位置
            const rect = container.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            
            // 以鼠标位置为中必缩放
            graph.zoom(factor,{
              minScale:0.2,
              maxScale:4,
              center: { x: mouseX, y: mouseY }
            });
        }
    }, { passive: false });
}

// 添加示例节点
// function addSampleNodes() {
//     const node1 = graph.addNode({
//         shape: 'rect',
//         x: 100,
//         y: 100,
//         width: 100,
//         height: 60,
//         label: '开始',
//         attrs: {
//             body: {
//                 stroke: '#5F95FF',
//                 strokeWidth: 1,
//                 fill: '#EFF4FF'
//             },
//             label: {
//                 fill: '#333',
//                 fontSize: 14
//             }
//         },
//         ports: getDefaultPorts()
//     });

//     const node2 = graph.addNode({
//         shape: 'rect',
//         x: 300,
//         y: 200,
//         width: 100,
//         height: 60,
//         label: '处理',
//         attrs: {
//             body: {
//                 stroke: '#5F95FF',
//                 strokeWidth: 1,
//                 fill: '#EFF4FF'
//             },
//             label: {
//                 fill: '#333',
//                 fontSize: 14
//             }
//         },
//         ports: getDefaultPorts()
//     });

    

//     graph.addEdge({
//         source: node1,
//         target: node2,
//         attrs: {
//             line: {
//                 stroke: '#5F95FF',
//                 strokeWidth: 2,
//                 targetMarker: {
//                     name: 'block',
//                     width: 12,
//                     height: 8
//                 }
//             }
//         }
//     });
// }

// 工具栏功能
document.addEventListener('DOMContentLoaded', () => {
    // 初始化图形
    initGraph();

    // 放大
    // document.getElementById('zoom-in').addEventListener('click', () => {
    //     graph.zoom(0.1);
    // });

    // // 缩小
    // document.getElementById('zoom-out').addEventListener('click', () => {
    //     graph.zoom(-0.1);
    // });

    // // 适应屏幕
    // document.getElementById('zoom-fit').addEventListener('click', () => {
    //     graph.zoomToFit({ padding: 20 });
    // });

    // // 锁定/解锁
    // document.getElementById('lock-toggle').addEventListener('click', () => {
    //     isLocked = !isLocked;
    //     const lockIcon = document.getElementById('lock-icon');
    //     const lockBtn = document.getElementById('lock-toggle');
        
    //     if (isLocked) {
    //         lockIcon.textContent = '🔒';
    //         lockBtn.classList.add('active');
    //         graph.disablePanning();
    //         graph.disableSelection();
    //         graph.disableHistory();
    //         graph.getCells().forEach(cell => {
    //             cell.setData({ movable: false });
    //         });
    //     } else {
    //         lockIcon.textContent = '🔓';
    //         lockBtn.classList.remove('active');
    //         graph.enablePanning();
    //         graph.enableSelection();
    //         graph.enableHistory();
    //         graph.getCells().forEach(cell => {
    //             cell.setData({ movable: true });
    //         });
    //     }
    // });

    // 清空画布
    // document.getElementById('clear-graph').addEventListener('click', () => {
    //     if (confirm('确定要清空画布吗？')) {
    //         graph.clearCells();
    //     }
    // });
    initCustomMousewheel();
    // 右键菜单工具追踪变量
    let currentNodeWithTools = null; 
    let currentEdgeWithTools = null; 
    
    // 统一清除工具的函数
    const clearAllTools = () => {
        if (currentNodeWithTools) {
            currentNodeWithTools.removeTools();
            currentNodeWithTools = null;
        }
        if (currentEdgeWithTools) {
            currentEdgeWithTools.removeTools();
            currentEdgeWithTools = null;
        }
    };

    // 监听画布/单元格点击或拖拽，清除所有工具
    graph.on('blank:mousedown', clearAllTools);
    graph.on('cell:mousedown', ({ cell }) => {
        if ((currentNodeWithTools && currentNodeWithTools !== cell) || 
            (currentEdgeWithTools && currentEdgeWithTools !== cell)) {
            clearAllTools();
        }
    });

    // 监听node右键事件
    graph.on('node:contextmenu', ({ node, e }) => {
        e.preventDefault(); // 阻止默认右键菜单
        
        // 先移除所有已存在的工具
        clearAllTools();
        
        const { width, height } = node.getSize();
        node.addTools([
          {
            name: 'button-remove',
            args: {
              offset: { x: width-10, y: height-10 },
              color: '#FF4D4F', // 按钮颜色
              onClick({ view }) {
                const node = view.cell;
                graph.removeNode(node);
                currentNodeWithTools = null;
                saveWorkFlow(); // 删除节点后保存
              }
            }
          }
        ]);
        
        currentNodeWithTools = node;
    });
    

    // 监听边连接完成事件
    graph.on('edge:connected', ({ isNew, edge }) => {
      // console.log('edge:connected', { isNew, edge })
      // 检查是否存在相同 source port 和 target port 的边（重复连线检测）
      const allEdges = graph.getEdges();
      const newSource = edge.getSource();
      const newTarget = edge.getTarget();
      const isDuplicate = allEdges.some(e => {
        if (e.id === edge.id) return false; // 跳过自身
        const s = e.getSource();
        const t = e.getTarget();
        return s.cell === newSource.cell &&
               s.port === newSource.port &&
               t.cell === newTarget.cell &&
               t.port === newTarget.port;
      });
      if (isDuplicate) {
        edge.remove();
        return;
      }
      if (isNew) {
        const target = edge.getTarget()
        const source = edge.getSource()
        
        // 判断是否连接到了有效的 port
        // 必须同时满足：source 和 target 都存在，且都有 port 属性
        if (!source || !source.port || !target || !target.port) {
          // 未连接到有效的 port，删除该 edge
          edge.remove()
          return
        }else{
          let _node = graph.getNodes().find(n=>n.id===source.cell)
          const _d = _node.getData()
          edge.setAttrs({
            line: {
                stroke: CONFIG.edgeColors[_d.type],
            }
          });
          edge?.setLabels([
            getLabelObj('?/?(?/?)',_d.type)
          ]);
        }
      }
      saveWorkFlow()
    })
    // Edge右键菜单 - 显示删除按钮
    // 监听edge右键事件
    graph.on('edge:contextmenu', ({ edge, e }) => {
        e.preventDefault(); // 阻止默认右键菜单
        
        // 先移除所有已存在的工具
        clearAllTools();
        
        // 检查是否已经有工具，避免重复添加
        if (!edge.hasTools()) {
            edge.addTools([{
                name: 'button-remove',
                args: { 
                    distance: -20,
                    markup: [{
                        tagName: 'circle',
                        selector: 'button',
                        attrs: {
                            r: 7,
                            fill: '#FF4D4F',
                            cursor: 'pointer',
                            'pointer-events': 'all'
                        }
                    }, {
                        tagName: 'path',
                        selector: 'icon',
                        attrs: {
                            d: 'M -3 -3 3 3 M 3 -3 -3 3',
                            fill: 'none',
                            stroke: '#fff',
                            'stroke-width': 2,
                            'pointer-events': 'none'
                        }
                    }],
                    onClick({ view }) {
                        const edge = view.cell;
                        graph.removeEdge(edge);
                        currentEdgeWithTools = null;
                        saveWorkFlow(); // 删除连线后保存
                    }
                },
            }]);
        }
        
        currentEdgeWithTools = edge;
    });
    

    
    // 监听边连接过程中的鼠标释放事件
    graph.on('edge:mouseup', ({ edge, e }) => {
      // 检查边是否已经正确连接
      const target = edge.getTarget()
      const source = edge.getSource()

      
      // 如果 target 或 source 没有 port，说明没有连接到有效的连接桩
      if (!target || !target.port || !source || !source.port) {
        edge.remove()
      }
    })

    graph.on('blank:click', () => {
      clearAllTools();
    })

    // 绑定侧边栏节点拖拽事件
    const nodeItems = document.querySelectorAll('.node-item');
    nodeItems.forEach(item => {
        item.addEventListener('dragstart', handleDragStart);
        item.addEventListener('dragend', handleDragEnd);
    });

    // 绑定画布的 drop 事件
    const graphContainer = document.getElementById('graph-container');
    
    graphContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
    });
    
    graphContainer.addEventListener('drop', (e) => {
        e.preventDefault();
        const nodeType = e.dataTransfer.getData('node-type');
        if (!nodeType) return;
        
        // 计算放置位置（转换为画布坐标）
        const rect = graphContainer.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // 转换为画布坐标系统
        const point = graph.clientToLocal({ x, y });
        
        // 直接打开配置面板，不创建节点
        openConfigPanelForCreate(nodeType, point);
    });

    // 移除原有的 node:added 监听，因为不再自动创建节点
    // graph.on('node:added', ...) 已删除

    // 监听节点双击事件
    graph.on('node:dblclick', ({ node, e }) => {
        e.preventDefault();
        // 打开编辑面板
        openConfigPanelForEdit(node);
    });

});

// setLabels
function getLabelObj(label,type) {
  return {
      attrs: {
        label:{
          fill:CONFIG.edgeFont[type]
        },
        // line: {
        //   stroke: '#73d13d',
        // },
        body:{
          fill:'transparent',
        },
        text: {
          text: label,
        },
      },
    }
}

// 画布居中并自动缩放
function centerAndFitCanvas() {
  // 使用 zoomToFit 自动计算缩放比例，并预留 50px 的内边距
  graph.zoomToFit({
    padding: 50,
    maxScale: 1, // 最高缩放到 1，避免只有少量节点时缩放太大
  });
  // 确保内容在视图中心
  graph.centerContent();
}

function refreshWorkflowGraph(options = {}) {
  const { arrange = false } = options
  return API.getWorkflow().then(res => {
    const data = res.data;
    graph.clearCells();
    data.nodes.forEach(n => {
      graph.addNode(createNode(n.data, n.position, n.id));
    });
    data.edges.forEach(e => {
      graph.addEdge(createEdge(e));
    });

    if (arrange) {
      arrangeLayout();
    } else {
      centerAndFitCanvas();
    }
  });
}

// 初始化的接口
function initAPI(){
  refreshWorkflowGraph({ arrange: true }).then(()=>{
    window.setInterval(() => {
      API.getEdgeParams().then(res=>{
        const {labels,processIds,resolutions,processStatus,fresh_workflow} = res.data
        if (fresh_workflow) {
          refreshWorkflowGraph({ arrange: true });
          return;
        }

        for(let k in resolutions){
          const node = graph.getNodes().find(n=>n.id===k)
          updateNodeContent(node,'resolution',resolutions[k])
        }

        for(let k in processIds){
          const node = graph.getNodes().find(n=>n.id===k)
          updateNodeContent(node,'processId',processIds[k], processStatus?.[k])
        }

        for(let k in labels){
          const edge = graph.getEdges().find(e=>e.id===k)
          if (!edge) {
            continue
          }
          const node = graph.getNodes().find(n=>n.id===edge.getSource().cell)
          const nodeData = node.getData();
          edge.setLabels([
            getLabelObj(labels[k],nodeData.type)
          ]);
        }
    })
    }, 2000);

    
  })

}

// 侧边栏切换
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const toggleIcon = document.getElementById('toggle-icon');
    
    sidebar.classList.toggle('open');
    
    if (sidebar.classList.contains('open')) {
        toggleIcon.textContent = '>';
    } else {
        toggleIcon.textContent = '<';
    }
}


// 创建edge
function createEdge(data) {
  const source = data.source;
  const target = data.target;
  let _node = graph.getNodes().find(n=>n.id===source)
  const _d = _node.getData()
  const edge = graph.createEdge({
    id: data.id,
    source: {
      cell:source,
      port:"out_1",
    },
    target: {
      cell:target,
      port:"in_1",
    },
    attrs: {
        line: {
            stroke: CONFIG.edgeColors[_d.type],
            strokeWidth: 2,
            targetMarker: null,
        }
    },
    zIndex: -999,
    labels:[
      {
        attrs: {
          label:{
            fill:CONFIG.edgeFont[_d.type]
          },
          body:{
            fill:'transparent',
            pointerEvents: 'none',
          },
          text: {
            text: data.data.label,
            pointerEvents: 'none',
          },
        },
      }
    ]
  });
  edge.setData(data.data)
  return edge
}
function pidColor(status, pid) {
  if (status === 'dead' || pid === undefined || pid === '?' || pid === '') return 'rgb(170, 0, 0)';
  if (status === 'ready') return 'rgb(128, 128, 128)';
  return 'rgb(0, 128, 0)';
}

// 创建节点
function createNode(data,pos,id='') {
  let obj = {}
  const type = data.type
  const pid = data.processId===undefined?'?':data.processId
  const pidStr = `<div class="${type}_processId processId" style="color:${pidColor(data.processStatus, pid)}">${pid}</div>`
  if(type === 'Streamer'){
    obj = {
      shape: 'html',
      width: 150, // 默认宽度
      height: 89, // 默认高度
      ports: getDefaultPorts('Streamer'),
      x:pos.x,
      y:pos.y,
      attrs: {
          body: {
              rx: 10, // 圆角矩形
              ry: 10,
              strokeWidth: 1,
          },
      },
      html: () => {
          const sc = CONFIG.nodeTypes.find(n => n.type === 'Streamer').color
          const wrap = document.createElement('div');
          wrap.classList.add('Streamer')
          wrap.classList.add('_node')
          wrap.style.background = sc;
          wrap.innerHTML = `
          ${pidStr}
          <div class="nodeContent">
            <div class="title">${data.label}</div>
            <div class="extra"><span class="_url" title="${data.params?.stream}">${data.params?.stream}</span></div>
            <div class="extra Streamer_resolution">${data.resolution}</div>
          </div>
          `;


          // 创建视频播放按钮
          const playBtn = document.createElement('div');
          playBtn.className = 'play-video-btn';
          playBtn.style.cssText = `
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            cursor: pointer;
            z-index: 10;
            transition: transform 0.2s ease, opacity 0.2s ease;
            opacity: 0.8;
          `;
          
          const playImg = document.createElement('img');
          playImg.src = '/static/images/playVideo.png';
          playImg.style.cssText = `
            width: 100%;
            height: 100%;
            display: block;
          `;
          playImg.title="播放视频"
          playBtn.appendChild(playImg);
          
          // 添加鼠标悬浮效果
          playBtn.addEventListener('mouseenter', () => {
            playBtn.style.transform = 'scale(1.2)';
            playBtn.style.opacity = '1';
          });
          
          playBtn.addEventListener('mouseleave', () => {
            playBtn.style.transform = 'scale(1)';
            playBtn.style.opacity = '0.8';
          });
          
          // 添加点击事件
          playBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            window.open(`/insight/${data.label}`, '_blank');
          });
          
          wrap.appendChild(playBtn);
          return wrap;
      },
    }
    if(id)obj['id'] = id
    
  }else if(type === 'Algorithm'){
    obj = {
      shape: 'html',
      width: 150, // 默认宽度
      height: 66, // 默认高度
      ports: getDefaultPorts('Algorithm'),
      x:pos.x,
      y:pos.y,
      attrs: {
          body: {
              rx: 10, // 圆角矩形
              ry: 10,
              strokeWidth: 1,
          },
      },
      html: () => {
          const sc = CONFIG.nodeTypes.find(n => n.type === 'Algorithm').color
          const wrap = document.createElement('div');
          wrap.classList.add('Algorithm')
          wrap.classList.add('_node')
          wrap.style.background = sc;
          wrap.innerHTML = `
          ${pidStr}
          <div class="nodeContent">
            <div class="title">${data.label}</div>
            <div class="extra">${data.params?.task_type}</div>
          </div>
          `;
          return wrap;
      },
    }
    if(id)obj['id'] = id
  }else if(type === 'Insight'){
    obj = {
      shape: 'html',
      width: 150, // 默认宽度
      height: 45, // 默认高度
      ports: getDefaultPorts('Insight'),
      x:pos.x,
      y:pos.y,
      attrs: {
          body: {
              rx: 10, // 圆角矩形
              ry: 10,
              strokeWidth: 1,
          },
      },
      html: () => {
          const sc = CONFIG.nodeTypes.find(n => n.type === 'Insight').color
          const wrap = document.createElement('div');
          wrap.classList.add('Insight')
          wrap.classList.add('_node')
          wrap.style.background = sc;
          wrap.innerHTML = `
          ${pidStr}
          <div class="nodeContent">
            <div class="title">${data.label}</div>
          </div>
          `;
          return wrap;
      },
    }
    if(id)obj['id'] = id
  }else if(type === 'Logic'){
    obj = {
      shape: 'html',
      width: 150, // 默认宽度
      height: 45, // 默认高度
      ports: getDefaultPorts('Logic'),
      x:pos.x,
      y:pos.y,
      attrs: {
          body: {
              rx: 10, // 圆角矩形
              ry: 10,
              strokeWidth: 1,
          },
      },
      html: () => {
          const sc = CONFIG.nodeTypes.find(n => n.type === 'Logic').color
          const wrap = document.createElement('div');
          wrap.classList.add('Logic')
          wrap.classList.add('_node')
          wrap.style.background = sc;
          wrap.innerHTML = `
          ${pidStr}
          <div class="nodeContent">
            <div class="title">${data.label}</div>
          </div>
          `;
          return wrap;
      },
    }
    if(id)obj['id'] = id
  }else{
    obj = {
      shape: 'html',
      width: 150, // 默认宽度
      height: 45, // 默认高度
      ports: getDefaultPorts('Report'),
      x:pos.x,
      y:pos.y,
      attrs: {
          body: {
              rx: 10, // 圆角矩形
              ry: 10,
              strokeWidth: 1,
          },
      },
      html: () => {
          const sc = CONFIG.nodeTypes.find(n => n.type === 'Report').color
          const wrap = document.createElement('div');
          wrap.classList.add('Report')
          wrap.classList.add('_node')
          wrap.style.background = sc;
          wrap.innerHTML = `
          ${pidStr}
          <div class="nodeContent">
            <div class="title">${data.label}</div>
          </div>
          `;
          return wrap;
      },
    }
      if(id)obj['id'] = id
  }
  obj['data'] = data
  const r = graph.createNode(obj)
  r.setData(data)
  return r
}
function updateNodeContent(node, key, val, status) {
  if (!node) return
  const data = node.getData();
  data[key] = val
  if (status !== undefined) data.processStatus = status
  node.setData(data);

  const view = node.findView(graph);
  if (!view) return
  const span = view.container.querySelector('.' + data.type + '_' + key);
  if (!span) return
  span.textContent = val;
  if (key === 'processId') span.style.color = pidColor(data.processStatus, val);
}

// 右上角按钮功能函数
// 重启服务
function restartService() {
    // 显示确认弹窗
    showRestartModal();
}

// 显示重启确认弹窗
function showRestartModal() {
    const modal = document.getElementById('restart-confirm-modal');
    const overlay = document.getElementById('restart-modal-overlay');
    
    modal.classList.add('show');
    overlay.classList.add('show');
}

// 关闭重启确认弹窗
function closeRestartModal() {
    const modal = document.getElementById('restart-confirm-modal');
    const overlay = document.getElementById('restart-modal-overlay');
    
    modal.classList.remove('show');
    overlay.classList.remove('show');
}

// 确认重启
function confirmRestart() {
    // 关闭弹窗
    closeRestartModal();
    
    API.restartServer()
        .then(res => {
            if (res.data && res.data.status === 'success') {
                console.log('重启响应:', res.data);
            } else {
                console.error('重启失败:', res.data);
            }
        })
        .catch(err => {
            console.error('重启错误:', err);
        });
}

// 自动排列节点 - 按连线顺序横向排列
function autoArrangeNodes() {
  const nodes = graph.getNodes();
  const edges = graph.getEdges();
  
  if (nodes.length === 0) return;
  
  const adjacencyList = new Map(); // 节点ID -> 子节点ID数组
  const nodeMap = new Map(); // 节点ID -> 节点对象
  
  // 初始化
  nodes.forEach(node => {
    const id = node.id;
    nodeMap.set(id, node);
    adjacencyList.set(id, []);
  });
  
  // 构建图结构
  edges.forEach(edge => {
    const source = edge.getSource();
    const target = edge.getTarget();
    
    if (source && source.cell && target && target.cell) {
      const sourceId = source.cell;
      const targetId = target.cell;
      
      if (adjacencyList.has(sourceId)) {
        adjacencyList.get(sourceId).push(targetId);
      }
    }
  });
  
  // 反向邻接表: 节点ID -> 父节点ID数组
  const parentList = new Map();
  nodes.forEach(node => parentList.set(node.id, []));
  adjacencyList.forEach((children, sourceId) => {
    children.forEach(childId => {
      if (parentList.has(childId)) parentList.get(childId).push(sourceId);
    });
  });

  const isStreamer = id => nodeMap.get(id).getData()?.type === 'Streamer';

  // 列号: Streamer 固定为 0, 其他节点 = 父节点最大列号 + 1; 无父节点的非 Streamer 节点放第 1 列
  // 环上的回连边在 DFS 中被忽略, 避免死循环
  const column = new Map();
  const visiting = new Set();
  const getColumn = id => {
    if (column.has(id)) return column.get(id);
    if (isStreamer(id)) {
      column.set(id, 0);
      return 0;
    }
    visiting.add(id);
    let col = 1;
    parentList.get(id).forEach(pid => {
      if (!visiting.has(pid)) col = Math.max(col, getColumn(pid) + 1);
    });
    visiting.delete(id);
    column.set(id, col);
    return col;
  };
  nodes.forEach(node => getColumn(node.id));

  const levels = [];
  nodes.forEach(node => {
    const col = column.get(node.id);
    if (!levels[col]) levels[col] = [];
    levels[col].push(node.id);
  });

  // 每列按父节点在上一列中的平均位置排序, 减少连线交叉
  const rowIndex = new Map();
  levels.forEach((level, col) => {
    if (!level) return;
    if (col > 0) {
      const weight = id => {
        const rows = parentList.get(id).filter(pid => rowIndex.has(pid)).map(pid => rowIndex.get(pid));
        return rows.length ? rows.reduce((a, b) => a + b, 0) / rows.length : Number.MAX_SAFE_INTEGER;
      };
      const weights = new Map(level.map(id => [id, weight(id)]));
      level.sort((a, b) => weights.get(a) - weights.get(b));
    }
    level.forEach((id, i) => rowIndex.set(id, i));
  });
  for (let i = levels.length - 1; i >= 0; i--) {
    if (!levels[i]) levels.splice(i, 1);
  }
  
  // 计算布局参数
  const horizontalSpacing = 200; // 横向间隔
  const verticalSpacing = 100; // 纵向间隔
  const startX = 100; // 起始X坐标
  
  // 按层级设置节点位置
  let currentX = startX;
  
  levels.forEach((level, levelIndex) => {
    // 计算当前层级的总高度，用于中心对齐
    const totalHeight = level.reduce((sum, nodeId) => {
      const node = nodeMap.get(nodeId);
      if (node) {
        const size = node.getSize();
        return sum + size.height;
      }
      return sum;
    }, 0) + (level.length - 1) * verticalSpacing;
    
    // 计算起始Y坐标，使节点组在垂直方向居中
    const centerY = 300; // 画布中心线Y坐标
    let currentY = centerY - totalHeight / 2;
    
    level.forEach((nodeId, nodeIndex) => {
      const node = nodeMap.get(nodeId);
      if (node) {
        const size = node.getSize();
        
        // 设置节点位置
        node.setPosition({
          x: currentX,
          y: currentY
        });
        
        // 更新Y坐标为下一个节点准备
        currentY += size.height + verticalSpacing;
      }
    });
    
    // 更新X坐标到下一列
    // 使用当前层级中最宽的节点宽度
    const maxWidth = Math.max(...level.map(nodeId => {
      const node = nodeMap.get(nodeId);
      return node ? node.getSize().width : 0;
    }));
    
    currentX += maxWidth + horizontalSpacing;
  });
  
  // 排列完成后,自动居中并缩放画布
  setTimeout(() => {
    centerAndFitCanvas();
  }, 100);
}

function arrangeLayout() {
  autoArrangeNodes();
}

// AI 对话功能
let selectedFiles = [];
let uploadedFilePaths = []; // 保存已上传文件的路径
let chatHistory = []; // 保存聊天历史
const CHAT_SESSION_KEY = 'cpipe_chat_session_id';
const CHAT_MODE_KEY = 'cpipe_chat_mode';
let chatMode = 'normal'; // normal | knowledge
let chatRequestInFlight = false;
let chatMessageCounter = 0;

function setChatSendingState(isSending) {
    const sendBtn = document.querySelector('.chat-send-btn');
    if (!sendBtn) return;
    sendBtn.disabled = isSending;
    sendBtn.style.opacity = isSending ? '0.6' : '1';
    sendBtn.style.cursor = isSending ? 'not-allowed' : 'pointer';
}

function initChatMode() {
    const savedMode = window.sessionStorage.getItem(CHAT_MODE_KEY);
    chatMode = savedMode === 'knowledge' ? 'knowledge' : 'normal';
    const toggle = document.getElementById('knowledge-mode-toggle');
    if (toggle) {
        toggle.checked = chatMode === 'knowledge';
    }
}

function toggleKnowledgeMode(event) {
    chatMode = event?.target?.checked ? 'knowledge' : 'normal';
    window.sessionStorage.setItem(CHAT_MODE_KEY, chatMode);
}

function createSessionId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
        return window.crypto.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getOrCreateChatSessionId() {
    let sid = window.sessionStorage.getItem(CHAT_SESSION_KEY);
    if (!sid) {
        sid = createSessionId();
        window.sessionStorage.setItem(CHAT_SESSION_KEY, sid);
    }
    return sid;
}

// 切换对话面板
function toggleChatPanel() {
    const chatPanel = document.getElementById('chat-panel');
    const isOpen = chatPanel.classList.contains('open');
    
    if (isOpen) {
        // 关闭聊天面板
        chatPanel.classList.remove('open');
        // 移除点击外部关闭的监听器
        document.removeEventListener('click', closeChatOnOutsideClick);
    } else {
        // 打开聊天面板
        chatPanel.classList.add('open');
        // 添加点击外部关闭的监听器
        setTimeout(() => {
            document.addEventListener('click', closeChatOnOutsideClick);
        }, 100);
    }
}

// 点击外部区域关闭聊天面板
function closeChatOnOutsideClick(event) {
    const chatPanel = document.getElementById('chat-panel');
    const chatFloatIcon = document.querySelector('.chat-float-icon');
    
    // 如果点击的不是聊天面板内部，也不是浮动图标，则关闭
    if (!chatPanel.contains(event.target) && !chatFloatIcon.contains(event.target)) {
        chatPanel.classList.remove('open');
        document.removeEventListener('click', closeChatOnOutsideClick);
    }
}

// 处理文件选择
function handleFileSelect(event) {
    const files = Array.from(event.target.files);
    selectedFiles = files;
    
    const fileCountEl = document.getElementById('file-count');
    if (files.length > 0) {
        fileCountEl.textContent = `Uploading... (0/${files.length})`;
        fileCountEl.style.color = '#1890ff';
        
        // 自动上传文件
        uploadSelectedFiles();
    } else {
        fileCountEl.textContent = 'No file selected';
        fileCountEl.style.color = '#8c8c8c';
    }
}

// 上传选中的文件
function uploadSelectedFiles() {
    const fileCountEl = document.getElementById('file-count');
    const totalCount = selectedFiles.length;
    
    fileCountEl.textContent = `Uploading... (${totalCount} files)`;
    fileCountEl.style.color = '#1890ff';
    
    // 一次性上传所有文件
    API.uploadFiles(selectedFiles)
        .then(res => {
            
            // 检查不同可能的返回格式
            let filePaths = [];
            
            // 格式1: { paths: [...] }
            if (res.data && res.data.paths && Array.isArray(res.data.paths)) {
                filePaths = res.data.paths;
            }
            
            
            if (filePaths.length > 0) {
                uploadedFilePaths = filePaths;
                fileCountEl.textContent = `Uploaded ${filePaths.length} files`;
                fileCountEl.style.color = '#52c41a';
                
                // 在对话框中显示上传的文件路径
                const fileListText = filePaths.map((path, index) => `${index + 1}. ${path}`).join('\n');
                const uploadMessage = `Files uploaded successfully!\n\n${fileListText}`;
                addMessageToChat('assistant', uploadMessage);
            } else {
                fileCountEl.textContent = 'Upload failed: No file path returned';
                fileCountEl.style.color = '#ff4d4f';
            }
        })
        .catch(err => {
            console.error('文件上传错误:', err);
            fileCountEl.textContent = 'Upload failed';
            fileCountEl.style.color = '#ff4d4f';
            addMessageToChat('assistant', 'Upload failed: ' + (err.message || 'Network error'));
        });
}

// 处理键盘事件（Enter 发送，Shift+Enter 换行）
function handleChatKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// 发送消息
function sendMessage() {
    if (chatRequestInFlight) {
        return;
    }
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message && uploadedFilePaths.length === 0) {
        return;
    }
    
    // 保存用户消息到历史记录
    const userMessage = {
        role: 'user',
        content: message || '(Sent files)',
        file_paths: uploadedFilePaths.length > 0 ? [...uploadedFilePaths] : [],
        timestamp: Date.now()
    };
    chatHistory.push(userMessage);
    
    // 显示用户消息
    addMessageToChat('user', userMessage.content);
    
    // 清空输入框
    input.value = '';
    chatRequestInFlight = true;
    setChatSendingState(true);

    // 显示加载中
    const loadingMsgId = addMessageToChat('assistant', 'Thinking...');

    const safeFilePaths = uploadedFilePaths.length > 0 ? [...uploadedFilePaths] : [];
    // 发送聊天消息
    sendChatMessage(message, safeFilePaths, loadingMsgId);
}

// 发送聊天消息
async function sendChatMessage(message, filePaths, loadingMsgId) {
    const sessionId = getOrCreateChatSessionId();
    const chatData = {
        session_id: sessionId,
        message: message,
        file_paths: filePaths,
        chat_mode: chatMode
    };

    try {
        const res = await API.chat(chatData);
        removeMessage(loadingMsgId);

        if (res.data && res.data.session_id) {
            window.sessionStorage.setItem(CHAT_SESSION_KEY, res.data.session_id);
        }

        if (res.data && res.data.answer) {
            const normalizedAnswer = normalizeAssistantContent(res.data.answer);
            const assistantMessage = {
                role: 'assistant',
                content: normalizedAnswer,
                timestamp: Date.now()
            };
            chatHistory.push(assistantMessage);
            addMessageToChat('assistant', normalizedAnswer);
        } else {
            const errorMsg = 'CPipe ERROR: Sorry, I did not understand your question.';
            chatHistory.push({
                role: 'assistant',
                content: errorMsg,
                timestamp: Date.now()
            });
            addMessageToChat('assistant', errorMsg);
        }
    } catch (err) {
        removeMessage(loadingMsgId);
        console.error('AI 对话错误:', err);
        const isTimeout = (err && err.code === 'ECONNABORTED') || String(err?.message || '').includes('timeout');
        const errorMsg = isTimeout
            ? '请求超时：任务可能仍在后台执行。请稍后查看工作流是否已更新，或重试一次。'
            : 'Sorry, server error: ' + (err.message || 'Network error');
        chatHistory.push({
            role: 'assistant',
            content: errorMsg,
            timestamp: Date.now()
        });
        addMessageToChat('assistant', errorMsg);
    } finally {
        chatRequestInFlight = false;
        setChatSendingState(false);
        clearFileSelection();
    }
}

// 清空文件选择
function clearFileSelection() {
    selectedFiles = [];
    uploadedFilePaths = [];
    document.getElementById('chat-file-input').value = '';
    document.getElementById('file-count').textContent = 'No file selected';
    document.getElementById('file-count').style.color = '#8c8c8c';
}

function appendTextWithInlineCode(container, text) {
    const textBlock = document.createElement('div');
    textBlock.className = 'chat-text-block';
    const parts = text.split(/(`[^`\n]+`)/g);
    parts.forEach(part => {
        if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
            const inlineCode = document.createElement('code');
            inlineCode.className = 'chat-inline-code';
            inlineCode.textContent = part.slice(1, -1);
            textBlock.appendChild(inlineCode);
        } else {
            textBlock.appendChild(document.createTextNode(part));
        }
    });
    container.appendChild(textBlock);
}

function appendCodeBlock(container, language, code) {
    const codeWrapper = document.createElement('div');
    codeWrapper.className = 'chat-code-block';

    const header = document.createElement('div');
    header.className = 'chat-code-header';

    const langTag = document.createElement('div');
    langTag.className = 'chat-code-lang';
    langTag.textContent = language || 'code';
    header.appendChild(langTag);

    const copyButton = document.createElement('button');
    copyButton.type = 'button';
    copyButton.className = 'chat-code-copy-btn';
    copyButton.textContent = 'Copy';
    copyButton.addEventListener('click', async () => {
        const original = copyButton.textContent;
        try {
            await navigator.clipboard.writeText(code);
            copyButton.textContent = 'Copied';
            copyButton.classList.add('copied');
        } catch (err) {
            // Fallback for insecure context or unsupported clipboard API.
            const temp = document.createElement('textarea');
            temp.value = code;
            temp.style.position = 'fixed';
            temp.style.left = '-9999px';
            document.body.appendChild(temp);
            temp.select();
            document.execCommand('copy');
            document.body.removeChild(temp);
            copyButton.textContent = 'Copied';
            copyButton.classList.add('copied');
        }
        window.setTimeout(() => {
            copyButton.textContent = original;
            copyButton.classList.remove('copied');
        }, 1200);
    });
    header.appendChild(copyButton);
    codeWrapper.appendChild(header);

    const pre = document.createElement('pre');
    const codeEl = document.createElement('code');
    codeEl.textContent = code;
    pre.appendChild(codeEl);
    codeWrapper.appendChild(pre);
    container.appendChild(codeWrapper);
}

function normalizeAssistantContent(rawContent) {
    const content = typeof rawContent === 'string' ? rawContent : String(rawContent ?? '');
    // Remove leading blank lines only; keep intentional internal line breaks.
    return content.replace(/^(?:[ \t]*\r?\n)+/, '');
}

function renderMessageContent(container, rawContent) {
    const content = typeof rawContent === 'string' ? rawContent : String(rawContent ?? '');
    const codeBlockPattern = /```([^\n`]*)\n([\s\S]*?)```/g;
    let cursor = 0;
    let match = null;

    while ((match = codeBlockPattern.exec(content)) !== null) {
        const before = content.slice(cursor, match.index);
        if (before) {
            appendTextWithInlineCode(container, before);
        }

        const language = (match[1] || '').trim();
        const code = (match[2] || '').replace(/\s+$/, '');
        appendCodeBlock(container, language, code);
        cursor = codeBlockPattern.lastIndex;
    }

    const tail = content.slice(cursor);
    if (tail || !container.childNodes.length) {
        appendTextWithInlineCode(container, tail);
    }
}

// 添加消息到对话区
function addMessageToChat(role, content) {
    const messagesContainer = document.getElementById('chat-messages');
    chatMessageCounter += 1;
    const messageId = 'msg-' + Date.now() + '-' + chatMessageCounter;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${role}`;
    messageDiv.id = messageId;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = role === 'user' ? 'You' : 'AI';
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    renderMessageContent(messageContent, content);
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(messageContent);
    
    messagesContainer.appendChild(messageDiv);
    
    // 滚动到底部
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    return messageId;
}

// 移除消息
function removeMessage(messageId) {
    const messageEl = document.getElementById(messageId);
    if (messageEl) {
        messageEl.remove();
    }
}

// 清空聊天历史
function clearChatHistory() {
    chatHistory = [];
    uploadedFilePaths = [];
    window.sessionStorage.setItem(CHAT_SESSION_KEY, createSessionId());
    const messagesContainer = document.getElementById('chat-messages');
    messagesContainer.innerHTML = '';
}

// 配置面板相关变量
let currentEditNode = null; // 当前正在编辑的节点
let isCreatingNode = false; // 是否是创建新节点
let pendingNodeType = null; // 待创建的节点类型
let pendingNodePosition = null; // 待创建的节点位置
let taskParamsCache = {}; // 缓存不同 task_type 的表单参数数据
let fieldTypesMap = {}; // 记录字段类型映射 {fieldName: 'string'|'number'}

// 打开配置面板 - 创建新节点
function openConfigPanelForCreate(nodeType, position) {
    isCreatingNode = true;
    pendingNodeType = nodeType;
    pendingNodePosition = position;
    currentEditNode = null;
    
    // 设置标题
    document.getElementById('config-title').textContent = `Create ${nodeType} Node`;
    
    // 显示加载状态
    const formContainer = document.getElementById('form-container');
    formContainer.innerHTML = '<p style="color: #999; text-align: center; padding: 20px;">Loading form configuration...</p>';
    
    // 显示面板
    document.getElementById('config-panel').classList.add('open');
    document.getElementById('config-overlay').classList.add('show');
    
    // 调用接口获取节点参数配置
    const typeMap = {
        'streamer': 'Streamer',
        'algorithm': 'Algorithm',
        'logic': 'Logic',
        'report': 'Report',
        'insight': 'Insight'
    };
    const mappedType = typeMap[nodeType.toLowerCase()] || nodeType;
    
    API.getNodeParams(mappedType)
        .then(res => {
            if (res.data && res.data.status === 'success') {
              const taskTypeField = res.data.data[0]; // 只有一个 task_type 字段
              // 在选项前面添加一个--Please Select--
              if (taskTypeField && taskTypeField.options) {
                  taskTypeField.options.unshift('--Please Select--');
              }
              renderForm(taskTypeField, null, mappedType);
            }
        })
        .catch(err => {
            console.error('获取节点参数失败:', err);
            formContainer.innerHTML = '<p class="error-message">Failed to load form configuration</p>';
        });
}

// 打开配置面板 - 编辑已有节点
function openConfigPanelForEdit(node) {
    isCreatingNode = false;
    currentEditNode = node;
    pendingNodeType = null;
    pendingNodePosition = null;
    
    const nodeData = node.getData();
    
    // 设置标题
    document.getElementById('config-title').textContent = `Edit ${nodeData.type} Node`;
    
    // 显示加载状态
    const formContainer = document.getElementById('form-container');
    formContainer.innerHTML = '<p class="loading-message">Loading form configuration...</p>';
    
    // 显示面板
    document.getElementById('config-panel').classList.add('open');
    document.getElementById('config-overlay').classList.add('show');
    
    // 调用接口获取节点参数配置
    API.getNodeParams(nodeData.type)
        .then(res => {
            if (res.data && res.data.status === 'success') {
                const taskTypeField = res.data.data[0]; // task_type 字段
                
                // 添加 --Please Select-- 选项
                if (taskTypeField && taskTypeField.options) {
                    taskTypeField.options.unshift('--Please Select--');
                }
                
                // 渲染基础表单（包含 node_name 和 task_type）
                renderForm(taskTypeField, nodeData, nodeData.type);
                
                // 如果节点已有 task_type，自动加载对应的任务参数
                if (nodeData.params && nodeData.params.task_type) {
                    loadTaskParams(nodeData.type, nodeData.params.task_type, nodeData.params);
                }
            } else {
                formContainer.innerHTML = '<p class="error-message">Failed to load form configuration</p>';
            }
        })
        .catch(err => {
            console.error('获取节点参数失败:', err);
            formContainer.innerHTML = '<p class="error-message">Failed to load form configuration</p>';
        });
}

// 关闭配置面板
function closeConfigPanel() {
    document.getElementById('config-panel').classList.remove('open');
    document.getElementById('config-overlay').classList.remove('show');
    
    // 清空状态
    currentEditNode = null;
    isCreatingNode = false;
    pendingNodeType = null;
    pendingNodePosition = null;
    taskParamsCache = {}; // 清空缓存
    fieldTypesMap = {}; // 清空字段类型映射
}

// 提交节点配置
function submitNodeConfig() {
    // 收集表单数据
    const formData = collectFormData();

    // 检查并处理formData中的null值
    Object.keys(formData).forEach(key => {
        if (formData[key] === null) {
            formData[key] = '';
        }
    });
    formData.router = +formData.router;
    
    // 根据字段类型映射进行类型转换
    Object.keys(fieldTypesMap).forEach(fieldName => {
        if (formData.hasOwnProperty(fieldName)) {
            const targetType = fieldTypesMap[fieldName];
            if (targetType === 'number') {
                // 转换为数字类型
                const value = formData[fieldName];
                if (value !== '' && value !== null && value !== undefined) {
                    formData[fieldName] = Number(value);
                }
            }
            // string 类型不需要转换
        }
    });

    // 验证必填项
    if (!validateForm(formData)) {
        return;
    }
    if (isCreatingNode) {
        // 现在才真正创建节点
        createNodeWithFormData(pendingNodeType, pendingNodePosition, formData);
    } else {
        // 更新已有节点
        updateNodeWithData(currentEditNode, formData);
    }
    
    closeConfigPanel();
}

// 表单验证
function validateForm(formData) {
    const formContainer = document.getElementById('form-container');
    const inputs = formContainer.querySelectorAll('input, select, textarea');
    
    let isValid = true;
    let firstErrorField = null;
    
    inputs.forEach(input => {
        const fieldName = input.getAttribute('data-field-name');
        const isRequired = input.getAttribute('data-required') === 'true';
        const value = input.value;
        
        // 移除之前的错误样式
        input.classList.remove('error');
        
        // 检查必填项
        if (isRequired && (!value || value.trim() === '' || value === '--Please Select--')) {
            input.classList.add('error');
            isValid = false;
            
            if (!firstErrorField) {
                firstErrorField = input;
            }
        }
        
        // 检查节点名称是否通过验证
        if (fieldName === 'node_name' && input.classList.contains('error') && !input.classList.contains('success')) {
            // 如果名称字段有 error 类且没有 success 类，说明名称重复或未通过验证
            isValid = false;
            if (!firstErrorField) {
                firstErrorField = input;
            }
        }
    });
    
    if (!isValid) {
        // 聚焦到第一个错误字段
        if (firstErrorField) {
            firstErrorField.focus();
        }
    }
    
    return isValid;
}

// 保存工作流
function saveWorkFlow() {
    // 获取画布中的所有节点和连线
    const nodes = graph.getNodes();
    const edges = graph.getEdges();
    
    // 转换节点数据格式
    const nodesData = nodes.map(node => {
        const position = node.getPosition();
        const size = node.getSize();
        const data = node.getData();
        
        return {
            id: node.id,
            type: 'custom',
            position: {
                x: position.x,
                y: position.y
            },
            data: {
                label: data.label || '',
                type: data.type || '',
                params: data.params || {},
                processId: data.processId,
                resolution: data.resolution,
                processStatus: data.processStatus
            },
            className: node.attrs?.body?.class || `CPipeNode ${data.type}`,
            width: size.width,
            height: size.height,
            positionAbsolute: {
                x: position.x,
                y: position.y
            }
        };
    });
    
    // 转换连线数据格式
    const edgesData = edges.map(edge => {
        const source = edge.getSource();
        const target = edge.getTarget();
        const edgeData = edge.getData() || {};
        
        return {
            id: edge.id,
            source: source.cell,
            target: target.cell,
            sourceHandle: source.port || 'output_1',
            type: 'custom',
            animated: true,
            targetHandle: target.port || 'top',
            data: {
                type: edgeData.type || '',
                sourceType: edgeData.sourceType || '',
                label: edgeData.label || '',
                edgeStyle: edgeData.edgeStyle || 'straight'
            },
            style: {
                strokeWidth: 2
            }
        };
    });
    
    // 组装完整的工作流数据
    const workflowData = {
        nodes: nodesData,
        edges: edgesData,
    };
    
    
    // 调用 API 保存
    API.saveToFile(workflowData)
        .then(() => refreshWorkflowGraph())
        .catch(err => {
            console.error('保存错误:', err);
        });
    
    return workflowData;
}

// 根据表单数据创建节点
function createNodeWithFormData(nodeType, position, formData) {
    // 将节点类型转换为首字母大写（匹配 createNode 函数的类型）
    const typeMap = {
        'streamer': 'Streamer',
        'algorithm': 'Algorithm',
        'logic': 'Logic',
        'report': 'Report',
        'insight': 'Insight'
    };
    
    const mappedType = typeMap[nodeType.toLowerCase()] || nodeType;
    
    // 从 formData 中提取 node_name 作为 label
    const nodeName = formData.node_name || mappedType;
    delete formData.node_name; // 从 params 中移除 node_name
    
    // 根据节点类型创建相应的节点数据
    const data = {
        label: nodeName,
        type: mappedType,
        params: formData,
    };
    
    // 使用 createNode 函数创建节点
    const node = createNode(data, position);
    graph.addNode(node);

    saveWorkFlow()
    
    return node;
}

// 更新节点数据
function updateNodeWithData(node, formData) {
    const nodeData = node.getData();
    
    // 从 formData 中提取 node_name 作为 label
    const nodeName = formData.node_name || nodeData.label;
    delete formData.node_name; // 从 params 中移除 node_name
    
    // 更新节点数据
    const updatedData = {
        ...nodeData,
        label: nodeName,
        params: formData,
    };
    
    // 更新节点的 data
    node.setData(updatedData);
    
    // 更新节点的显示内容（需要重新渲染节点）
    // 注意：X6 的 HTML 节点需要手动更新内容
    if (nodeData.type === 'Streamer') {
        // 对于 Streamer 类型，需要更新 HTML 内容
        const htmlElement = node.view?.container;
        if (htmlElement) {
            const titleElement = htmlElement.querySelector('.title');
            const extraElement = htmlElement.querySelector('._url');
            if (titleElement) titleElement.textContent = nodeName;
            if (extraElement && formData.stream) {
                extraElement.textContent = formData.stream;
                extraElement.setAttribute('title', formData.stream);
            }
        }
    }
    saveWorkFlow()
    // console.log('节点更新成功:', node, updatedData);
    return node;
}

// 收集表单数据
function collectFormData() {
    const formContainer = document.getElementById('form-container');
    const formData = {};
    
    // 获取所有表单字段
    const inputs = formContainer.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        const fieldName = input.getAttribute('data-field-name');
        const fieldType = input.getAttribute('data-field-type');
        const isRequired = input.getAttribute('data-required') === 'true';
        
        if (!fieldName) return;
        
        let value = input.value;
        
        // 类型转换
        if (fieldType === 'number') {
            value = value ? Number(value) : null;
        } else if (fieldType === 'select') {
            // 如果是 "--Please Select--" 则设为 null
            value = (value && value !== '--Please Select--') ? value : null;
        } else if (value === '') {
            value = null;
        }
        
        formData[fieldName] = value;
    });
    
    return formData;
}

// 渲染表单（getNodeParams只返回task_type一个字段）
function renderForm(taskTypeField, initialData = null, nodeType = null) {
    const formContainer = document.getElementById('form-container');
    formContainer.innerHTML = '';
    
    // 首先添加节点名称输入框（必填项）
    const nameFieldDiv = document.createElement('div');
    nameFieldDiv.className = 'form-field';
    
    const nameLabel = document.createElement('label');
    const nameLabelText = document.createElement('span');
    nameLabelText.textContent = 'Node name';
    nameLabel.appendChild(nameLabelText);
    
    const nameRequired = document.createElement('span');
    nameRequired.className = 'required-mark';
    nameRequired.textContent = ' *';
    nameLabel.appendChild(nameRequired);
    
    nameFieldDiv.appendChild(nameLabel);
    
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.placeholder = 'Enter node name';
    nameInput.setAttribute('data-field-name', 'node_name');
    nameInput.setAttribute('data-field-type', 'text');
    nameInput.setAttribute('data-required', 'true');
    
    // 填充节点名称：优先使用 label，其次使用 node_name
    if (initialData) {
        nameInput.value = initialData.label || (initialData.params && initialData.params.node_name) || '';
    }
    
    nameFieldDiv.appendChild(nameInput);
    
    // 添加验证提示文本
    const nameHint = document.createElement('div');
    nameHint.className = 'name-validation-hint';
    nameFieldDiv.appendChild(nameHint);
    
    // 防抖定时器
    let nameCheckTimeout = null;
    
    // 监听输入变化，调用 checkName 接口
    nameInput.addEventListener('input', (e) => {
        const name = e.target.value.trim();
        
        // 清除之前的定时器
        if (nameCheckTimeout) {
            clearTimeout(nameCheckTimeout);
        }
        
        // 清除验证状态
        nameInput.classList.remove('error', 'success');
        nameHint.textContent = '';
        nameHint.className = 'name-validation-hint';
        
        if (!name) {
            return;
        }
        
        // 显示检查中状态
        nameHint.textContent = 'Checking...';
        nameHint.className = 'name-validation-hint checking';
        
        // 防抖：500ms 后才调用接口
        nameCheckTimeout = setTimeout(() => {
            API.checkName({ name: name })
                .then(res => {
                    if (res.data && res.data.valid !== undefined) {
                        if (res.data.valid) {
                            // 名称可用
                            nameInput.classList.remove('error');
                            nameInput.classList.add('success');
                            nameHint.textContent = res.data.message || 'Name available';
                            nameHint.className = 'name-validation-hint success';
                        } else {
                            // 名称重复
                            nameInput.classList.remove('success');
                            nameInput.classList.add('error');
                            nameHint.textContent = res.data.message || 'Name already exists';
                            nameHint.className = 'name-validation-hint error';
                        }
                    }
                })
                .catch(err => {
                    console.error('检查名称失败:', err);
                    nameHint.textContent = 'Check failed';
                    nameHint.className = 'name-validation-hint error';
                });
        }, 500);
    });
    
    formContainer.appendChild(nameFieldDiv);
    
    // 添加分割线
    const divider = document.createElement('div');
    divider.className = 'form-divider';
    formContainer.appendChild(divider);
    
    // 添加参数列表标题
    const paramTitle = document.createElement('div');
    paramTitle.className = 'param-title';
    paramTitle.textContent = 'Parameter list';
    formContainer.appendChild(paramTitle);
    
    if (!taskTypeField) {
        const emptyMsg = document.createElement('p');
        emptyMsg.className = 'empty-message';
        emptyMsg.textContent = 'No configuration items';
        formContainer.appendChild(emptyMsg);
        return;
    }
    
    // 渲染 task_type 字段
    const fieldDiv = document.createElement('div');
    fieldDiv.className = 'form-field';
    
    // 创建标签 - 使用 name 而不是 description
    const label = document.createElement('label');
    const labelText = document.createElement('span');
    labelText.textContent = taskTypeField.name || 'task_type';
    label.appendChild(labelText);
    
    if (taskTypeField.required) {
        const required = document.createElement('span');
        required.className = 'required-mark';
        required.textContent = ' *';
        label.appendChild(required);
    }
    
    // 添加描述提示问号图标
    if (taskTypeField.description) {
        const tooltip = document.createElement('span');
        tooltip.className = 'description-tooltip';
        tooltip.title = taskTypeField.description;
        tooltip.textContent = '?';
        tooltip.style.cssText = 'margin-left: 5px; cursor: help; color: rgb(102, 102, 102); font-weight: normal; font-size: 10px; display: inline-block; width: 12px; height: 12px; border-radius: 50%; background-color: rgb(248, 248, 248); text-align: center; line-height: 12px; border: 1px solid rgb(221, 221, 221); transition: 0.2s;';
        label.appendChild(tooltip);
    }
    
    fieldDiv.appendChild(label);
    
    // 创建下拉选择框
    const select = document.createElement('select');
    
    // 添加选项
    if (taskTypeField.options && taskTypeField.options.length > 0) {
        taskTypeField.options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option;
            opt.textContent = option;
            select.appendChild(opt);
        });
    }
    
    // 设置默认值或初始数据
    if (initialData && initialData.params && initialData.params.task_type) {
        // 优先使用节点数据中的 task_type
        select.value = initialData.params.task_type;
        // 记录当前的 task_type
        select.setAttribute('data-current-task-type', initialData.params.task_type);
    } else if (taskTypeField.default_value !== null && taskTypeField.default_value !== undefined && taskTypeField.default_value !== '--Please Select--') {
        // 其次使用字段配置的默认值（如果不是占位符）
        select.value = taskTypeField.default_value;
        select.setAttribute('data-current-task-type', taskTypeField.default_value);
    } else {
        // 没有值时，默认选中 "--Please Select--"
        select.value = '--Please Select--';
    }
    
    // 监听变化事件，加载对应的任务参数
    select.addEventListener('change', (e) => {
        const selectedTaskType = e.target.value;
        if (selectedTaskType && selectedTaskType !== '--Please Select--') {
            // 在切换之前，先保存当前表单数据到缓存
            const currentTaskType = select.getAttribute('data-current-task-type');
            if (currentTaskType && currentTaskType !== '--Please Select--') {
                // 收集当前 task_type 的参数
                const currentParams = {};
                const taskParamInputs = formContainer.querySelectorAll('.task-param-field input, .task-param-field select, .task-param-field textarea');
                taskParamInputs.forEach(input => {
                    const fieldName = input.getAttribute('data-field-name');
                    if (fieldName) {
                        currentParams[fieldName] = input.value;
                    }
                });
                taskParamsCache[currentTaskType] = currentParams;
            }
            
            // 记录当前选中的 task_type
            select.setAttribute('data-current-task-type', selectedTaskType);
            
            // 加载新的 task_type 参数，优先从缓存中恢复
            const cachedParams = taskParamsCache[selectedTaskType];
            loadTaskParams(nodeType, selectedTaskType, cachedParams);
        }
    });
    
    // 设置字段属性
    select.setAttribute('data-field-name', taskTypeField.name || 'task_type');
    select.setAttribute('data-field-type', 'select');
    select.setAttribute('data-required', taskTypeField.required ? 'true' : 'false');
    
    fieldDiv.appendChild(select);
    formContainer.appendChild(fieldDiv);
}

// 加载任务参数（当 task_type 变化时调用）
function loadTaskParams(nodeType, taskType, initialParams = null) {
    const formContainer = document.getElementById('form-container');
    
    // 显示加载状态（在 task_type 后面添加）
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'task-params-loading';
    loadingDiv.className = 'loading-message';
    loadingDiv.textContent = 'Loading task parameters...';
    
    // 移除旧的 task params
    const oldTaskParams = formContainer.querySelectorAll('.task-param-field');
    oldTaskParams.forEach(el => el.remove());
    const oldLoading = document.getElementById('task-params-loading');
    if (oldLoading) oldLoading.remove();
    
    formContainer.appendChild(loadingDiv);
    
    API.getTaskParams(nodeType, taskType)
        .then(res => {
            loadingDiv.remove();
            
            if (res.data && res.data.status === 'success' && res.data.data) {
                const taskFields = res.data.data;
                
                // 渲染任务参数字段
                taskFields.forEach(field => {
                    const fieldDiv = document.createElement('div');
                    fieldDiv.className = 'form-field task-param-field';
                    
                    // 记录字段类型（如果存在 select_value_type）
                    if (field.select_value_type) {
                        fieldTypesMap[field.name] = field.select_value_type;
                    }
                    
                    // 创建标签
                    const label = document.createElement('label');
                    const labelText = document.createElement('span');
                    labelText.textContent = field.name;
                    label.appendChild(labelText);
                    
                    if (field.required) {
                        const required = document.createElement('span');
                        required.className = 'required-mark';
                        required.textContent = ' *';
                        label.appendChild(required);
                    }
                    
                    // 添加描述提示问号图标
                    if (field.description) {
                        const tooltip = document.createElement('span');
                        tooltip.className = 'description-tooltip';
                        tooltip.title = field.description;
                        tooltip.textContent = '?';
                        tooltip.style.cssText = 'margin-left: 5px; cursor: help; color: rgb(102, 102, 102); font-weight: normal; font-size: 10px; display: inline-block; width: 12px; height: 12px; border-radius: 50%; background-color: rgb(248, 248, 248); text-align: center; line-height: 12px; border: 1px solid rgb(221, 221, 221); transition: 0.2s;';
                        label.appendChild(tooltip);
                    }
                    
                    fieldDiv.appendChild(label);
                    
                    // 创建输入控件
                    let input;
                    
                    if (field.type === 'select') {
                        input = document.createElement('select');
                        
                        // 添加 "--Please Select--" 选项
                        const defaultOption = document.createElement('option');
                        defaultOption.value = '--Please Select--';
                        defaultOption.textContent = '--Please Select--';
                        input.appendChild(defaultOption);
                        
                        if (field.options && field.options.length > 0) {
                            field.options.forEach(option => {
                                const opt = document.createElement('option');
                                opt.value = option;
                                opt.textContent = option;
                                input.appendChild(opt);
                            });
                        }
                        
                        // 填充值：优先使用 initialParams，其次使用默认值
                        if (initialParams && initialParams[field.name] !== undefined && initialParams[field.name] !== null) {
                            input.value = initialParams[field.name];
                        } else if (field.default_value !== null && field.default_value !== undefined && field.default_value !== '--Please Select--') {
                            input.value = field.default_value;
                        } else {
                            // 没有值时，默认选中 "--Please Select--"
                            input.value = '--Please Select--';
                        }
                        
                    } else if (field.type === 'number') {
                        input = document.createElement('input');
                        input.type = 'number';
                        input.value = field.default_value;
                        
                        // 填充值：优先使用 initialParams
                        if (initialParams && initialParams[field.name] !== undefined && initialParams[field.name] !== null) {
                            input.value = initialParams[field.name];
                        }
                        
                    } else if (field.type === 'file') {
                        const fileWrapper = document.createElement('div');
                        fileWrapper.className = 'file-input-wrapper';
                        
                        input = document.createElement('input');
                        input.type = 'text';
                        input.placeholder = field.default_value  || '';
                        
                        // 填充值：优先使用 initialParams
                        if (initialParams && initialParams[field.name]) {
                            input.value = initialParams[field.name];
                        }
                        
                        const browseBtn = document.createElement('button');
                        browseBtn.className = 'browse-btn';
                        browseBtn.textContent = 'Browse...';
                        browseBtn.type = 'button';
                        browseBtn.onclick = () => {
                            // 根据节点类型决定调用哪个 API
                            openFileSelectModal(nodeType, input);
                        };
                        
                        fileWrapper.appendChild(input);
                        fileWrapper.appendChild(browseBtn);
                        fieldDiv.appendChild(fileWrapper);
                        
                    } else {
                        input = document.createElement('input');
                        input.type = 'text';
                        input.value = field.default_value || '';
                        
                        // 填充值：优先使用 initialParams
                        if (initialParams && initialParams[field.name]) {
                            input.value = initialParams[field.name];
                        }
                    }
                    
                    if (input) {
                        input.setAttribute('data-field-name', field.name);
                        input.setAttribute('data-field-type', field.type);
                        input.setAttribute('data-required', field.required ? 'true' : 'false');
                        
                        if (field.type !== 'file') {
                            fieldDiv.appendChild(input);
                        }
                    }
                    
                    formContainer.appendChild(fieldDiv);
                });
            }
        })
        .catch(err => {
            console.error('获取任务参数失败:', err);
            loadingDiv.className = 'error-message';
            loadingDiv.textContent = 'Failed to load task parameters';
        });
}

// 文件选择弹框相关变量
let currentFileInputTarget = null; // 当前需要填充的 input 元素

// 打开文件选择弹框
function openFileSelectModal(nodeType, inputElement) {
    currentFileInputTarget = inputElement;
    
    const modal = document.getElementById('file-select-modal');
    const overlay = document.getElementById('file-select-modal-overlay');
    const fileList = document.getElementById('file-list');
    
    // 显示弹框
    modal.classList.add('show');
    overlay.classList.add('show');
    
    // 显示加载状态
    fileList.innerHTML = '<div class="file-list-loading">Loading file list...</div>';
    
    // 根据节点类型调用不同的 API
    let apiCall;
    if (nodeType === 'Algorithm') {
        apiCall = API.getModelFiles();
    } else if (nodeType === 'Streamer') {
        apiCall = API.getVideoFiles();
    } else {
        // 默认使用模型文件
        apiCall = API.getModelFiles();
    }
    
    apiCall
        .then(res => {
            if (res.data && res.data.status === 'success' && res.data.data) {
                const files = res.data.data;
                
                if (files.length === 0) {
                    fileList.innerHTML = '<div class="file-list-empty">No files</div>';
                    return;
                }
                
                // 渲染文件列表
                fileList.innerHTML = '';
                files.forEach(filePath => {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item';
                    fileItem.textContent = filePath;
                    fileItem.onclick = () => selectFile(filePath);
                    fileList.appendChild(fileItem);
                });
            } else {
                fileList.innerHTML = '<div class="file-list-error">Failed to load file list</div>';
            }
        })
        .catch(err => {
            console.error('获取文件列表失败:', err);
            fileList.innerHTML = '<div class="file-list-error">Failed to load file list: ' + (err.message || 'Network error') + '</div>';
        });
}

// 选择文件
function selectFile(filePath) {
    if (currentFileInputTarget) {
        // 将选中的文件路径填入 input
        currentFileInputTarget.value = filePath;
    }
    
    // 关闭弹框
    closeFileSelectModal();
}

// 关闭文件选择弹框
function closeFileSelectModal() {
    const modal = document.getElementById('file-select-modal');
    const overlay = document.getElementById('file-select-modal-overlay');
    
    modal.classList.remove('show');
    overlay.classList.remove('show');
    
    // 清空状态
    currentFileInputTarget = null;
}