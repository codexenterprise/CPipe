// Log page: tail the current CPipe log file, load older lines when scrolling up
const LogPage = {
    POLL_MS: 1000,
    start: 0,
    end: 0,
    loading: false,
    stick: true,
    empty: true,

    $(id) { return document.getElementById(id); },

    // Poll after the previous request finished, so the requests never pile up
    poll(fn, ms = this.POLL_MS) {
        const loop = () => fn().catch(() => {}).finally(() => setTimeout(loop, ms));
        loop();
    },

    async get(query) {
        const data = await fetch(`/api/logs${query}`, { cache: 'no-store' }).then(r => r.json());
        if (data.name) this.$('log-name').textContent = data.name;
        return data;
    },

    escape(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    },

    // Map CLogger ANSI colors: debug 32, info 36, warning 33, error 91, report 35
    color(line) {
        return this.escape(line)
            .replace(/\x1b\[32m/g, '<span class="log-debug">')
            .replace(/\x1b\[36m/g, '<span class="log-info">')
            .replace(/\x1b\[33m/g, '<span class="log-warning">')
            .replace(/\x1b\[91m/g, '<span class="log-error">')
            .replace(/\x1b\[35m/g, '<span class="log-report">')
            .replace(/\x1b\[[0-9;]*m/g, '</span>');
    },

    html(lines) {
        return lines.map(l => this.color(l)).join('\n');
    },

    render(lines, mode) {
        const view = this.$('log-view');
        const html = this.html(lines);
        if (mode === 'init') {
            this.empty = !html;
            if (html) view.innerHTML = html;
            else view.textContent = I18N.t('暂无日志');
            view.scrollTop = view.scrollHeight;
            this.stick = true;
            return;
        }
        if (!html) return;
        if (this.empty) {
            view.innerHTML = html;
            this.empty = false;
            if (this.stick) view.scrollTop = view.scrollHeight;
            return;
        }
        if (mode === 'older') {
            const prev = view.scrollHeight;
            view.innerHTML = `${html}\n${view.innerHTML}`;
            view.scrollTop = view.scrollHeight - prev;
            return;
        }
        view.innerHTML += `\n${html}`;
        if (this.stick) view.scrollTop = view.scrollHeight;
    },

    async initLoad() {
        const data = await this.get('?n=500');
        this.start = data.start;
        this.end = data.end;
        this.render(data.lines, 'init');
    },

    async older() {
        if (this.loading || this.start <= 0) return;
        this.loading = true;
        try {
            const data = await this.get(`?before=${this.start}&n=1000`);
            this.start = data.start;
            this.render(data.lines, 'older');
        } finally {
            this.loading = false;
        }
    },

    async newer() {
        if (this.loading) return;
        this.loading = true;
        try {
            const data = await this.get(`?after=${this.end}`);
            if (data.size < this.end) {
                await this.initLoad();
                return;
            }
            this.end = data.end;
            this.render(data.lines, 'newer');
        } finally {
            this.loading = false;
        }
    },

    bind() {
        const view = this.$('log-view');
        view.onscroll = () => {
            this.stick = view.scrollHeight - view.scrollTop - view.clientHeight < 40;
            if (view.scrollTop < 40) this.older();
        };
    },

    init() {
        I18N.apply();
        this.bind();
        this.loading = true;
        this.initLoad().catch(() => {}).finally(() => { this.loading = false; });
        this.poll(() => this.newer());
    },
};

LogPage.init();
