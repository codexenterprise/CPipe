// Lightweight UI components shared by the pages without compiling: toast / confirm / modal, needs common/i18n.js
const UI = {
    okCancel() {
        return `<button class="ui-btn" data-act="cancel">${I18N.t('取消')}</button><button class="ui-btn ui-btn-primary" data-act="ok">${I18N.t('确定')}</button>`;
    },

    toast(message, type = 'info', duration = 2500) {
        let box = document.getElementById('ui-toast-box');
        if (!box) {
            box = document.createElement('div');
            box.id = 'ui-toast-box';
            document.body.appendChild(box);
        }
        const item = document.createElement('div');
        item.className = `ui-toast ui-toast-${type}`;
        item.textContent = message;
        box.appendChild(item);
        setTimeout(() => item.remove(), duration);
    },

    confirm(message, title = I18N.t('提示')) {
        return new Promise(resolve => {
            const modal = UI.modal(`<p class="ui-confirm-text"></p>`, {
                title,
                footer: UI.okCancel(),
                onClose: () => resolve(false),
            });
            modal.body.querySelector('.ui-confirm-text').textContent = message;
            modal.footer.querySelector('[data-act=cancel]').onclick = () => modal.close();
            modal.footer.querySelector('[data-act=ok]').onclick = () => { modal.close(false); resolve(true); };
        });
    },

    // validate(value) returns an error message, or '' when the value is valid
    prompt(message, validate = () => '', title = I18N.t('提示')) {
        return new Promise(resolve => {
            const modal = UI.modal(`<p class="ui-confirm-text"></p><input class="ui-input" autofocus><p class="ui-prompt-error"></p>`, {
                title,
                footer: UI.okCancel(),
                onClose: () => resolve(null),
            });
            const input = modal.body.querySelector('input');
            const ok = () => {
                const error = validate(input.value);
                modal.body.querySelector('.ui-prompt-error').textContent = error;
                if (!error) { modal.close(false); resolve(input.value); }
            };
            modal.body.querySelector('.ui-confirm-text').textContent = message;
            input.onkeydown = e => { if (e.key === 'Enter') ok(); };
            modal.footer.querySelector('[data-act=cancel]').onclick = () => modal.close();
            modal.footer.querySelector('[data-act=ok]').onclick = ok;
            input.focus();
        });
    },

    // Date time picker following I18N (the native one follows the browser language), the input value is 'YYYY-MM-DD HH:mm'
    datetime(input) {
        const pad = n => String(n).padStart(2, '0');
        const options = n => Array.from({ length: n }, (_, i) => `<option>${pad(i)}</option>`).join('');
        input.readOnly = true;
        input.onclick = () => {
            document.querySelector('.ui-dt')?.remove();
            const init = input.value ? new Date(input.value.replace(' ', 'T')) : new Date();
            let year = init.getFullYear(), month = init.getMonth(), picked = input.value ? init : null;
            const box = document.createElement('div');
            box.className = 'ui-dt';
            const rect = input.getBoundingClientRect();
            box.style.left = `${rect.left}px`;
            box.style.top = `${rect.bottom + 4}px`;
            box.innerHTML = `
                <div class="ui-dt-head"><span data-m="-1">‹</span><b></b><span data-m="1">›</span></div>
                <div class="ui-dt-days"></div>
                <div class="ui-dt-foot">
                    <select>${options(24)}</select>:<select>${options(60)}</select>
                    <button class="ui-btn ui-btn-small" data-act="clear">${I18N.t('清除')}</button>
                    <button class="ui-btn ui-btn-small ui-btn-primary" data-act="ok">${I18N.t('确定')}</button>
                </div>`;
            const [hour, minute] = box.querySelectorAll('select');
            hour.value = pad(init.getHours());
            minute.value = pad(init.getMinutes());
            const same = (a, b) => a && a.toDateString() === b.toDateString();
            const render = () => {
                box.querySelector('b').textContent = `${year}-${pad(month + 1)}`;
                const blanks = new Date(year, month, 1).getDay();
                const days = new Date(year, month + 1, 0).getDate();
                box.querySelector('.ui-dt-days').innerHTML = I18N.t('日,一,二,三,四,五,六').split(',').map(w => `<i>${w}</i>`).join('')
                    + '<span></span>'.repeat(blanks)
                    + Array.from({ length: days }, (_, i) => {
                        const day = new Date(year, month, i + 1);
                        return `<span class="${same(picked, day) ? 'is-picked' : ''} ${same(new Date(), day) ? 'is-today' : ''}" data-d="${i + 1}">${i + 1}</span>`;
                    }).join('');
            };
            const close = () => {
                box.remove();
                document.removeEventListener('mousedown', outside);
            };
            const outside = e => { if (!box.contains(e.target) && e.target !== input) close(); };
            box.onclick = e => {
                const { m, d, act } = e.target.dataset;
                if (m) {
                    month += +m;
                    year += Math.floor(month / 12);
                    month = (month + 12) % 12;
                } else if (d) {
                    picked = new Date(year, month, +d);
                } else if (act === 'clear') {
                    input.value = '';
                    return close();
                } else if (act === 'ok') {
                    const day = picked || new Date();
                    input.value = `${day.getFullYear()}-${pad(day.getMonth() + 1)}-${pad(day.getDate())} ${hour.value}:${minute.value}`;
                    return close();
                }
                render();
            };
            render();
            document.body.appendChild(box);
            document.addEventListener('mousedown', outside);
        };
    },

    // Returns {el, body, footer, close(notify=true)}
    modal(bodyHtml, { title = '', footer = '', width = '520px', onClose = null } = {}) {
        const el = document.createElement('div');
        el.className = 'ui-modal-mask';
        el.innerHTML = `
            <div class="ui-modal" style="width:${width}">
                <div class="ui-modal-header"><span class="ui-modal-title"></span><span class="ui-modal-close">×</span></div>
                <div class="ui-modal-body">${bodyHtml}</div>
                ${footer ? `<div class="ui-modal-footer">${footer}</div>` : ''}
            </div>`;
        el.querySelector('.ui-modal-title').textContent = title;
        document.body.appendChild(el);
        const close = (notify = true) => {
            el.remove();
            if (notify && onClose) onClose();
        };
        el.querySelector('.ui-modal-close').onclick = () => close();
        el.onclick = e => { if (e.target === el) close(); };
        return { el, body: el.querySelector('.ui-modal-body'), footer: el.querySelector('.ui-modal-footer'), close };
    },

    escape(text) {
        const div = document.createElement('div');
        div.textContent = text ?? '';
        return div.innerHTML;
    },
};
