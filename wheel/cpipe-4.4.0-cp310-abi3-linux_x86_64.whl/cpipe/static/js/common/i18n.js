// Chinese / English switch: the Chinese text is the key, elements marked by data-i18n / data-i18n-placeholder / data-i18n-title are translated
const I18N = {
    lang: localStorage.getItem('cpipe_lang') === 'en' ? 'en' : 'zh',
    EN: {
        '首页': 'Home', '工作流': 'Workflow', '直播': 'Live', '消息': 'Messages', '等待消息...': 'Waiting for messages...', '更新于': 'Updated', '报警': 'Alarms', '日志': 'Logs', '暂无日志': 'No logs', '重启服务': 'Restart', '授权': 'License',
        '未启用报警功能': 'Alarm is not enabled',
        '节点类型': 'Node Type', '整理布局': 'Arrange Layout', '播放': 'Play',
        '摄像头列表': 'Cameras', '新增摄像头': 'Add camera', '清空': 'Clear', '保存': 'Save',
        '选择已有标注': 'Select annotation', '新建多边形': 'New polygon', '新建直线': 'New line', '删除选中标注': 'Delete selected annotation',
        '当前节点不支持该标定': 'This node does not support this annotation',
        '多边形标定': 'Polygons', '直线标定': 'Lines', '新增': 'Add', '编辑': 'Edit', '删除': 'Delete', '更多': 'More',
        '请选择摄像头和算法': 'Select a camera and an algorithm', '暂无摄像头': 'No camera',
        '提示': 'Notice', '取消': 'Cancel', '确定': 'OK', '复制': 'Copy', '复制成功': 'Copied', '加载中...': 'Loading...',
        '网络服务出错啦！': 'Network error!', '请输入名称': 'Please enter a name', '名称不能为空': 'The name is required',
        '名称不能重复': 'The name already exists', '是否确认删除': 'Confirm to delete?', '删除成功': 'Deleted',
        '保存成功': 'Saved', '存在必须标定项未标定': 'Some required items are not calibrated',
        '当前已经标定,是否覆盖': 'Already calibrated, overwrite it?',
        '当前存在修改标定,请选择是否提交?': 'There are unsaved changes, save them?',
        '确定要重启服务吗?': 'Restart the service?', '重启成功': 'Restarted', '设备信息': 'Device info',
        '算法选择': 'Algorithms', '节点名称': 'Node name', '请输入节点名称': 'Please enter the node name', '视频流地址': 'Stream URLs',
        '请选择算法': 'Please select the algorithms', '请填写视频流地址': 'Please enter the stream URLs',
        '修改成功': 'Modified', '添加成功': 'Added',
        '自动刷新': 'Auto refresh', '刷新': 'Refresh', '时间': 'Time', '今天': 'Today', '近7天': 'Last 7 days', '近30天': 'Last 30 days',
        '摄像头': 'Camera', '报警名称': 'Alarm name', '类型': 'Type', '关键字': 'Keyword',
        '报警名称 / 报警内容': 'Alarm name / text', '排序': 'Order', '时间倒序': 'Newest first', '时间正序': 'Oldest first',
        '查询': 'Search', '重置': 'Reset', '删除选中': 'Delete selected', '缩略图': 'Thumbnail', '报警内容': 'Alarm text',
        '全部': 'All', '文字': 'Text', '图片': 'Image', '视频': 'Video', '生成中': 'Generating', '失败': 'Failed', '无': 'None',
        '暂无报警': 'No alarms', '上一页': 'Prev', '下一页': 'Next', '条/页': '/ page', '共 {n} 条': 'Total {n}',
        '来源节点': 'Source node', '目标ID': 'Target IDs', '扩展信息': 'Extra', '报警ID': 'Alarm ID', '文件ID': 'File ID',
        '下载图片': 'Download image', '下载视频': 'Download video', '请先选择报警': 'Please select the alarms first',
        '确定删除选中的 {n} 条报警及其图片、视频吗?': 'Delete the {n} selected alarms with their images and videos?',
        '已删除 {n} 条': '{n} deleted', '开始时间': 'Start time', '结束时间': 'End time', '清除': 'Clear',
        '日,一,二,三,四,五,六': 'Su,Mo,Tu,We,Th,Fr,Sa',
    },

    t(text, params = {}) {
        const result = this.lang === 'en' ? this.EN[text] ?? text : text;
        return result.replace(/\{(\w+)\}/g, (_, k) => params[k] ?? '');
    },

    apply(root = document) {
        document.documentElement.lang = this.lang === 'en' ? 'en' : 'zh-CN';
        root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = this.t(el.dataset.i18n); });
        root.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.placeholder = this.t(el.dataset.i18nPlaceholder); });
        root.querySelectorAll('[data-i18n-title]').forEach(el => { el.title = this.t(el.dataset.i18nTitle); });
        const btn = document.getElementById('btn-lang');
        if (btn) btn.textContent = this.lang === 'en' ? '中文' : 'EN';
    },

    // The pages render the dynamic text by t(), so reload to switch all of them
    toggle() {
        localStorage.setItem('cpipe_lang', this.lang === 'en' ? 'zh' : 'en');
        location.reload();
    },
};
