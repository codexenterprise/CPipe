// Configuration
const CONFIG = {
    // API Base URL
    apiBaseUrl: window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
        ? 'http://127.0.0.1:9966'
        : '',

    // Node Types
    nodeTypes: [
        { type: 'Streamer', color: 'linear-gradient(135deg, #2ecc71, #a2e2d5)' },
        { type: 'Algorithm', color: 'linear-gradient(135deg, #3498db, #a5e9db)' },
        { type: 'Logic', color: 'linear-gradient(135deg, #e67e22, #dde7bd)' },
        { type: 'Report', color: 'linear-gradient(135deg, #FF69B4, #ddc6b6)' },
        { type: 'Insight', color: 'linear-gradient(135deg, #9b59b6, #c7b3c7)' }
    ],
    
    // Edge Colors
    edgeColors: {
        Streamer: '#2ecc71',
        Algorithm: '#3498db',
        Logic: '#e67e22',
        Report: '#FF69B4',
        Insight: '#9b59b6'
    },

    edgeFont:{
        "Streamer": "#1e7e34",
        "Algorithm": "#19608f",
        "Logic": "#934d10",
        "Report": "#e00070",
        "Insight": "#623388"
    }
};
