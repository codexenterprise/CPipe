// Insight page of one node: live image stream, video play control (only for the video file streamer) and debug messages
const Player = {
    POLL_MS: 100,
    node: encodeURIComponent(document.body.dataset.node || ''),
    name: document.body.dataset.node || '',
    paused: true,
    duration: 0,
    dragging: false,
    lastText: null,
    lastNames: '',

    $(id) { return document.getElementById(id); },

    setLive(on) { this.$('live').classList.toggle('is-on', !!on); },

    format(seconds) {
        return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
    },

    // Poll after the previous request finished, so the requests never pile up
    poll(fn, ms = this.POLL_MS) {
        const loop = () => fn().catch(() => {}).finally(() => setTimeout(loop, ms));
        loop();
    },

    play(query = '') {
        if (!this.node) return Promise.resolve();
        return fetch(`/play/${this.node}${query}`).then(r => r.json()).then(data => this.setData(data));
    },

    // data: {support, video_duration, play_progress, pause(-1: paused, -2: playing), fps}
    setData(data) {
        this.$('controls').classList.toggle('show', !!data.support);
        if (!data.support) return;
        if (data.video_duration !== undefined) this.duration = data.video_duration;
        if (data.play_progress !== undefined && !this.dragging) this.setProgress(data.play_progress);
        if (data.pause !== undefined) {
            this.paused = data.pause === -1;
            this.$('icon-play').style.display = this.paused ? '' : 'none';
            this.$('icon-pause').style.display = this.paused ? 'none' : '';
        }
    },

    setProgress(seconds) {
        const percent = this.duration > 0 ? Math.min(seconds / this.duration, 1) * 100 : 0;
        this.$('bar').style.width = this.$('handle').style.left = `${percent}%`;
        this.$('time').textContent = `${this.format(seconds)} / ${this.format(this.duration)}`;
    },

    seekAt(clientX) {
        const rect = this.$('progress').getBoundingClientRect();
        return Math.max(0, Math.min((clientX - rect.left) / rect.width, 1)) * this.duration;
    },

    fetchMessage() {
        if (!this.node) return Promise.resolve();
        return fetch(`/debug_message/${this.node}`).then(r => r.json()).then(({ text }) => {
            if (!text || text === this.lastText) return;
            this.lastText = text;
            this.$('message').textContent = text;
            this.$('updated').textContent = `${I18N.t('更新于')} ${new Date().toLocaleTimeString()}`;
        });
    },

    setNode(name) {
        this.name = name;
        this.node = encodeURIComponent(name);
        this.lastText = null;
        this.$('video-stream').src = `/show/${this.node}`;
    },

    fetchStreamers() {
        return fetch('/connect').then(r => r.json()).then(data => {
            const info = data.streamer_info || {};
            const names = Object.keys(info);
            const key = names.join('\0');
            if (key !== this.lastNames) {
                this.lastNames = key;
                if (!this.name && names[0]) this.setNode(names[0]);
                this.$('node-select').replaceChildren(...names.map(n => {
                    const o = document.createElement('option');
                    o.value = n;
                    o.textContent = n;
                    o.selected = n === this.name;
                    return o;
                }));
            }
            this.setLive(!!this.name && info[this.name]?.state === 'alive');
        }).catch(() => this.setLive(false));
    },

    bind() {
        this.$('node-select').onchange = e => this.setNode(e.target.value);
        this.$('btn-play').onclick = () => this.play(`?pause=${this.paused ? -2 : -1}`);
        this.$('progress').onclick = e => this.play(`?time_seconds=${this.seekAt(e.clientX)}`);
        this.$('handle').onmousedown = e => {
            e.preventDefault();
            e.stopPropagation();
            this.dragging = true;
        };
        document.addEventListener('mousemove', e => { if (this.dragging) this.setProgress(this.seekAt(e.clientX)); });
        document.addEventListener('mouseup', e => {
            if (!this.dragging) return;
            this.dragging = false;
            this.play(`?time_seconds=${this.seekAt(e.clientX)}`);
        });
    },

    init() {
        I18N.apply();
        this.bind();
        this.poll(() => this.play());
        this.poll(() => this.fetchMessage());
        this.poll(() => this.fetchStreamers(), 1000);
    },
};

Player.init();
