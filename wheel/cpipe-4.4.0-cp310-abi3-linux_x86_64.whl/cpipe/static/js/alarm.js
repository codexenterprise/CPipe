// Alarm record page: query / search / sort / pagination / detail / delete / auto refresh
const AlarmPage = {
    FILTERS: ['streamer_name', 'alarm_name', 'alarm_type', 'keyword', 'order'],
    TYPE_NAMES: { text: I18N.t('文字'), image: I18N.t('图片'), video: I18N.t('视频') },
    STATUS_NAMES: { pending: I18N.t('生成中'), writing: I18N.t('生成中'), failed: I18N.t('失败'), skipped: I18N.t('无') },
    REFRESH_MS: 5000,

    state: { page: 1, page_size: 20, total: 0, items: [], lastTopId: null },

    $(id) {
        return document.getElementById(id);
    },

    toLocalInput(ts) {
        const d = new Date(ts * 1000);
        d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
        return d.toISOString().slice(0, 16).replace('T', ' ');
    },

    fromLocalInput(value) {
        return value ? new Date(value.replace(' ', 'T')).getTime() / 1000 : '';
    },

    // Read the query conditions from the url, so refreshing the page keeps them
    loadFromUrl() {
        const params = new URLSearchParams(location.search);
        this.FILTERS.forEach(k => { if (params.has(k)) this.$(`f-${k}`).value = params.get(k); });
        if (params.get('start_time')) this.$('f-start').value = this.toLocalInput(+params.get('start_time'));
        if (params.get('end_time')) this.$('f-end').value = this.toLocalInput(+params.get('end_time'));
        this.state.page = +params.get('page') || 1;
        this.state.page_size = +params.get('page_size') || 20;
        this.$('pager-size').value = this.state.page_size;
    },

    params() {
        const p = { page: this.state.page, page_size: this.state.page_size,
                    start_time: this.fromLocalInput(this.$('f-start').value), end_time: this.fromLocalInput(this.$('f-end').value) };
        this.FILTERS.forEach(k => { p[k] = this.$(`f-${k}`).value.trim(); });
        Object.keys(p).forEach(k => { if (p[k] === '') delete p[k]; });
        return p;
    },

    disabled(message) {
        if (message !== 'AlarmReport node not found') return false;
        this.$('alarm-body').innerHTML = `<tr><td colspan="7" class="alarm-empty">${I18N.t('未启用报警功能')}</td></tr>`;
        return true;
    },

    async loadOptions() {
        const { data } = await axios.get('/api/alarms/options');
        if (data.code !== 1) return this.disabled(data.message) || UI.toast(data.message, 'error');
        ['streamer_name', 'alarm_name'].forEach(k => {
            const select = this.$(`f-${k}`);
            const current = select.value;
            select.innerHTML = `<option value="">${I18N.t('全部')}</option>` + data[k].map(v => `<option>${UI.escape(v)}</option>`).join('');
            select.value = current;
        });
    },

    async query(silent = false) {
        const params = this.params();
        history.replaceState(null, '', `?${new URLSearchParams(params)}`);
        const { data } = await axios.get('/api/alarms', { params });
        if (data.code !== 1) return this.disabled(data.message) || silent || UI.toast(data.message, 'error');
        const newIds = silent && this.state.lastTopId ? this.newIds(data.items) : new Set();
        Object.assign(this.state, { total: data.total, items: data.items, lastTopId: data.items[0]?.alarm_id });
        this.render(newIds);
    },

    newIds(items) {
        const ids = new Set();
        for (const one of items) {
            if (one.alarm_id === this.state.lastTopId) break;
            ids.add(one.alarm_id);
        }
        return ids;
    },

    mediaCell(one) {
        if (one.image_url) {
            const badge = one.video_url ? '<span class="alarm-play">▶</span>' : '';
            return `<div class="alarm-thumb"><img loading="lazy" src="${one.image_url}">${badge}</div>`;
        }
        return `<span class="alarm-muted">${one.alarm_type === 'text' ? '-' : this.STATUS_NAMES[one.image_status] || '-'}</span>`;
    },

    render(newIds = new Set()) {
        const body = this.$('alarm-body');
        body.innerHTML = this.state.items.length ? this.state.items.map(one => `
            <tr data-id="${one.alarm_id}" class="${newIds.has(one.alarm_id) ? 'alarm-new' : ''}">
                <td><input type="checkbox" class="row-check" value="${one.alarm_id}"></td>
                <td>${this.mediaCell(one)}</td>
                <td>${UI.escape(one.alarm_time_str)}</td>
                <td>${UI.escape(one.streamer_name)}</td>
                <td>${UI.escape(one.alarm_name)}</td>
                <td class="alarm-text">${UI.escape(one.alarm_text)}</td>
                <td>${this.TYPE_NAMES[one.alarm_type] || one.alarm_type}</td>
            </tr>`).join('') : `<tr><td colspan="7" class="alarm-empty">${I18N.t('暂无报警')}</td></tr>`;
        this.$('check-all').checked = false;

        const pages = Math.max(Math.ceil(this.state.total / this.state.page_size), 1);
        this.$('pager-total').textContent = I18N.t('共 {n} 条', { n: this.state.total });
        this.$('pager-info').textContent = `${this.state.page} / ${pages}`;
        this.$('pager-prev').disabled = this.state.page <= 1;
        this.$('pager-next').disabled = this.state.page >= pages;
    },

    async showDetail(alarmId) {
        const { data } = await axios.get(`/api/alarms/${alarmId}`);
        if (data.code !== 1) return UI.toast(data.message, 'error');
        const one = data.item;
        const fileIds = (one.files || []).map(f => `${f.file_type} ${f.file_id}`).join(', ')
            || [one.image_file_id != null && `image ${one.image_file_id}`, one.video_file_id != null && `video ${one.video_file_id}`].filter(Boolean).join(', ')
            || '-';
        const fields = [[I18N.t('时间'), one.alarm_time_str], [I18N.t('摄像头'), one.streamer_name], [I18N.t('报警名称'), one.alarm_name], [I18N.t('报警内容'), one.alarm_text],
                        [I18N.t('类型'), this.TYPE_NAMES[one.alarm_type]], [I18N.t('来源节点'), one.node_name],
                        [I18N.t('目标ID'), one.target_ids], [I18N.t('扩展信息'), one.extra],
                        [I18N.t('报警ID'), one.alarm_id], [I18N.t('文件ID'), fileIds]];
        const media = [
            one.image_url ? `<img class="alarm-detail-media" src="${one.image_url}"><a class="alarm-link" href="${one.image_url}" download>${I18N.t('下载图片')}</a>` : '',
            one.video_url ? `<video class="alarm-detail-media" src="${one.video_url}" controls autoplay muted></video><a class="alarm-link" href="${one.video_url}" download>${I18N.t('下载视频')}</a>` : '',
            one.alarm_type === 'video' && !one.video_url ? `<p class="alarm-muted">${I18N.t('视频')}: ${this.STATUS_NAMES[one.video_status] || one.video_status}</p>` : '',
        ].join('');
        this.detailModal = UI.modal(`
            <div class="alarm-detail">
                <div>${media}</div>
                <table class="alarm-detail-fields">${fields.map(([k, v]) => `<tr><th>${k}</th><td>${UI.escape(v)}</td></tr>`).join('')}</table>
            </div>`, { title: one.alarm_name, width: '900px', onClose: () => { this.detailModal = null; } });
    },

    async remove(alarmIds) {
        if (!alarmIds.length) return UI.toast(I18N.t('请先选择报警'), 'warning');
        if (!await UI.confirm(I18N.t('确定删除选中的 {n} 条报警及其图片、视频吗?', { n: alarmIds.length }))) return;
        const { data } = await axios.post('/api/alarms/delete', { alarm_ids: alarmIds });
        if (data.code !== 1) return UI.toast(data.message, 'error');
        UI.toast(I18N.t('已删除 {n} 条', { n: data.count }), 'success');
        this.query();
    },

    setRange(range) {
        const now = new Date();
        const start = new Date(now);
        if (range === 'today') start.setHours(0, 0, 0, 0);
        else start.setDate(start.getDate() - +range);
        this.$('f-start').value = this.toLocalInput(start / 1000);
        this.$('f-end').value = '';
        this.search();
    },

    search() {
        this.state.page = 1;
        this.query();
    },

    bind() {
        this.$('btn-lang').onclick = () => I18N.toggle();
        UI.datetime(this.$('f-start'));
        UI.datetime(this.$('f-end'));
        this.$('btn-search').onclick = () => this.search();
        this.$('btn-refresh').onclick = () => { this.loadOptions(); this.query(); };
        this.$('btn-reset').onclick = () => {
            this.FILTERS.forEach(k => { this.$(`f-${k}`).value = k === 'order' ? 'desc' : ''; });
            this.$('f-start').value = this.$('f-end').value = '';
            this.search();
        };
        this.$('btn-delete').onclick = () => this.remove([...document.querySelectorAll('.row-check:checked')].map(c => c.value));
        this.$('f-keyword').onkeydown = e => { if (e.key === 'Enter') this.search(); };
        ['streamer_name', 'alarm_name', 'alarm_type', 'order'].forEach(k => { this.$(`f-${k}`).onchange = () => this.search(); });
        document.querySelectorAll('[data-range]').forEach(btn => { btn.onclick = () => this.setRange(btn.dataset.range); });
        this.$('check-all').onchange = e => document.querySelectorAll('.row-check').forEach(c => { c.checked = e.target.checked; });
        this.$('pager-prev').onclick = () => { this.state.page--; this.query(); };
        this.$('pager-next').onclick = () => { this.state.page++; this.query(); };
        this.$('pager-size').onchange = e => { this.state.page_size = +e.target.value; this.search(); };
        this.$('alarm-body').onclick = e => {
            const row = e.target.closest('tr[data-id]');
            if (row && !e.target.closest('td:first-child')) this.showDetail(row.dataset.id);
        };
    },

    // Only refresh the first page when no detail is open, avoid disturbing the user
    autoRefresh() {
        setInterval(() => {
            if (this.$('auto-refresh').checked && this.state.page === 1 && !this.detailModal && !document.querySelector('.row-check:checked')) {
                this.query(true);
            }
        }, this.REFRESH_MS);
    },

    async init() {
        I18N.apply();
        this.bind();
        // the select values in the url can be restored only after the options are loaded
        await this.loadOptions().catch(e => UI.toast(e.message, 'error'));
        this.loadFromUrl();
        await this.query().catch(e => UI.toast(e.message, 'error'));
        this.autoRefresh();
    },
};

AlarmPage.init();
