// Index page: camera list, polygon / line calibration and streamer management
const Home = {
    REQUIRED: /^__.*__$/,
    STATE_COLORS: { ready: '#f2f2f2', alive: '#67c23a', dead: '#f56c6c' },

    cameras: [],          // [{name, children: [{algorithmName, polygons, lines}]}]
    streamerInfo: {},
    captainNames: [],
    camera: '',
    algo: '',
    tool: 'select',
    isEdit: false,
    saved: null,          // Snapshot of the current algorithm, restored when the changes are discarded
    imageSize: { width: 0, height: 0 },
    hoverBox: '',
    opened: new Set(),
    canvas: null,

    $(id) { return document.getElementById(id); },
    isEmpty(value) { return !value || !Object.keys(value).length; },
    clone(value) { return value === undefined ? undefined : JSON.parse(JSON.stringify(value)); },

    // Returns null and toasts the error when the request fails
    async post(url, data) {
        const res = await axios.post(url, data).then(r => r.data, () => ({ message: I18N.t('网络服务出错啦！') }));
        if (res.code === 1) return res;
        UI.toast(res.message || I18N.t('网络服务出错啦！'), 'error');
        return null;
    },

    current() {
        return this.cameras.find(c => c.name === this.camera)?.children.find(a => a.algorithmName === this.algo);
    },

    toChildren(cmask) {
        return Object.entries(cmask).map(([algorithmName, one]) => ({ algorithmName, ...one }));
    },

    // Points of the canvas -> normalized coordinates
    toPosition(points) {
        return points.map(p => [p.x / this.imageSize.width, p.y / this.imageSize.height]);
    },

    labelData() {
        const data = { label_polygon: [], label_pointLine: [] };
        const one = this.current();
        if (!one || (!this.imageSize.width && !this.imageSize.height)) return data;
        [['polygons', 'label_polygon'], ['lines', 'label_pointLine']].forEach(([key, target]) => {
            Object.entries(one[key] || {}).forEach(([name, points]) => {
                if (this.isEmpty(points)) return;
                data[target].push({
                    id: `${this.camera},${one.algorithmName},${name}`,
                    category: name,
                    polygon: { bottom: points.map(([x, y]) => ({ x: x * this.imageSize.width, y: y * this.imageSize.height })) },
                });
            });
        });
        return data;
    },

    // ---------------- camera / algorithm switching ----------------
    async loadCameras() {
        const data = await this.post('/connect');
        if (!data) return;
        this.captainNames = data.captain_names;
        this.streamerInfo = data.streamer_info;
        this.cameras = Object.entries(data.cmask_list).map(([name, cmask]) => ({ name, children: this.toChildren(cmask) }));
        if (this.camera === '' && this.cameras.length) {
            this.setCamera(this.cameras[0].name);
            this.setAlgo(this.cameras[0].children[0]?.algorithmName ?? '');
        }
        this.renderMenu();
        this.renderTools();
    },

    async setCamera(name) {
        if (name === this.camera) return;
        this.camera = name;
        this.opened.add(name);
        this.canvas.clearShapes();
        if (name === '') return;
        const main = this.$('main');
        main.classList.add('ui-loading');
        const data = await this.post('/get_image', { streamer_name: name });
        if (data) {
            for (const [camera, cmask] of Object.entries(data.streamer_cmask)) {
                const find = this.cameras.find(c => c.name === camera);
                if (find) find.children = this.toChildren(cmask);
                else this.cameras.push({ name: camera, children: this.toChildren(cmask) });
            }
            await this.initCanvas(data.image_data);
        } else {
            this.canvas.clear();
            this.canvas.clearImage();
            this.imageSize = { width: 0, height: 0 };
        }
        main.classList.remove('ui-loading');
        this.renderMenu();
    },

    setAlgo(name) {
        this.algo = name;
        this.saved = this.clone(this.current());
    },

    async initCanvas(image) {
        this.canvas.resetSelected();
        this.canvas.clear();
        try {
            this.imageSize = JSON.parse(await this.canvas.drawImage(image));
            this.canvas.reRenderSize('c-label');
            this.redraw();
        } finally {
            this.canvas.rebindEvents();
        }
    },

    setTool(tool) {
        if (this.canvas._isDrawing) this.canvas.drawShapeBySelfCancel();
        this.tool = tool;
        this.canvas.setTool(tool);
        this.renderTools();
        this.renderDelete();
        this.setCategory();
    },

    async select(camera, algo) {
        if (camera === this.camera && algo === this.algo) return;
        const change = () => {
            const sameCamera = camera === this.camera;
            this.setCamera(camera);
            this.setAlgo(algo);
            if (sameCamera) this.redraw();
            this.canvas.reRenderSize('c-label');
            this.renderMenu();
        };
        if (!this.isEdit) return change();
        if (await UI.confirm(I18N.t('当前存在修改标定,请选择是否提交?'))) return this.submit(change);
        this.isEdit = false;
        Object.assign(this.current(), this.saved);
        change();
    },

    // ---------------- calibration ----------------
    setCategory() {
        const one = this.current() || {};
        const names = Object.keys(one.polygons || {}).concat(Object.keys(one.lines || {}));
        // A draft category keeps a new stroke blue until it is named
        this.canvas.setCategory([...names.map(name => ({ name, color: '#409eff' })), { name: ' ', color: '#409eff' }]);
        this.canvas.setSelectCategory(this.tool === 'select' ? names[0] : ' ');
    },

    redraw() {
        this.setCategory();
        this.canvas.clearShapes();
        this.canvas.drawShapes(this.labelData());
    },

    clearAll() {
        this.canvas.clearShapes();
        const one = this.current();
        if (!one) return;
        ['polygons', 'lines'].forEach(key => Object.keys(one[key] || {}).forEach(name => { one[key][name] = null; }));
        this.changed();
    },

    changed() {
        this.isEdit = true;
    },

    shapeGroup(type) {
        return this.current()?.[type === 'polygon' ? 'polygons' : 'lines'];
    },

    isSubmit() {
        const one = this.current() || {};
        return ['polygons', 'lines'].every(key => Object.entries(one[key] || {}).every(([name, points]) => !this.REQUIRED.test(name) || !this.isEmpty(points)));
    },

    async submit(done) {
        const one = this.current();
        if (!one) return;
        const cmask = {};
        if (one.polygons) cmask.polygons = one.polygons;
        if (one.lines) cmask.lines = one.lines;
        const btn = this.$('btn-save');
        btn.disabled = true;
        if (await this.post('/set_cmask', { streamer_cmask: { [this.camera]: { [this.algo]: cmask } } })) {
            if (this.isSubmit()) {
                UI.toast(I18N.t('保存成功'), 'success');
                this.saved = this.clone(one);
            } else {
                UI.toast(I18N.t('存在必须标定项未标定'), 'error');
            }
        }
        if (done) done();
        this.isEdit = false;
        btn.disabled = false;
    },

    // Name a shape that was just drawn. Returns null when the prompt is cancelled.
    async askName(group) {
        const one = this.current() || {};
        const taken = new Set([...Object.keys(one.polygons || {}), ...Object.keys(one.lines || {})]);
        const pending = Object.entries(group).filter(([name, points]) => this.REQUIRED.test(name) && this.isEmpty(points)).map(([name]) => name);
        const message = pending.length ? `${I18N.t('请输入名称')}: ${pending.join('、')}` : I18N.t('请输入名称');
        const name = await UI.prompt(message, value => {
            const text = value.trim();
            if (text === '') return I18N.t('名称不能为空');
            if (taken.has(text) && !(text in group)) return I18N.t('名称不能重复');
            return '';
        });
        return name === null ? null : name.trim();
    },

    showContextMenu(e, items) {
        document.querySelector('.home-contextmenu')?.remove();
        const menu = document.createElement('ul');
        menu.className = 'home-contextmenu';
        menu.style.left = `${e.clientX}px`;
        menu.style.top = `${e.clientY}px`;
        items.forEach(([label, callback]) => {
            const li = document.createElement('li');
            li.textContent = label;
            li.onclick = callback;
            menu.appendChild(li);
        });
        document.body.appendChild(menu);
        setTimeout(() => document.addEventListener('click', () => menu.remove(), { once: true }));
    },

    // ---------------- streamer management ----------------
    openStreamer(name = '') {
        const info = name ? this.streamerInfo[name] : { algo_name: [], streamer_urls: [''] };
        if (!info) return;
        const algos = this.captainNames.map(algo => `
            <label><input type="checkbox" value="${UI.escape(algo)}" ${info.algo_name.includes(algo) ? 'checked' : ''} ${name ? 'disabled' : ''}> ${UI.escape(algo)}</label>`).join('');
        const modal = UI.modal(`
            <div class="home-form">
                <div class="home-form-row"><span>${I18N.t('算法选择')}</span><div class="home-algos">${algos}</div></div>
                <div class="home-form-row"><span>${I18N.t('节点名称')}</span><input class="ui-input" id="form-name" placeholder="${I18N.t('请输入节点名称')}"></div>
                <div class="home-form-row"><span>${I18N.t('视频流地址')}</span><div><button class="ui-btn ui-btn-small ui-btn-primary" id="form-add-url">${I18N.t('新增')}</button><div class="home-urls" id="form-urls"></div></div></div>
            </div>`, {
            title: name ? I18N.t('编辑') : I18N.t('新增'),
            footer: UI.okCancel(),
        });
        const urls = modal.body.querySelector('#form-urls');
        const addUrl = url => {
            const row = document.createElement('div');
            row.innerHTML = `<input class="ui-input"><span class="home-icon home-danger" title="${I18N.t('删除')}">−</span>`;
            row.querySelector('input').value = url;
            row.querySelector('span').onclick = () => row.remove();
            urls.appendChild(row);
        };
        info.streamer_urls.forEach(addUrl);
        modal.body.querySelector('#form-name').value = name;
        modal.body.querySelector('#form-add-url').onclick = () => addUrl('');
        modal.footer.querySelector('[data-act=cancel]').onclick = () => modal.close();
        modal.footer.querySelector('[data-act=ok]').onclick = async () => {
            const params = {
                captain_names: [...modal.body.querySelectorAll('.home-algos input:checked')].map(i => i.value),
                streamer_name: modal.body.querySelector('#form-name').value.trim(),
                streamer_urls: [...urls.querySelectorAll('input')].map(i => i.value.trim()).filter(Boolean),
            };
            if (!params.captain_names.length) return UI.toast(I18N.t('请选择算法'), 'error');
            if (!params.streamer_name) return UI.toast(I18N.t('请输入节点名称'), 'error');
            if (!params.streamer_urls.length) return UI.toast(I18N.t('请填写视频流地址'), 'error');
            modal.close();
            if (!await this.post(name ? '/modify_streamer' : '/set_streamer', params)) return;
            UI.toast(name ? I18N.t('修改成功') : I18N.t('添加成功'), 'success');
            if (name && this.camera === name) {
                this.camera = '';
                this.setCamera(params.streamer_name);
            }
            this.loadCameras();
        };
    },

    async deleteStreamer(name) {
        if (!await UI.confirm(I18N.t('是否确认删除'))) return;
        if (!await this.post('/del_streamer', { streamer_name: name })) return;
        if (this.camera === name) {
            this.camera = this.algo = '';
            this.canvas.clear();
        }
        UI.toast(I18N.t('删除成功'), 'success');
        this.loadCameras();
    },

    async restart() {
        if (!await UI.confirm(I18N.t('确定要重启服务吗?'))) return;
        if (!await this.post('/restart')) return;
        UI.toast(I18N.t('重启成功'), 'success');
    },

    async showDeviceInfo() {
        const data = await this.post('/get_device_info');
        if (!data) return;
        const modal = UI.modal('<p class="home-device"></p>', {
            title: I18N.t('设备信息'),
            width: '640px',
            footer: `<button class="ui-btn ui-btn-primary" data-act="copy">${I18N.t('复制')}</button>`,
        });
        modal.body.querySelector('.home-device').textContent = data.device_info;
        modal.footer.querySelector('[data-act=copy]').onclick = () => {
            // navigator.clipboard needs https, so copy by a temporary input
            const input = document.createElement('input');
            input.value = data.device_info;
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            input.remove();
            UI.toast(I18N.t('复制成功'), 'success');
        };
    },

    // ---------------- render ----------------
    renderMenu() {
        this.$('crumb').innerHTML = this.camera && this.algo
            ? `<b>${UI.escape(this.camera)}</b> / ${UI.escape(this.algo)}` : `<span class="home-muted">${I18N.t('请选择摄像头和算法')}</span>`;
        this.$('camera-menu').innerHTML = this.cameras.length ? this.cameras.map(c => `
            <li class="${this.opened.has(c.name) ? 'is-opened' : ''} ${c.name === this.camera ? 'is-active' : ''}" data-camera="${UI.escape(c.name)}">
                <div class="home-menu-title">
                    <i class="home-state" style="background:${this.STATE_COLORS[this.streamerInfo[c.name]?.state] || '#f56c6c'}"></i>
                    <span class="home-menu-name" title="${UI.escape(c.name)}">${UI.escape(c.name)}</span>
                    <a class="home-play" href="/insight/${encodeURIComponent(c.name)}" title="${I18N.t('播放')}"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></a>
                    <span class="home-icon" data-act="more" title="${I18N.t('更多')}">⋮</span>
                    <span class="home-arrow">›</span>
                </div>
                <ul>${c.children.map(a => `<li class="${c.name === this.camera && a.algorithmName === this.algo ? 'is-active' : ''}" data-algo="${UI.escape(a.algorithmName)}">${UI.escape(a.algorithmName)}</li>`).join('')}</ul>
            </li>`).join('') : `<li class="home-empty">${I18N.t('暂无摄像头')}</li>`;
    },

    renderTools() {
        this.$('draw-tools').querySelectorAll('[data-tool]').forEach(btn => {
            const on = btn.dataset.tool === this.tool;
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
    },

    renderDelete() {
        this.$('btn-delete').disabled = !this.canvas?._selected;
    },

    removeSelected() {
        const id = this.canvas.shapeKey(this.canvas._selected);
        if (!id) return;
        this.canvas.deleteShape(id);
    },

    // ---------------- events ----------------
    createCanvas() {
        const canvas = this.canvas = new CoolCanvas('c-label');
        canvas.setTextShow(true);
        canvas.afterDelete = (type, name) => {
            const group = this.shapeGroup(type);
            if (!group?.[name]) return;
            group[name] = null;
            this.changed();
        };
        const update = data => {
            const group = this.shapeGroup(data.shape.attrs.type);
            if (!group) return;
            group[data.category.name] = this.toPosition(data.points);
            this.changed();
        };
        canvas.afterEdit = update;
        canvas.afterMove = update;
        canvas.afterDraw = async data => {
            if (!data.isDraw) return;
            const points = this.toPosition(data.points);
            const drop = () => canvas.deleteShape(data.id);
            const group = this.shapeGroup(this.tool);
            if (!group) {
                drop();
                if (this.current()) UI.toast(I18N.t('当前节点不支持该标定'), 'error');
                return;
            }
            const name = await this.askName(group);
            if (name === null) return drop();
            if (!this.isEmpty(group[name]) && !await UI.confirm(I18N.t('当前已经标定,是否覆盖'))) return drop();
            group[name] = points;
            this.changed();
            this.redraw();
        };
        canvas.onHover = id => { this.hoverBox = (id || '').replace(/^(start_|end_)/, ''); };
        canvas.onSelected = () => this.renderDelete();
        this.$('main').oncontextmenu = e => e.preventDefault();
    },

    bind() {
        this.$('btn-add').onclick = () => this.openStreamer();
        this.$('btn-restart').onclick = () => this.restart();
        this.$('btn-config').onclick = () => this.showDeviceInfo();
        this.$('btn-delete').onclick = () => this.removeSelected();
        this.$('btn-clear').onclick = () => this.clearAll();
        this.$('btn-save').onclick = () => this.submit();
        this.$('btn-lang').onclick = async () => {
            if (!this.isEdit || !await UI.confirm(I18N.t('当前存在修改标定,请选择是否提交?'))) return I18N.toggle();
            this.submit(() => I18N.toggle());
        };
        this.$('draw-tools').onclick = e => {
            const tool = e.target.closest('[data-tool]')?.dataset.tool;
            if (tool) this.setTool(tool);
        };

        this.$('camera-menu').onclick = e => {
            const camera = e.target.closest('[data-camera]')?.dataset.camera;
            if (camera === undefined || e.target.closest('a')) return;
            if (e.target.dataset.act === 'more') {
                return this.showContextMenu(e, [[I18N.t('编辑'), () => this.openStreamer(camera)], [I18N.t('删除'), () => this.deleteStreamer(camera)]]);
            }
            const algo = e.target.closest('[data-algo]')?.dataset.algo;
            if (algo !== undefined) return this.select(camera, algo);
            this.opened.has(camera) ? this.opened.delete(camera) : this.opened.add(camera);
            this.renderMenu();
        };

        window.addEventListener('keydown', e => {
            if (e.key === 'Delete' && this.hoverBox) this.canvas.deleteShape(this.hoverBox);
        });
    },

    init() {
        I18N.apply();
        this.$('main').dataset.loading = I18N.t('加载中...');
        this.createCanvas();
        this.bind();
        this.loadCameras();
    },
};

Home.init();
