// Annotation canvas of the index page (polygon / line calibration), translated from the Vue source libs/Canvas, based on Konva(static/js/lib/konva.min.js)
(function () {
function uniqId() {
    const hexDigits = '0123456789abcdef';
    const s = [];
    for (let i = 0; i < 32; i++) s[i] = hexDigits[Math.floor(Math.random() * 16)];
    s[14] = '4';
    s[19] = hexDigits[(parseInt(s[19], 16) & 0x3) | 0x8];
    return s.join('');
}

/**
 * 解析字符串为数字（如果传入的就是数字则不做处理）
 * */
function getNum(data) {
    return typeof data === 'string' ? Number.parseFloat(data) : data;
}
/**
 * 将十六进制的hex颜色转换成rgba
 * @param hex 十六进制hex
 * @param opacity 透明度
 * @returns rgba字符串
 */
function hexToRgba(hex, opacity = 0.2) {
    const full = hex.length === 4 ? '#' + [...hex.slice(1)].map(c => c + c).join('') : hex;
    return ('rgba(' +
        parseInt(full.slice(1, 3), 16) +
        ',' +
        parseInt(full.slice(3, 5), 16) +
        ',' +
        parseInt(full.slice(5, 7), 16) +
        ',' +
        opacity +
        ')');
}
// Light label colors need a dark ring, darker ones a white ring
function textHalo(color) {
    const full = color.length === 4 ? '#' + [...color.slice(1)].map(c => c + c).join('') : color;
    const r = parseInt(full.slice(1, 3), 16);
    const g = parseInt(full.slice(3, 5), 16);
    const b = parseInt(full.slice(5, 7), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.72 ? 'rgba(0,0,0,0.75)' : '#fff';
}
/**
 * 清除浮点
 * */
function clearFloat(number, precision = 2) {
    return Math.round(number * 10 ** precision) / 10 ** precision;
}
/**
 * 根据偏移量计算实际坐标（数组计算）
 * @param points 原数据（数组）
 * @param offset 偏移量
 * */
function calcOffset(points, offset) {
    return points.map(({ x, y }) => ({
        x: clearFloat(x + offset.x),
        y: clearFloat(y + offset.y),
    }));
}
/**
 * 根据偏移量计算实际坐标（单个计算）
 * @param points 原数据
 * @param offset 偏移量
 * */
function calcOffsetOne({ x, y }, offset) {
    return {
        x: clearFloat(x + offset.x),
        y: clearFloat(y + offset.y),
    };
}
/**
 * Konva points纯数字数组转换为{x, y}数组
 * */
function pointsArrayTurnObj(arr) {
    const result = [];
    for (let i = 0; i < arr.length; i += 2) {
        result.push({
            x: arr[i],
            y: arr[i + 1],
        });
    }
    return result;
}
/**
 * {x, y}数组转换为Konva points纯数字数组
 * */
function pointsObjTurnArray(points) {
    const result = [];
    points.forEach(({ x, y }) => {
        result.push(x);
        result.push(y);
    });
    return result;
}
/**
 * 判断是否为图形（shape），是就返回shape，不是就查找子类是否有shape
 * */
function figureShape(origin) {
    return origin instanceof Konva.Group
        ? origin.children?.find(i => !(i instanceof Konva.Text))
        : origin;
}
/**
 * 判断是否为文字（text），是就返回text，不是就查找子类是否有text
 * */
function figureText(origin) {
    return origin instanceof Konva.Group
        ? origin.children?.find(i => i instanceof Konva.Text)
        : origin;
}
/**
 * 根据点位计算面积
 * */
function areaCalculator(polygon) {
    let total = 0;
    for (let i = 0; i < polygon.length; i++) {
        const addX = polygon[i][0];
        const addY = polygon[i === polygon.length - 1 ? 0 : i + 1][1];
        const subX = polygon[i === polygon.length - 1 ? 0 : i + 1][0];
        const subY = polygon[i][1];
        total = total + (addX * addY * 0.5 - subX * subY * 0.5);
    }
    return Math.abs(total);
}
/**
 * 计算鼠标点击的点位在画布上的实际坐标
 * @param point 鼠标点击的点位
 * @param layerPosition 画布的位置（layer.x()/layer.y()）
 * @param scale 画布的缩放比例（layer.scaleX()/layer.scaleY()）
 * */
function calcPositionAtLayer(point, layerPosition, scale = { x: 1, y: 1 }) {
    return {
        x: (point.x - layerPosition.x) / scale.x,
        y: (point.y - layerPosition.y) / scale.y,
    };
}
/**
 * 计算点位（相对layer的点位）是否超出边界，返回一个新的点位
 * @param x x坐标
 * @param y y坐标
 * @param image 图片对象
 */
function calcPointOutOfBoundary(x, y, image) {
    if (!image)
        return { x, y };
    if (x < 0)
        x = 0;
    else if (x > image.width())
        x = image.width();
    if (y < 0)
        y = 0;
    else if (y > image.height())
        y = image.height();
    return { x, y };
}
/**
 * 计算点位（相对画布的点位）是否超出layer边界，返回一个新的点位
 */
function calcPointOutOfLayerBoundary({ x, y, layerPosition, image, scale, fix = 0, }) {
    if (!image)
        return { x, y };
    const maxX = layerPosition.x + image.width() * (scale?.x ?? 1) - fix;
    const maxY = layerPosition.y + image.height() * (scale?.y ?? 1) - fix;
    const minX = layerPosition.x - fix;
    const minY = layerPosition.y - fix;
    if (x < minX)
        x = minX;
    else if (x > maxX)
        x = maxX;
    if (y < minY)
        y = minY;
    else if (y > maxY)
        y = maxY;
    return { x, y };
}
/**
 * 计算offset值，是否会导致点超出边界
 */
function calcOffsetOutOfBoundary({ x, y, layerPosition, image, scale, width, height, offset, }) {
    if (!image)
        return { x, y };
    if (!offset)
        offset = { x: 0, y: 0 };
    if (!scale)
        scale = { x: 1, y: 1 };
    const maxX = layerPosition.x + (image.width() - width) * scale.x - offset.x;
    const maxY = layerPosition.y + (image.height() - height) * scale.y - offset.y;
    const minX = layerPosition.x - offset.x;
    const minY = layerPosition.y - offset.y;
    if (x < minX)
        x = minX;
    else if (x > maxX)
        x = maxX;
    if (y < minY)
        y = minY;
    else if (y > maxY)
        y = maxY;
    return { x, y };
}
/**
 * 计算多边形的偏移，是否会导致点超出边界
 * */
function calcPolygonOffsetOutOfBoundary({ x, y, points, image, layerPosition, scale, }) {
    if (!image)
        return { x, y };
    if (!scale)
        scale = { x: 1, y: 1 };
    let minPointX = points[0], minPointY = points[1], maxPointX = points[0], maxPointY = points[1];
    for (let i = 0; i < points.length; i += 2) {
        const pointX = points[i];
        const pointY = points[i + 1];
        if (pointX < minPointX)
            minPointX = pointX;
        if (pointY < minPointY)
            minPointY = pointY;
        if (pointX > maxPointX)
            maxPointX = pointX;
        if (pointY > maxPointY)
            maxPointY = pointY;
    }
    /* 下面的代码是AI写的，我也不太懂 */
    // 计算多边形的最大最小x,y坐标
    const maxX = layerPosition.x + (image.width() - maxPointX) * scale.x;
    const maxY = layerPosition.y + (image.height() - maxPointY) * scale.y;
    const minX = layerPosition.x - minPointX * scale.x;
    const minY = layerPosition.y - minPointY * scale.y;
    if (x < minX)
        x = minX;
    else if (x > maxX)
        x = maxX;
    if (y < minY)
        y = minY;
    else if (y > maxY)
        y = maxY;
    return { x, y };
}
function isRect(points) {
    const x_arr = points.map(i => i.x);
    const y_arr = points.map(i => i.y);
    return new Set(x_arr).size === 2 && new Set(y_arr).size === 2;
}

// 有空再写上不同的图标吧
const controllerCursor = ['move', 'move', 'move', 'move'];
const SHADOW_SIZE = 1;
// 控制器
// 依赖于konva的layer，所以必须要有konva，也必须要有layer
class CoolController {
    constructor(layer, options) {
        this._controllers = [];
        this._controllerObjs = [];
        this._polylineControllers = [];
        this._polylineControllerObjs = [];
        this._size = 8;
        this._controllerStrokeWidth = 2;
        this._offset = { x: 0, y: 0 };
        this._layer = layer;
        if (options?.origin)
            this.setOrigin(options.origin);
        if (options?.size)
            this._size = options.size;
    }
    setOrigin(origin) {
        if (this._origin)
            this.clearOrigin();
        this._origin = origin;
        const id = origin.attrs.id;
        if (id && id.startsWith('group_'))
            id.replace('group_', '');
        this._originId = id;
        if (origin instanceof Konva.Group) {
            this._offset.x = origin.position().x;
            this._offset.y = origin.position().y;
        }
        else {
            this._offset.x = 0;
            this._offset.x = 0;
        }
        this._genControllers();
    }
    clearOrigin() {
        this._originId = undefined;
        this._origin = undefined;
        this._controllers = [];
        this._polylineControllers = [];
        this.clearControllerObjs();
        this.clearPolylineControllerObjs();
    }
    clearControllerObjs() {
        while (this._controllerObjs.length > 0) {
            const obj = this._controllerObjs.pop();
            if (obj) {
                obj.destroy();
            }
        }
    }
    clearPolylineControllerObjs() {
        while (this._polylineControllerObjs.length > 0) {
            const obj = this._polylineControllerObjs.pop();
            obj?.destroy();
        }
    }
    fixControllerScale(scale) {
        if (scale === undefined)
            scale = this._layer.scaleX();
        this._controllerObjs.forEach(i => {
            i.radius(this._size / 2 / scale);
            i.strokeWidth(this._controllerStrokeWidth / scale);
            i.shadowBlur(SHADOW_SIZE / scale);
        });
        this._polylineControllerObjs.forEach(i => {
            i.strokeWidth(this._size / scale);
        });
    }
    _genControllers(origin) {
        if (!origin && this._origin)
            origin = this._origin;
        if (!origin)
            return;
        const obj = figureShape(origin);
        if (obj instanceof Konva.Line)
            this._genPolygonControllersFactory(obj);
        this._placeLineControllers();
        this._placeControllers();
    }
    _genPolygonControllersFactory(origin) {
        this._controllers = calcOffset(pointsArrayTurnObj(origin.points()), this._offset);
        const _polylines = [];
        this._controllers.forEach((i, index) => {
            const next = index !== this._controllers.length - 1 ? index + 1 : 0;
            _polylines.push({
                points: [i, this._controllers[next]],
                to: [index, next],
            });
        });
        this._polylineControllers = _polylines;
    }
    _setControllerEvent(controller) {
        controller.on('click', ev => {
            const target = figureShape(this._origin);
            // 多边形
            if (target instanceof Konva.Line) {
                // 检测是否右键点击，如果是右键点击则删除该点位，如果只剩下三个点则不做删除
                if (ev.evt.button === 2) {
                    if (this._controllers.length > 3) {
                        this._controllers.splice(controller.attrs.controlIdx, 1);
                        this.onControl?.('click', controller, ev);
                    }
                }
            }
        });
        controller.on('dragstart', ev => {
            this.onControl?.('start', controller, ev);
        });
        controller.on('dragmove', ev => {
            const target = figureShape(this._origin);
            if (controller instanceof Konva.Circle &&
                ev.target.attrs.controlIdx !== undefined &&
                target instanceof Konva.Line)
                this._polygonControllerMove();
            this.onControl?.('move', controller, ev);
        });
        controller.on('dragend', ev => {
            this.onControl?.('end', controller, ev);
        });
    }
    _setPolylineControllerEvent(controller) {
        controller.on('click', ev => {
            const to = controller.getAttr('to');
            const mousePoint = calcPositionAtLayer({ x: ev.evt.offsetX, y: ev.evt.offsetY }, this._layer.position(), this._layer.scale());
            this._controllers.splice(to[0] + 1, 0, mousePoint);
            this.onControl?.('click', controller, ev);
        });
    }
    _polygonControllerMove() {
        this._controllers = this._controllerObjs.map(i => ({ x: i.x(), y: i.y() }));
    }
    _placeControllers() {
        const flag = isRect(this.controllers);
        this._controllers.forEach((point, index) => {
            const controller = this._controllerFactory(point, index, flag);
            this._setControllerEvent(controller);
            this._layer.add(controller);
            this._controllerObjs.push(controller);
        });
    }
    _placeLineControllers() {
        this._polylineControllers.forEach((i, index) => {
            const line = this._polylineControllerFactory(i, index);
            this._setPolylineControllerEvent(line);
            this._layer.add(line);
            this._polylineControllerObjs.push(line);
        });
    }
    _controllerFactory({ x, y }, idx, flag = true) {
        const that = this;
        if (figureShape(this._origin).attrs.type === 'polygon')
            flag = true;
        return new Konva.Circle({
            type: 'controller',
            name: 'controller controller_' + idx,
            x,
            y,
            controlIdx: idx,
            radius: this._size / this._layer.scaleX() / 2,
            stroke: '#fff',
            strokeWidth: this._controllerStrokeWidth / this._layer.scaleX(),
            shadowBlur: SHADOW_SIZE / this._layer.scaleX(),
            shadowColor: '#000',
            // fill: '#ff000099',
            draggable: true,
            cursor: controllerCursor?.[idx] ?? 'move',
            dragBoundFunc: function (pos) {
                if (flag) {
                    return calcPointOutOfLayerBoundary({
                        ...pos,
                        layerPosition: that._layer.position(),
                        scale: that._layer.scale(),
                        image: that._layer.findOne('.image'),
                    });
                }
                else
                    return pos;
            },
        });
    }
    _polylineControllerFactory({ points, to }, index) {
        return new Konva.Line({
            type: 'controller',
            controlIdx: index,
            to: to,
            name: 'polylineController polylineController_' + to[0] + '_' + to[1],
            points: pointsObjTurnArray(points),
            strokeWidth: this._size / this._layer.scaleX(),
            cursor: 'cell',
            stroke: '#ffffff00',
            // stroke: '#f00',
            draggable: false,
        });
    }
    get origin() {
        return this._origin;
    }
    get controllers() {
        return this._controllers;
    }
    get size() {
        return this._size;
    }
    set size(value) {
        this._size = value;
    }
}

class CoolCanvas {
    constructor(id) {
        this.width = 0;
        this.height = 0;
        this.maxScale = 10;
        this.minScale = 0.1;
        this.baseStrokeWidth = 1;
        this.baseFontSize = 16;
        this.baseCircleRadius = 6;
        this._scale = 1;
        this._readonly = false;
        this._tool = 'select';
        this._selected = '';
        this._hovering = '';
        this._isDrawing = false;
        this._drawPoints = [];
        this._mouse = { x: 0, y: 0 };
        this._clickMouse = { x: 0, y: 0 };
        this._isMousePress = false;
        this._showText = false;
        this._category = {};
        this.selectedCategory = '';
        this._children = {};
        let dom;
        this._currLoadingImg = 0;
        if (id) {
            dom = document.getElementById(id);
            // else dom = document.createElement('div')
            if (!dom)
                throw new Error('DOM not found');
            this._setSize(dom);
            dom.addEventListener('contextmenu', e => e.preventDefault());
            this.stage = new Konva.Stage({
                container: id ?? dom,
                width: this.width,
                height: this.height,
            });
        }
        this.layer = new Konva.Layer();
        if (id) {
            this._setController();
            this.stage?.add(this.layer);
            this._bindEvents();
            this.setTool();
        }
    }
    _bindEvents() {
        this.stage?.on('mousedown', this.mousedown.bind(this));
        this.stage?.on('mouseup', this.mouseup.bind(this));
        this.stage?.on('mousemove', this.mousemove.bind(this));
        this.stage?.on('wheel', this._wheel.bind(this));
        this.stage?.on('mouseout', this.mouseout.bind(this));
    }
    _clearEvents() {
        this.stage?.off('mousedown');
        this.stage?.off('mouseup');
        this.stage?.off('mousemove');
        this.stage?.off('mouseout');
        this.stage?.off('wheel');
    }
    rebindEvents() {
        this._clearEvents();
        this._bindEvents();
    }
    _setSize(dom, resizeOnly = false) {
        if (!resizeOnly)
            this.dom = dom;
        else
            dom = this.dom;
        this.width = dom?.offsetWidth ?? 0;
        this.height = dom?.offsetHeight ?? 0;
        if (this.width === 0 || this.height === 0) {
            if (dom?.parentElement) {
                this.width = dom.parentElement.offsetWidth;
                this.height = dom.parentElement.offsetHeight;
            }
            else if (dom) {
                this.width = 800;
                this.height = 600;
            }
        }
    }
    // 当页面变动，主动调用此方法来修改宽高
    reRenderSize(el) {
        let dom;
        if (typeof el === 'string') {
            dom = document.getElementById(el);
        }
        else if (el)
            dom = el;
        else
            dom = this.dom;
        if (!dom)
            return;
        this._setSize(dom, true);
        this.stage?.width(this.width);
        this.stage?.height(this.height);
        this.fitBounds();
    }
    _setController() {
        if (!this._readonly) {
            this._controllerService = new CoolController(this.layer);
            this._controllerBind();
        }
    }
    // 检验layer的x,y是否超出边界，会返回一个合法的{x,y}对象
    _checkLayerXY(x, y) {
        const image = this.layer.findOne('.image');
        if (image) {
            const scaleWidth = image.width() * this._scale;
            const scaleHeight = image.height() * this._scale;
            const limitX = -scaleWidth + 20;
            const limitY = -scaleHeight + 20;
            const maxX = this.width - 20;
            const maxY = this.height - 20;
            if (x < limitX)
                x = limitX;
            else if (x > maxX)
                x = maxX;
            if (y < limitY)
                y = limitY;
            else if (y > maxY)
                y = maxY;
        }
        return { x, y };
    }
    // 检验point是否超出边界，会返回一个合法的{x,y}对象
    _checkPointInImage(x, y) {
        const image = this.layer.findOne('.image');
        return calcPointOutOfBoundary(x, y, image);
    }
    _stageDrag() {
        this.stage?.draggable(true);
        this.stage?.on('dragend', () => {
            const x = this.layer.x() + (this.stage?.x() ?? 0);
            const y = this.layer.y() + (this.stage?.y() ?? 0);
            this.layer.position(this._checkLayerXY(x, y));
            this.stage?.position({ x: 0, y: 0 });
        });
    }
    _stopStageDrag() {
        this.stage?.draggable(false);
        this.stage?.off('dragend');
    }
    _getArea(shape) {
        const { fullPoints } = this.getPoints(shape);
        if (shape.attrs.type === 'pointLine') {
            return 1;
        }
        return areaCalculator(fullPoints.map(i => [i.x, i.y]));
    }
    _calcZIndex() {
        const keys = Object.keys(this._children);
        if (keys.length <= 1)
            return;
        const children = keys?.sort((a, b) => {
            return (Number.parseFloat(this._children[b].getAttr('area')) -
                Number.parseFloat(this._children[a].getAttr('area')));
        });
        children.forEach((id, index) => {
            this._children[id].zIndex(index + 1);
        });
    }
    _controllerBind() {
        if (!this._controllerService)
            return;
        this._controllerService.onControl = (status, item) => {
            const target = figureShape(this._children[this._selected]);
            const text = figureText(this._children[this._selected]);
            if (text)
                text.destroy();
            if (this.stage)
                this.stage.container().style.cursor = item.attrs.cursor;
            target.opacity(0);
            if (target.attrs.type === 'polygon')
                this._drawPoints = this._controllerService.controllers;
            const shape = this.drawShapeBySelfUndone({
                tool: target.attrs.type,
                category: target.attrs.category,
                strokeColor: '#fff',
            });
            if (status !== 'end') {
                if (target instanceof Konva.Line && shape)
                    target.points(shape.points());
                this._children[this._selected].position({ x: 0, y: 0 });
            }
            if (status === 'end' || status === 'click') {
                shape?.destroy();
                target.opacity(1);
                if (this.stage && status === 'click')
                    this.stage.container().style.cursor = 'move';
                const newText = this.drawText(target);
                this._children[this._selected].add(newText);
                this._children[this._selected].setAttr('area', this._getArea(shape || target));
                this._calcZIndex();
                this.afterEdit?.(this._genOutputData(target));
                this._controllerService?.setOrigin(this._children[this._selected]);
            }
        };
    }
    // 通用options配置
    genCommonOptions(item, options) {
        let cate, number;
        if (item?.category)
            cate = this._category[item.category];
        else
            cate = this._category[this.selectedCategory];
        if (item?.number !== undefined)
            number = item.number;
        else {
            try {
                const numbers = this.layer
                    .find('.' + cate.name)
                    .map(i => (i.attrs?.number ? Number.parseInt(i.attrs.number) : 1))
                    .sort((a, b) => b - a);
                number = (numbers[0] ?? 0) + 1;
            }
            catch (e) {
                number = 1;
            }
        }
        return {
            id: item?.instanceId ?? item?.id ?? uniqId(),
            name: 'label ' + cate?.name,
            category: cate?.name,
            number,
            ...options,
        };
    }
    // 清除
    clear() {
        if (this._controllerService) {
            this._controllerService.clearOrigin();
        }
        this.layer.destroyChildren();
        this._children = {};
        this.setScale(1);
        this._isMousePress = false;
        this._mouse.x = 0;
        this._mouse.y = 0;
        this.resetSelected();
        this.layer.scaleX(1);
        this.layer.scaleY(1);
        this.layer.offsetX(0);
        this.layer.offsetY(0);
    }
    clearImage() {
        this.layer.find('.image').forEach(i => i.destroy());
    }
    clearShapes() {
        this.resetSelected();
        this._children = {};
        this.layer.find('.group').forEach(i => i.destroy());
        this.layer.find('.layer').forEach(i => i.destroy());
        this.layer.find('.text').forEach(i => i.destroy());
    }
    // 获取相对与layer位置的点位
    figurePositionAtLayer(point) {
        if (!point)
            point = this._mouse;
        return calcPositionAtLayer(point, this.layer.position(), this.layer.scale());
    }
    // 设置工具
    setTool(mode = 'select') {
        this._tool = mode;
        if (mode === 'select') {
            this.setReadonly(false);
            this._stageDrag();
        }
        else {
            this.setReadonly(true);
            this._stopStageDrag();
        }
        this.resetSelected();
        if (this._isDrawing) {
            this.drawShapeBySelfCancel();
        }
        return Promise.resolve();
    }
    // 设置当前激活类别
    setSelectCategory(name) {
        this.selectedCategory = name;
    }
    // 重制当前选中框
    resetSelected() {
        const had = !!this._selected;
        if (this._selected) {
            const categoryName = this._children[this._selected]?.children?.[0]?.attrs.category;
            const cate = this._category[categoryName];
            this.setChildrenColor(this._selected, cate?.color);
            this._selected = '';
        }
        if (this._controllerService)
            this._controllerService.clearOrigin();
        if (had)
            this.onSelected?.();
    }
    setSelected(id) {
        if (!id) {
            this.resetSelected();
            this.onSelected?.();
            return;
        }
        let localId = id;
        if (id.startsWith('group_'))
            localId = localId.replace('group_', '');
        if (id.startsWith('text_'))
            localId = localId.replace('text_', '');
        if (localId !== this._selected) {
            this.resetSelected();
            this._selected = localId;
            // this._children[localId]?.moveToTop()
            this.setChildrenColor(localId, '#ffffff');
        }
        if (this._controllerService) {
            /* const origin = this._children[localId]?.children?.find(
              i => i.attrs.type !== 'text' && i.attrs.type !== 'point',
            ) */
            if (this._children[localId])
                this._controllerService.setOrigin(this._children[localId]);
        }
        this.onSelected?.(this._selected, this._children[this._selected]);
    }
    // Line endpoints are stored separately; hover and color treat them as the line
    shapeKey(id) {
        return (id || '').replace(/^(?:text_|group_|start_|end_)/, '');
    }
    setHovering(id) {
        id = id ? this.shapeKey(id) : '';
        if (this._hovering &&
            this._hovering !== id &&
            this._hovering !== this._selected) {
            const categoryName = this._children[this._hovering]?.children?.[0]?.attrs.category;
            const cate = this._category[categoryName];
            this.setChildrenColor(this._hovering, cate?.color);
        }
        if (id) {
            if (id !== this._selected)
                this.setChildrenColor(id, '#ffff00');
            this._hovering = id;
        }
        else {
            this._hovering = '';
        }
        this.onHover?.(this._hovering, this._children[this._hovering]);
    }
    setChildrenColor(id, color = '#ff0000') {
        const target = this.shapeKey(id);
        const emphasize = color === '#ffff00' || color === '#ffffff';
        [target, 'start_' + target, 'end_' + target].forEach(one => {
            this._children[one]?.children?.forEach(i => {
                if (!(i instanceof Konva.Shape))
                    return;
                if (i.attrs.type === 'text') {
                    i.fill(color);
                    i.stroke(textHalo(color));
                }
                else if (i.attrs.type === 'pointLine_point') {
                    i.stroke(color);
                    i.fill(hexToRgba(color, 0.85));
                }
                else {
                    i.stroke(color);
                    if (i.attrs.type === 'pointLine')
                        i.strokeWidth((emphasize ? 2.5 : this.baseStrokeWidth) / this._scale);
                }
            });
        });
    }
    // 鼠标移除canvas
    mouseout() {
        this.onMouseOut?.();
    }
    // 鼠标移动
    mousemove(ev) {
        const { offsetX, offsetY } = ev.evt;
        this._mouse.x = offsetX;
        this._mouse.y = offsetY;
        if (this._isDrawing) {
            if (this.stage)
                this.stage.container().style.cursor = 'default';
            this.drawShapeBySelfUndone();
        }
        else {
            if (ev.target && ev.target.getAttr('id')) {
                this.setHovering(ev.target.getAttr('id'));
            }
            else {
                this.setHovering();
            }
            if (ev.target && ev.target.attrs.cursor) {
                if (this.stage)
                    this.stage.container().style.cursor = ev.target.attrs.cursor;
            }
            else if (ev.target && ev.target.attrs.type && !this._readonly) {
                if (this.stage && this._isMousePress)
                    this.stage.container().style.cursor = 'grabbing';
                if (this.stage && !this._isMousePress)
                    this.stage.container().style.cursor = 'grab';
            }
            else if (this.stage)
                this.stage.container().style.cursor = 'default';
        }
        const p = this.figurePositionAtLayer(this._mouse);
        if (this._drawPoints.length > 0) {
            this.onMouseMove?.([...this._drawPoints, p]);
        }
        else {
            this.onMouseMove?.([p]);
        }
    }
    // ev: Konva.KonvaEventObject<MouseEvent>
    mouseup() {
        this._isMousePress = false;
    }
    _wheel(ev) {
        if (!this.stage)
            return;
        ev.evt.preventDefault();
        if (ev.evt.metaKey || ev.evt.ctrlKey) {
            const direction = ev.evt.deltaY > 0 ? -1 : 1;
            const pointer = this.stage.getPointerPosition();
            this.zoomInAndOut(direction > 0, pointer);
        }
        else {
            let x;
            let y;
            if (ev.evt.altKey || ev.evt.shiftKey) {
                x = this.layer.x() - ev.evt.deltaY;
                y = this.layer.y();
            }
            else {
                x = this.layer.x() - ev.evt.deltaX;
                y = this.layer.y() - ev.evt.deltaY;
            }
            this.layer.position(this._checkLayerXY(x, y));
        }
        ev.evt.stopPropagation();
    }
    // 右键点在画布上时，吞掉随后一次浏览器自带菜单
    _blockNativeMenu() {
        const stop = e => {
            e.preventDefault();
            cleanup();
        };
        const cleanup = () => {
            document.removeEventListener('contextmenu', stop, true);
            clearTimeout(timer);
        };
        document.addEventListener('contextmenu', stop, true);
        const timer = setTimeout(cleanup, 500);
    }
    // 鼠标点击
    mousedown(ev) {
        // 右键结束多边形后会立刻弹出命名框，contextmenu 的目标已经不是画布，要提前在 document 上拦住浏览器菜单
        if (ev.evt.button === 2)
            this._blockNativeMenu();
        if (this._isDrawing) {
            if (ev.evt.clientX > this._clickMouse.x) {
                this._clickMouse.x = ev.evt.clientX;
                this._clickMouse.y = ev.evt.clientY;
            }
        }
        else {
            this._clickMouse.x = ev.evt.clientX;
            this._clickMouse.y = ev.evt.clientY;
        }
        // 右键停止多边形画图
        if (ev.evt.button === 2 && !this._isDrawing) {
            // 右键
            this.onContextMenu?.(ev, this._hovering !== '');
            return;
        }
        const id = ev?.target?.attrs?.id;
        const target = ev.target;
        this._isMousePress = true;
        switch (this._tool) {
            case 'select':
                if (target.attrs.type &&
                    (target.attrs.type === 'controller' ||
                        target.attrs.oriShapeType === 'pointLine'))
                    return;
                this.setSelected(id);
                break;
            case 'polygon':
                this.drawShapeBySelf(ev);
                break;
            case 'pointLine':
                if (ev.evt.button !== 2)
                    this.drawShapeBySelf(ev);
                else
                    this.drawShapeBySelfCancel();
                break;
            default:
                break;
        }
        this.onMouseDown?.();
    }
    // 作画功能
    drawShapeBySelf(ev) {
        const { offsetX, offsetY } = ev.evt;
        let point = this.figurePositionAtLayer({ x: offsetX, y: offsetY });
        point = this._checkPointInImage(point.x, point.y);
        if (this._isDrawing) {
            if (this._tool === 'polygon' && ev.evt.button === 2) {
                this.drawShapeBySelfDone();
                return;
            }
            this._drawPoints.push(point);
            if (this._tool === 'pointLine' && this._drawPoints.length === 2)
                this.drawShapeBySelfDone();
        }
        else {
            this.setDrawing(true);
            this._drawPoints = [point];
        }
    }
    // 画临时框
    drawShapeBySelfUndone(data) {
        //
        let tool = data?.tool;
        const category = data?.category;
        if (!tool)
            tool = this._tool;
        // this.layer.find('.TEMP')?.destroy()
        this.layer.find('.TEMP').forEach(i => i.destroy());
        const cate = this._category[category ?? this.selectedCategory];
        const options = {
            name: 'TEMP',
        };
        const points = [...this._drawPoints];
        if (!data) {
            const _tempPoint = this.figurePositionAtLayer();
            points.push(this._checkPointInImage(_tempPoint.x, _tempPoint.y));
        }
        let shape;
        if (tool === 'pointLine') {
            shape = this.drawPointLine({
                points,
                color: data?.color || cate?.color,
                strokeColor: data?.strokeColor,
                options,
            });
        }
        else if (tool === 'polygon') {
            shape = this.drawPolygon({
                points,
                color: data?.color || cate?.color,
                strokeColor: data?.strokeColor,
                options,
            });
        }
        return shape;
    }
    // 画框中止
    drawShapeBySelfCancel() {
        // this.layer.findOne('.TEMP')?.destroy()
        this.layer.find('.TEMP').forEach(i => i.destroy());
        this.setDrawing(false);
        this._drawPoints = [];
    }
    // 画框完成
    drawShapeBySelfDone() {
        this.layer.find('.TEMP').forEach(i => i.destroy());
        const cate = this._category[this.selectedCategory];
        const options = this.genCommonOptions(undefined, {
            isDraw: true,
        });
        this.setDrawing(false);
        if (this._tool === 'polygon' && this._drawPoints.length > 2) {
            this.drawPolygon({
                points: this._drawPoints,
                color: cate?.color,
                options,
            });
        }
        else if (this._tool === 'pointLine') {
            this.drawPointLine({
                points: this._drawPoints,
                color: cate?.color,
                options,
            });
        }
        this._drawPoints = [];
    }
    // 选择类别
    setCategory(categories) {
        const localCate = JSON.parse(JSON.stringify(categories));
        this._category = {};
        localCate.forEach(i => {
            if (i.name)
                this._category[i.name] = i;
        });
    }
    // 根据图形类别获取图形点位数组数据
    getPoints(shape, offset) {
        if (!offset)
            offset = { x: 0, y: 0 };
        const type = shape.attrs.type;
        let point = { x: shape.x(), y: shape.y() };
        let points;
        let fullPoints;
        if (type === 'pointLine_point') {
            point = calcOffsetOne(point, offset);
            points = [point];
            fullPoints = [point];
        }
        else {
            points = calcOffset(pointsArrayTurnObj(shape.points()), offset);
            fullPoints = [...points];
        }
        return { point, points, fullPoints };
    }
    // 生产一份输出出去的数据
    _genOutputData(shape, offset) {
        if (!offset)
            offset = { x: 0, y: 0 };
        const id = shape.attrs.id;
        const type = shape.attrs.type;
        const number = shape.attrs.number ?? 1;
        const isDraw = shape.attrs.isDraw ? true : undefined;
        let sendType;
        const category = this._category[shape.attrs.category];
        const { point, points } = this.getPoints(shape, offset);
        if (type === 'polygon')
            sendType = 'label_polygon';
        else
            sendType = 'label_pointLine';
        return {
            point,
            points,
            id,
            category,
            shape,
            type: sendType,
            isDraw,
            number,
        };
    }
    // 框画完后的事件集中绑定
    _shapeEventBind(shape) {
        if (shape.attrs.name !== 'TEMP') {
            const that = this;
            const text = this.drawText(shape);
            const group = new Konva.Group({
                draggable: !this._readonly && shape.attrs.type !== 'pointLine',
                name: 'group group_' + shape.attrs?.id ??
                    '' + ' ' + (shape.attrs?.category ?? ''),
                id: 'group_' + shape.attrs?.id ?? '',
                area: this._getArea(shape),
                category: shape.attrs?.category ?? '',
                dragBoundFunc: function (pos) {
                    const _origin = figureShape(this);
                    const _nodePos = { x: _origin.x(), y: _origin.y() };
                    let width = _origin.width();
                    let height = _origin.height();
                    _nodePos.x *= that._scale;
                    _nodePos.y *= that._scale;
                    if (_origin instanceof Konva.Line) {
                        const points = pointsArrayTurnObj(_origin.points());
                        if (!isRect(points) && _origin.attrs.type !== 'polygon') {
                            return pos;
                        }
                        else
                            return calcPolygonOffsetOutOfBoundary({
                                ...pos,
                                points: _origin.points(),
                                image: that.layer.findOne('.image'),
                                layerPosition: that.layer.position(),
                                scale: that.layer.scale(),
                            });
                    }
                    else if (_origin instanceof Konva.Circle) {
                        width = 0;
                        height = 0;
                    }
                    return calcOffsetOutOfBoundary({
                        ...pos,
                        layerPosition: that.layer.position(),
                        scale: that.layer.scale(),
                        offset: _nodePos,
                        height,
                        width,
                        image: that.layer.findOne('.image'),
                    });
                },
            });
            group.add(shape);
            group.on('dragstart', () => {
                if (this._controllerService)
                    this._controllerService.clearOrigin();
            });
            group.on('dragmove', ev => {
                const targetShape = figureShape(ev.target);
                // 单独处理以点作为线的控制器,拖动点的过程修改线的points
                if (targetShape.attrs.type === 'pointLine_point') {
                    const strId = targetShape.attrs.id.split('_');
                    const otherId = strId[0] === 'start' ? 'end_' + strId[1] : 'start_' + strId[1];
                    const another_target = figureShape(this._children[otherId]);
                    const shape = figureShape(this._children[strId[1]]);
                    const text = figureText(this._children[strId[1]]);
                    const points = [
                        this.getPoints(another_target, this._children[otherId].position())
                            .point.x,
                        this.getPoints(another_target, this._children[otherId].position())
                            .point.y,
                        this.getPoints(targetShape, ev.target.position()).point.x,
                        this.getPoints(targetShape, ev.target.position()).point.y,
                    ];
                    shape.points(points);
                    const futureText = this.drawText(shape);
                    text.x(futureText.x());
                    text.y(futureText.y());
                    text.setAttrs({
                        oriX: futureText.attrs.oriX,
                        oriY: futureText.attrs.oriY,
                    });
                }
            });
            group.on('dragend', (ev) => {
                const target = ev.target;
                const targetShape = figureShape(ev.target);
                if (targetShape.attrs.type === 'pointLine_point') {
                    const strId = targetShape.attrs.id.split('_');
                    const shape = figureShape(this._children[strId[1]]);
                    if (shape) {
                        const data = this._genOutputData(shape, this._children[strId[1]].position());
                        this.afterMove?.(data);
                    }
                    return;
                }
                const shape = figureShape(target);
                if (shape) {
                    const data = this._genOutputData(shape, target.position());
                    this.afterMove?.(data);
                }
                if (target && this._controllerService) {
                    this._controllerService.setOrigin(target);
                }
            });
            const localId = shape.attrs?.id ?? uniqId();
            if (text)
                group.add(text);
            this._children[localId] = group;
            this.layer.add(group);
            if (shape.attrs.type !== 'pointLine_point') {
                this.afterDraw?.(this._genOutputData(shape));
            }
            setTimeout(() => {
                this._calcZIndex();
            }, 1);
        }
        else {
            this.layer.add(shape);
        }
    }
    // 删除单个框
    deleteShape(id) {
        if (id === undefined)
            id = this._selected;
        if (!id) {
            const keys = Object.keys(this._children);
            if (keys.length > 0)
                id = keys[keys.length - 1];
        }
        if (!id)
            return;
        const group = this._children[id];
        // console.log(group)
        if (!group)
            return;
        const shape = figureShape(group);
        const cate = group.attrs.category ?? group.children?.[0].attrs.category;
        group.destroy();
        delete this._children[id];
        // 同时删除作为线控制器的点
        if (shape.attrs.type === 'pointLine') {
            const start = this._children['start_' + id];
            const end = this._children['end_' + id];
            if (start) {
                start.destroy();
                delete this._children['start_' + id];
            }
            if (end) {
                end.destroy();
                delete this._children['end_' + id];
            }
        }
        this.afterDelete?.(shape.attrs.type, cate ?? '');
        if (id === this._selected) {
            this.resetSelected();
        }
        if (id === this._hovering) {
            this._hovering = '';
        }
    }
    findCate(name) {
        return this._category[name];
    }
    // 通过传入的json画框
    drawShapes(labelInfo, categories) {
        if (categories)
            this.setCategory(categories);
        if (!labelInfo)
            return;
        const getOptions = (i) => {
            return this.genCommonOptions(i);
        };
        if (labelInfo.label_polygon) {
            labelInfo.label_polygon.forEach(i => {
                const points = i.polygon.bottom.map(({ x, y }) => ({
                    x: getNum(x),
                    y: getNum(y),
                }));
                const cate = this.findCate(i.category);
                this.drawPolygon({
                    points,
                    color: cate?.color,
                    options: getOptions(i),
                });
            });
        }
        if (labelInfo.label_pointLine) {
            labelInfo.label_pointLine.forEach(i => {
                const points = i.polygon.bottom.map(({ x, y }) => ({
                    x: getNum(x),
                    y: getNum(y),
                }));
                const cate = this.findCate(i.category);
                this.drawPointLine({
                    points,
                    color: cate?.color,
                    options: getOptions(i),
                });
            });
        }
        return Promise.resolve();
    }
    // 画多边形
    drawPolygon({ points, color, options, strokeColor, dash }) {
        if (!points)
            return;
        if (!color)
            color = '#ff0000';
        const _points = pointsObjTurnArray(points);
        /* if (_points.length > 2) {
          _points.push(points[0].x, points[0].y)
        } */
        const shape = new Konva.Line({
            points: _points,
            fill: hexToRgba(color),
            stroke: strokeColor || color,
            closed: true,
            strokeWidth: this.baseStrokeWidth / this._scale,
            type: 'polygon',
            dash: dash ?? [],
            ...options,
        });
        this._shapeEventBind(shape);
        return shape;
    }
    drawPointLine({ points, color, options, strokeColor }) {
        //
        if (points.length !== 2)
            return;
        if (!color)
            color = '#ff0000';
        const p1 = points[0];
        const p2 = points[1];
        const { x: x1, y: y1 } = p1;
        const { x: x2, y: y2 } = p2;
        const _points = pointsObjTurnArray(points);
        const id = uniqId();
        const p1_shape = new Konva.Circle({
            x: x1,
            y: y1,
            noText: true,
            radius: this.baseCircleRadius / this._scale,
            hitRadius: 16 / this._scale,
            fill: hexToRgba(color, 0.8),
            stroke: color,
            strokeWidth: this.baseStrokeWidth / this._scale,
            type: 'pointLine_point',
            hitFunc(context) {
                context.beginPath();
                context.arc(0, 0, this.getAttr('hitRadius') || this.radius(), 0, Math.PI * 2, false);
                context.closePath();
                context.fillStrokeShape(this);
            },
            ...options,
            id: 'start_' + id,
        });
        const p2_shape = new Konva.Circle({
            x: x2,
            y: y2,
            noText: true,
            radius: this.baseCircleRadius / this._scale,
            hitRadius: 16 / this._scale,
            fill: hexToRgba(color, 0.8),
            stroke: color,
            strokeWidth: this.baseStrokeWidth / this._scale,
            type: 'pointLine_point',
            hitFunc(context) {
                context.beginPath();
                context.arc(0, 0, this.getAttr('hitRadius') || this.radius(), 0, Math.PI * 2, false);
                context.closePath();
                context.fillStrokeShape(this);
            },
            ...options,
            id: 'end_' + id,
        });
        const shape = new Konva.Line({
            points: _points,
            fill: hexToRgba(color),
            stroke: strokeColor || color,
            closed: false,
            strokeWidth: this.baseStrokeWidth / this._scale,
            hitStrokeWidth: 14 / this._scale,
            type: 'pointLine',
            ...options,
            id,
        });
        this._shapeEventBind(shape);
        this._shapeEventBind(p1_shape);
        this._shapeEventBind(p2_shape);
    }
    // 画文字
    drawText(shape) {
        if (!shape.attrs.category ||
            shape.attrs.number === undefined ||
            shape.attrs.id === undefined ||
            shape.attrs.noText)
            return;
        const edge = 5 / this._scale;
        const fontSize = this.baseFontSize / this._scale;
        const text = shape.attrs.category ?? '';
        let x, y, oriX, oriY;
        if (shape.attrs.type === 'polygon' || shape.attrs.type === 'pointLine') {
            x = shape.getSelfRect().x + shape.getSelfRect().width / 2;
            y = shape.getSelfRect().y + shape.getSelfRect().height / 2;
            oriX = x;
            oriY = y;
            x = x - edge - (fontSize * text.length) / 2;
            y = y - edge - fontSize / 2;
        }
        else {
            x = shape.x();
            y = shape.y();
            oriX = x;
            oriY = y;
        }
        const fill = shape.stroke();
        return new Konva.Text({
            x: x + edge,
            y: y + edge,
            oriX,
            oriY,
            text,
            fontSize,
            fill,
            stroke: textHalo(fill),
            strokeWidth: 1.5 / this._scale,
            fillAfterStrokeEnabled: true,
            opacity: this._showText ? 1 : 0,
            type: 'text',
            oriShapeType: shape.attrs.type,
            name: 'text ' +
                'text_' +
                shape.attrs.id +
                ' ' +
                (shape.attrs?.category ?? ''),
            id: 'text_' + shape.attrs.id,
        });
    }
    // 画图像
    drawImage(src, previewSize) {
        return new Promise((resolve, reject) => {
            const imgId = this._currLoadingImg + 1;
            const imageObj = new Image();
            imageObj.src = src;
            this._currLoadingImg = imgId;
            imageObj.crossOrigin = 'Anonymous';
            imageObj.onerror = () => {
                reject('image load Error');
            };
            imageObj.onload = () => {
                if (this.dom && imgId < this._currLoadingImg) {
                    reject({
                        type: 233,
                        msg: 'image load has been covered',
                    });
                    return;
                }
                const width = imageObj.width;
                const height = imageObj.height;
                if (previewSize) {
                    this.setScale(previewSize / width);
                }
                else {
                    this.fitBounds(width, height);
                }
                const image = new Konva.Image({
                    x: 0,
                    y: 0,
                    image: imageObj,
                    width,
                    height,
                    name: 'image',
                });
                this.layer.add(image);
                image.moveToBottom();
                resolve(JSON.stringify({ width, height }));
            };
        });
    }
    checkAllObjStroke() {
        const textArr = this.layer.find('.text');
        const labelArr = this.layer.find('.label');
        this._controllerService?.fixControllerScale(this._scale);
        textArr.forEach(i => {
            if (i instanceof Konva.Text) {
                const edge = 5 / this._scale;
                const fontSize = this.baseFontSize / this._scale;
                i.fontSize(fontSize);
                i.strokeWidth(1.5 / this._scale);
                if (i.attrs.oriShapeType && i.attrs.oriShapeType === 'polygon') {
                    const x = i.attrs.oriX - edge - i.width() / 2;
                    const y = i.attrs.oriY - edge - i.height() / 2;
                    i.x(x);
                    i.y(y);
                }
                else if (i.attrs.oriShapeType &&
                    i.attrs.oriShapeType === 'pointLine') {
                    const x = i.attrs.oriX - edge - i.width() / 2;
                    const y = i.attrs.oriY - edge - i.height() / 2;
                    i.x(x);
                    i.y(y);
                }
                else {
                    i.x(i.attrs.oriX + edge);
                    i.y(i.attrs.oriY + edge);
                }
            }
        });
        labelArr.forEach((i) => {
            if (i instanceof Konva.Circle) {
                i.radius(this.baseCircleRadius / this._scale);
                if (i.attrs.type === 'pointLine_point')
                    i.setAttr('hitRadius', 16 / this._scale);
            }
            i.strokeWidth(this.baseStrokeWidth / this._scale);
            if (i.attrs.type === 'pointLine')
                i.hitStrokeWidth(14 / this._scale);
        });
    }
    fitBounds(width, height) {
        if (width === undefined || height === undefined) {
            const imageObj = this.layer.findOne('.image');
            width = imageObj?.width() ?? 0;
            height = imageObj?.height() ?? 0;
        }
        const offset = { x: 0, y: 0 };
        if (this.width && this.height) {
            // 确定比例系数和画布偏移距离
            const wScale = this.width / width;
            const hScale = (this.height - 22) / height;
            if (wScale < hScale) {
                this.setScale(wScale);
                offset.y = (height * wScale - this.height) / 2;
            }
            else {
                this.setScale(hScale);
                offset.x = (width * hScale - this.width) / 2;
            }
            this.layer.scaleX(this._scale);
            this.layer.scaleY(this._scale);
            this.layer.position({ x: -offset.x, y: -offset.y });
        }
        this.checkAllObjStroke();
    }
    // 设置文字显隐
    setTextShow(flag) {
        if (flag === undefined)
            flag = !this._showText;
        this._showText = flag;
        this.layer.find('.text').forEach(label => {
            label.opacity(flag ? 1 : 0);
            label.listening(!!flag);
        });
        return Promise.resolve();
    }
    // 设置scale
    setScale(number = 1) {
        this._scale = number;
        this.onScale?.(number);
    }
    // 设置只读
    setReadonly(flag = false) {
        this._readonly = flag;
        if (this._controllerService) {
            this._controllerService.clearOrigin();
        }
        if (!flag)
            this._setController();
        else
            this._controllerService = undefined;
        this.layer.find('.group').forEach(label => {
            if (figureShape(label).attrs.type !== 'pointLine')
                label.draggable(!flag);
        });
        return Promise.resolve();
    }
    setDrawing(flag) {
        this._isDrawing = flag;
        if (this._isDrawing) {
            this.onDrawStart?.();
        }
        else {
            this.onDrawEnd?.();
        }
    }
    zoomInAndOut(flag, pointer) {
        if (!this.stage)
            return;
        const oldScale = this.layer.scaleX();
        let x, y;
        if (pointer) {
            x = pointer.x;
            y = pointer.y;
        }
        else {
            x = 0;
            y = 0;
        }
        const mousePointTo = {
            x: (x - this.layer.x()) / oldScale,
            y: (y - this.layer.y()) / oldScale,
        };
        let newScale = flag ? oldScale * 1.04 : oldScale / 1.04;
        if (newScale > this.maxScale)
            newScale = this.maxScale;
        if (newScale < this.minScale)
            newScale = this.minScale;
        this.layer?.scale({ x: newScale, y: newScale });
        this.setScale(newScale);
        const layerX = x - mousePointTo.x * newScale;
        const layerY = y - mousePointTo.y * newScale;
        this.layer?.position(this._checkLayerXY(layerX, layerY));
        this.checkAllObjStroke();
    }
}

window.CoolCanvas = CoolCanvas;
})();
