from _typeshed import Incomplete
from cpipe.module.node import Node as Node

ALARM_FIELDS: Incomplete

def get_store_dir():
    """
    Find the store_dir of the AlarmReport node on every request, the node objects change after the workflow restarts.
    Returns: The store_dir, None if there is no AlarmReport node.
    """
def connect(store_dir, readonly: bool = True): ...
def _attach_files(conn, items):
    """
    Add image_url/video_url to the alarms, null when the file is not ready.
    """
def query_alarms(store_dir, start_time=None, end_time=None, alarm_name=None, streamer_name=None, alarm_type=None, keyword=None, order: str = 'desc', page: int = 1, page_size: int = 20):
    """
    Query the alarms. keyword searches in alarm_name and alarm_text.
    Returns: (total, items)
    """
def get_alarm(store_dir, alarm_id):
    """
    Get one alarm by alarm_id, including image_url/video_url and all files.
    Returns: The alarm dict, None if not found.
    """
def get_options(store_dir):
    """
    Returns: The distinct values for the filter selects.
    """
def get_file_path(store_dir, file_id):
    """
    Returns: The absolute file path, None if not exists or outside store_dir.
    """
def delete_alarms(store_dir, alarm_ids):
    """
    Delete the alarms and their files which are not used by other alarms.
    Returns: The number of the deleted alarms.
    """
