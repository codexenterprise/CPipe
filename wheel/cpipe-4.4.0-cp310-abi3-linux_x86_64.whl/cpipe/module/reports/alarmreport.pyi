from _typeshed import Incomplete
from cpipe.config.config import BETWEEN_NODES_SHARE_MEMORY_MODE as BETWEEN_NODES_SHARE_MEMORY_MODE, SHARE_MEMORY_MODE as SHARE_MEMORY_MODE
from cpipe.module.cdata import Alarm as Alarm
from cpipe.module.cvalidator import CBool as CBool, CNone as CNone
from cpipe.module.insight import Insight as Insight
from cpipe.module.node import Node as Node
from cpipe.module.report import Report as Report
from cpipe.module.utils import ChineseText as ChineseText

SQL_INIT: str

class AlarmReport(Report):
    store_dir: str
    retention_days: float
    video_seconds: float
    video_frame_interval: int
    save_max_side: int
    buffer_resize: CBool
    image_quality: int
    snapshot_workers: int
    snapshot_queue_size: int
    video_workers: int
    video_queue_size: int
    draw_boxes: CBool
    draw_shows: CBool
    mqtt_broker: CNone | str
    mqtt_port: int
    mqtt_username: CNone | str
    mqtt_password: CNone | str
    mqtt_topic_prefix: str
    mqtt_qos: int
    mqtt_http_base: CNone | str
    shutdown_flush_seconds: float
    _db_lock: Incomplete
    _db: Incomplete
    _thread_local: Incomplete
    _show_args: Incomplete
    _rings: Incomplete
    _clips: Incomplete
    _snapshot_queue: Incomplete
    _video_queue: Incomplete
    _event_alarm_queue: Incomplete
    _ffmpeg: Incomplete
    _mqtt: Incomplete
    def init_alarm(self) -> None: ...
    def event_alarm(self, data):
        '''
        Receive the alarm from the nodes not in the data link. "image" type is not supported, because box_unique_id cannot match the frame.
        Args:
            data: {"streamer_name": str, "alarm_name": str, "alarm_text": str, "alarm_type": "text"/"video", "track_ids": [...], "extra": dict}
        Returns: True
        '''
    def _db_exec(self, sql, args=()): ...
    def _mqtt_publish(self, alarm_id) -> None: ...
    def _add_media(self, file_type, file_path, status, start_time=None): ...
    def _media_path(self, ts, name): ...
    def _draw(self, rec, alarm, track_ids): ...
    def _snapshot_loop(self) -> None: ...
    def _video_loop(self) -> None: ...
    def _cleanup_loop(self) -> None: ...
    def _buffer_frame(self, streamer_name, cimage, boxes, shows) -> None: ...
    def _close_clip(self, clip) -> None: ...
    def _handle_alarm(self, streamer_name, alarm, new_cdata) -> None: ...
    def lastly(self, signum, frame) -> None: ...
    def _start(self) -> None:
        """
        Start the alarm report node.
        Returns: None

        """
