from _typeshed import Incomplete
from collections.abc import Generator
from cpipe.config.config import AGENT_MODEL as AGENT_MODEL, SHARE_MEMORY_MAX_HEIGHT_WIDTH_CHANNEL as SHARE_MEMORY_MAX_HEIGHT_WIDTH_CHANNEL
from cpipe.module import alarmquery as alarmquery
from cpipe.module.cbuffer import CSharedImageBuffer as CSharedImageBuffer
from cpipe.module.clogger import CLogger as CLogger
from cpipe.module.cmask import CMask as CMask
from cpipe.module.cvalidator import CBool as CBool, CFilePath as CFilePath
from cpipe.module.node import Node as Node, NodeType as NodeType
from cpipe.module.security import Security as Security
from cpipe.module.service.chat import ChatService as ChatService
from cpipe.module.utils import ChineseText as ChineseText, check_annotation as check_annotation
from enum import Enum
from fastapi import FastAPI, Request as Request
from fastapi.templating import Jinja2Templates
from typing import Annotated, Any, ClassVar, Literal

def _register_numpy_json_encoders(): ...

class InsightType(str, Enum):
    UI = 'UI'
    HTTP = 'HTTP'
    NODE = 'NODE'

class Insight(Node):
    EVENT_SAVE_VIDEO: ClassVar[str]
    SHOW_TYPE_UI: ClassVar[InsightType]
    SHOW_TYPE_HTTP: ClassVar[InsightType]
    SHOW_TYPE_NODE: ClassVar[InsightType]
    instances: ClassVar[dict]
    show_type: Annotated[InsightType, 'The type of the display.']
    show_scale: Annotated[int, 'The scale of the display.']
    save_video: Annotated[CBool, 'Whether to save the video stream.']
    save_video_just_from_event: Annotated[CBool, 'Whether to save the video stream only from event.']
    streamers: Annotated[dict, 'The streamers of the node.']
    streamer_messages: Annotated[dict, 'The streamer messages of the node.']
    show_chinese: Annotated[Any, 'The show chinese class of the node.']
    streamer_frame_delay: Annotated[dict, 'The streamer frame delay of the node.']
    video_writers: Annotated[dict, 'The video writers of the node.']
    show_args: Annotated[dict, 'The show arguments of the node.']
    node_type: Annotated[NodeType, 'The type of the node.']
    video_writer_queue_size: Annotated[int, 'The queue size of the video writer.']
    video_save_format: Annotated[str, 'The format of the video save. avc1 or mp4v']
    web_message_draw_to_frame: Annotated[CBool, 'Whether to draw the message to the frame. Just support English message.']
    kwargs: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        """
        The node used to display the video stream in CPipe, supports UI display, HTTP display, and saving video streams. This is a basic class.
        Args:
            node_name: (str) The name of the node.
            queue_size: (int) The size of the queue.
            show_type: (int) The type of the display, 0: UI, 1: HTTP, 2: Save.
            show_scale: (int) The scale of the display.
            save_video: (bool) Whether to save the video stream.
            **kwargs: Other parameters.
        """
    def init_streamer_list(self) -> None:
        """
        Initialize the streamer list and initialize the shared memory. This method is called before the start method.
        Returns:

        """
    def delay_update(self, streamer_name, m_time, current_time):
        """
        Update the delay time of the frame of the streamer.
        Args:
            streamer_name: Streamer Node name.
            m_time: The time of the frame.
            current_time: The current time.

        Returns: The fps and the delay time.

        """
    def lastly(self, signum, frame) -> None: ...
    @staticmethod
    def get_show_args(kwargs=None, get_default: bool = False): ...
    def event_show_args(self, show_args=None):
        """
        The event function of the show_args parameter of CPipeInsight.
        Args:
            show_args: The show arguments.
        Returns: None
        """
    def set_show_arguments(self, show_args: dict, tmp: int, tmp2: str = 'test'):
        '''
        The setting of information such as polygons/boxes/lines/names in the screen displaying the algorithm\'s running results.
        show_args need a dict. Note: Color is BGR format.
        Args:
            show_polygon_box: (bool) Whether to show the polygon box. default: False
            show_box: (bool) Whether to show the box. default: True
            show_box_name: (bool) Whether to show the box name. default: True
            show_text: (bool) Whether to show the text. default: True
            show_polygon: (bool) Whether to show the polygon. default: True
            show_mask: (bool) Whether to show the mask. default: True
            show_key_points: (bool) Whether to show the key points. default: True
            show_person: (bool) Whether to show the person. default: True
            show_classification: (bool) Whether to show the classification. default: True
            show_track: (bool) Whether to show the track. default: True
            show_track_velocity: (bool) Whether to show the track velocity. default: False
            show_key_points_name: (bool) Whether to show the key points name. default: False
            chinese_font_size: (int) The size of the Chinese font, Set the font size for all text except for "key_points_name". default: 20
            key_points_name_font_scale: (float) The scale of the key points name font. default: 1
            key_points_color: (tuple) The color of the key points. default: (0, 255, 128)
            key_points_name_color: (tuple) The color of the key points name. default: (128, 255, 128)
            mask_color: (tuple) The color of the mask. default: (0, 255, 0)
            track_id_font_scale: (float) The scale of the track id font. default: 1
            track_id_color: (tuple) The color of the track id. default: (0, 0, 255)
            box_name_color: (tuple) The color of the box name. default: (255, 128, 0)
            box_color: (tuple) The color of the box. default: (255, 128, 128)
            embedding_box_name_color: (tuple) The color of the embedding box name. default: (0, 255, 100)
            classification_name_color: (tuple) The color of the classification name. default: (0, 200, 255)
        Returns: None
        '''
    @staticmethod
    def draw_custom_shows(show_chinese, show, img_show) -> None: ...
    @staticmethod
    def draw_bboxes(show_chinese, img_show, one_box, show_args) -> None: ...
    def save_video_thread(self, queue_one) -> None:
        '''
        action: "START" "WRITE" "END"
        {"file_name": file_name, "fps": fps, "wh": wh, "frame": frame, "frame_time": frame_time, "action": "", "message": message, "message_format": message_format}
        # message_format: {"x_offset": 20, "y_offset": 100, "font_scale": 0.5, "color": (0, 0, 255), "thickness": 2, "line_spacing": 20}
        '''
    def event_save_video(self, data):
        '''
        data format: 
        {"stream_name": stream_name, "action": "START" | "WRITE" | "END" | "EXIT", 
        "file_name": file_name, "fps": fps, "wh": wh, "frame": frame, "frame_time": frame_time,
        "callback_event": {"node_name": node_name, "event_name": event_name, "data": data}
        }
        '''
    def _start(self) -> None:
        """
        The entry function for the current node (process) to run in one-stage mode, all the logic processing of the current node is completed here.

        Returns: None

        """

class CPipeInsight(Insight):
    app: ClassVar[FastAPI]
    current_file_path: ClassVar[str]
    current_directory: ClassVar[str]
    templates: ClassVar[Jinja2Templates]
    is_running: ClassVar[bool]
    http_insight_enabled: ClassVar[bool]
    _workflow_data: ClassVar[dict]
    _workflow_file_mtime: ClassVar[float | None]
    http_insight: Annotated[CBool, 'Whether to enable HTTP display.']
    show_fps: Annotated[int, 'The show fps.']
    ip: Annotated[str | None, 'The ip address.']
    port: Annotated[int | None, 'The port.']
    ui_insight: Annotated[CBool, 'Whether to enable UI display.']
    save_streamer_node_name: Annotated[str | None, 'The streamer node name to save, if None, save all streamer nodes.']
    save_file_name: Annotated[dict | None, 'The save file name.']
    save_path: Annotated[str, 'The save path.']
    save_duration_seconds: Annotated[float, 'The save duration in seconds.']
    save_fps: Annotated[float, 'The save fps.']
    save_wh: Annotated[tuple, 'The save width and height.']
    auto_exit: Annotated[CBool, 'Auto exit when all streamer nodes are dead.']
    mcp: Annotated[CBool, 'Whether to serve the CPipe MCP server at http://ip:port/mcp for external agents (Cursor, Claude Code, ...).']
    ssl: Annotated[CBool, 'Whether to use https.']
    cert_path: Annotated[str | None, 'The cert path with https.']
    key_path: Annotated[str | None, 'The key path with https.']
    show_polygon_box: Annotated[CBool, 'Whether to show the polygon box.']
    show_box: Annotated[CBool, 'Whether to show the box.']
    show_box_name: Annotated[CBool, 'Whether to show the box name.']
    show_text: Annotated[CBool, 'Whether to show the text.']
    show_polygon: Annotated[CBool, 'Whether to show the polygon.']
    show_mask: Annotated[CBool, 'Whether to show the mask.']
    show_key_points: Annotated[CBool, 'Whether to show the key points.']
    show_person: Annotated[CBool, 'Whether to show the person.']
    show_classification: Annotated[CBool, 'Whether to show the classification.']
    show_track: Annotated[CBool, 'Whether to show the track.']
    show_track_velocity: Annotated[CBool, 'Whether to show the track velocity.']
    show_key_points_name: Annotated[CBool, 'Whether to show the key points name.']
    video_writer_queue_size: Annotated[int, 'The queue size of the video writer.']
    chinese_font_size: Annotated[int, 'The chinese font size.']
    key_points_name_font_scale: Annotated[int, 'The key points name font scale.']
    key_points_color: Annotated[tuple, 'The key points color.']
    key_points_name_color: Annotated[tuple, 'The key points name color.']
    mask_color: Annotated[tuple, 'The mask color.']
    track_id_font_scale: Annotated[int, 'The track id font scale.']
    track_id_color: Annotated[tuple, 'The track id color.']
    box_name_color: Annotated[tuple, 'The box name color.']
    classification_name_color: Annotated[tuple, 'The classification name color.']
    embedding_box_name_color: Annotated[tuple, 'The embedding box name color.']
    node_name: Annotated[Literal['CPipeInsight'], 'The name of the node.']
    show_type: Incomplete
    interval: Incomplete
    dead_img: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        """
        Used to display the video stream in CPipe, and support HTTP display.
        """
    @staticmethod
    def _jinja_url_for_adapter(request: Request): ...
    def start_fastapi(self) -> None:
        """
        Start the node.
        Returns:

        """
    def node(request: Request):
        """
        The node page.
        Args:
            *args:

        Returns: The node page.

        """
    def alarm_page(request: Request):
        """
        The alarm page.
        """
    def live_page(request: Request): ...
    def log_page(request: Request): ...
    def get_logs(after: int | None = None, before: int | None = None, n: int = 500): ...
    @staticmethod
    def _alarm_call(func, *args, **kwargs): ...
    def get_alarms(start_time: float | None = None, end_time: float | None = None, alarm_name: str | None = None, streamer_name: str | None = None, alarm_type: str | None = None, keyword: str | None = None, order: str = 'desc', page: int = 1, page_size: int = 20):
        '''
        Query the alarms, keyword searches in alarm_name and alarm_text, order is "desc" or "asc" by alarm_time.
        '''
    def get_alarm_options(): ...
    def get_alarm(alarm_id: str): ...
    def get_alarm_file(file_id: int): ...
    async def delete_alarms(request: Request): ...
    def index(request: Request):
        """
        The index page.
        Args:
            *args:

        Returns: The index page.

        """
    def restart():
        """
        Restart the cpipe.
        Args:
            *args:

        Returns: The response data.

        """
    def connect():
        """
        Connect the cpipe, and get the cpipe streamer information.
        Args:
            *args:

        Returns: The response data.

        """
    async def del_streamer(request: Request):
        """
        Delete the streamer.
        Args:
            *args:

        Returns: The response data.

        """
    async def set_streamer(request: Request):
        """
        Add the streamer.
        Args:
            *args:

        Returns: The response data.

        """
    async def validate_node_name(request: Request): ...
    def get_edge_labels(): ...
    def get_node_params(request: Request):
        """获取节点参数列表
        根据节点类型返回对应的参数列表信息
        参数信息包括：参数名称、参数类型、是否必填以及可选值（针对选择列表类型）
        """
    def get_task_params(request: Request):
        """获取特定任务类型的参数
        根据任务类型返回该任务特有的参数列表
        """
    async def save_to_file(request: Request):
        """保存工作流到本地文件"""
    def get_workflow(): ...
    def list_video_files():
        """获取video_files目录下的所有文件"""
    def list_model_files():
        """获取model_files目录下的所有文件"""
    def restart_system():
        """接收重启请求并执行重启操作"""
    async def modify_streamer(request: Request):
        """
        Modify the streamer.
        Args:
            *args:

        Returns: The response data.

        """
    def get_device_info():
        """
        Get the device information.
        Args:
            *args:

        Returns: The response data.

        """
    async def get_image(request: Request):
        """
        Get the streamer image.
        Args:
            *args:

        Returns: The response data.

        """
    async def set_cmask(request: Request):
        """
        Set the cmask. The cmask is used to mask the streamer image. The cmask can be a polygon or a line.
        Args:
            *args:

        Returns: The response data.

        """
    async def del_cmask(request: Request):
        """
        Delete the cmask.
        Args:
            *args:

        Returns: The response data.

        """
    def show(node_name: str, request: Request):
        """
        Show the streamer image.
        Args:
            node_name: The node name.
            **kwargs:

        Returns: The streamer image.

        """
    def play(node_name: str, request: Request, time_seconds: float | None = None, pause: int | None = None):
        """
        Play the streamer video. support Fast forward and pause function.
        - no args: only return the video duration and the play progress.
        - with args time_seconds: save the time_seconds to the node instance and return the video duration and the play progress.
        - with args pause: pause/play the video.
        Args:
            node_name: The node name.
            time_seconds: optional, the time to jump to (seconds). If passed, save to the node instance.
            pause: optional, pause/play the video.

        Returns: video_duration: the video duration (seconds), play_progress: the play progress (seconds), pause: the pause/play state, fps: the video fps.
        """
    def insight(node_name: str, request: Request):
        """
        Show the insight page.
        Args:
            node_name: The node name.
            **kwargs:

        Returns: The insight page.

        """
    def debug_message(node_name: str):
        """
        Get the debug message of the node.
        Args:
            *args:
            node_name: The node name.

        Returns: The debug message.

        """
    def generate_frames(self, stream_name) -> Generator[Incomplete]:
        """
        Generate the streamer image from the streamer.
        Args:
            stream_name: The streamer name.

        Returns: The streamer image.

        """
    def get_current_show_image(self, stream_name):
        """
        Get the current streamer image with all algorithm results.
        Args:
            stream_name: The streamer name.

        Returns: The streamer image or None if the streamer is dead.

        """
