"""CPipe package."""

__version__ = "4.4.0"

# Imported on first access, so `import cpipe` stays cheap and has no side effects.
_LAZY_ATTRS = {
    "logic": ("cpipe.module.logic", "logic"),
    "Frame": ("cpipe.module.logic", "Frame"),
    "Logic": ("cpipe.module.logic", "Logic"),
    "Node": ("cpipe.module.node", "Node"),
    "Box": ("cpipe.module.cdata", "Box"),
    "CData": ("cpipe.module.cdata", "CData"),
    "CImage": ("cpipe.module.cdata", "CImage"),
    "VideoStreamer": ("cpipe.module.streamer", "VideoStreamer"),
    "CPipeInsight": ("cpipe.module.insight", "CPipeInsight"),
    "discovery": ("cpipe.module.discovery", "discovery"),
}


def __getattr__(name):
    if name == "device":
        from cpipe.module.security import Security
        value = Security.get_device_id()
        globals()["device"] = value
        return value
    if name in _LAZY_ATTRS:
        import importlib
        module_name, attr = _LAZY_ATTRS[name]
        value = getattr(importlib.import_module(module_name), attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
