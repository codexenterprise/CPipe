import asyncio
from _typeshed import Incomplete

class CEvent(asyncio.Event):
    data: Incomplete
    def __init__(self) -> None: ...
